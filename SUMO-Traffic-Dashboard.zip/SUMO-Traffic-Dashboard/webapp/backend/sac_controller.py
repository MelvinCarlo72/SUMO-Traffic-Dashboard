from pathlib import Path
import numpy as np

class SACController:
    """Adapter for the trained SAC policy.

    If a Stable-Baselines3 SAC zip is placed at ml/models/sac_controller.zip,
    this class loads it automatically. Otherwise it exposes a clearly-labeled
    deterministic fallback so the dashboard remains runnable.
    """
    def __init__(self, model_path: Path):
        self.model_path = model_path
        self.model = None
        self.loaded = False
        self.backend = "Fallback demo policy"
        if model_path.exists():
            try:
                from stable_baselines3 import SAC
                self.model = SAC.load(str(model_path))
                self.loaded = True
                self.backend = "Stable-Baselines3 SAC"
            except Exception as exc:
                self.backend = f"SAC model unavailable: {exc}"

    def predict(self, state):
        state = np.asarray(state, dtype=np.float32)
        if self.model is not None:
            action, _ = self.model.predict(state, deterministic=True)
            return int(np.asarray(action).reshape(-1)[0])
        # Safe deterministic fallback: select the direction with the largest queue.
        queues = state[:4]
        return int(np.argmax(queues))

    def status(self):
        return {
            "loaded": self.loaded,
            "backend": self.backend,
            "model_path": str(self.model_path),
        }
