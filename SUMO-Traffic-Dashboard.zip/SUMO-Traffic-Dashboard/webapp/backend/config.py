from pathlib import Path
import os
import sys

# Source run: project root. Packaged .exe: the folder that contains the .exe,
# so ml/models/ and pipeline/06_simulation/ can sit next to it and be swapped without rebuilding.
if getattr(sys, "frozen", False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = Path(os.getenv("TRAFFIC_ROOT") or Path(__file__).resolve().parents[2])
SUMO_CFG = ROOT / "pipeline" / "06_simulation" / "scenario.sumocfg"
SAC_MODEL = ROOT / "ml" / "models" / "sac_controller.zip"
HOST = os.getenv("TRAFFIC_HOST", "127.0.0.1")
PORT = int(os.getenv("TRAFFIC_PORT", "8000"))

# --- SUMO settings -----------------------------------------------------------
# Traffic-light IDs of the two junctions. Either set pipeline/06_simulation/tls_ids.json
#   {"sacop": "<tls id>", "del_rosario": "<tls id>"}
# or the environment variables SACOP_TLS_ID / DEL_ROSARIO_TLS_ID (env wins).
# Find the IDs with:  python tools/list_traffic_lights.py <network.net.xml>
import json


def _load_tls_ids():
    ids = {}
    f = ROOT / "pipeline" / "06_simulation" / "tls_ids.json"
    if f.exists():
        try:
            ids = {k: str(v) for k, v in json.loads(f.read_text(encoding="utf-8")).items() if v}
        except Exception:
            ids = {}
    for key, env in (("sacop", "SACOP_TLS_ID"), ("del_rosario", "DEL_ROSARIO_TLS_ID")):
        if os.getenv(env):
            ids[key] = os.getenv(env)
    return ids


TLS_IDS = _load_tls_ids()
# "sumo" runs headless; set SUMO_BINARY=sumo-gui to also open the SUMO window (or a full path to the exe).
SUMO_BINARY = os.getenv("SUMO_BINARY", "sumo")
