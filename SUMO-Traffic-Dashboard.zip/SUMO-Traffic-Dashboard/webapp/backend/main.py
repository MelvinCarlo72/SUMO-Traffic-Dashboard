from fastapi import FastAPI, WebSocket
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import asyncio
import csv
import io
import sys

from fastapi.responses import JSONResponse

from .config import ROOT
from .simulation import SimulationManager

app = FastAPI(title="SAC Traffic Optimization Dashboard")


@app.middleware("http")
async def no_cache(request, call_next):
    """Always serve the current UI files (the browser must not reuse old CSS/JS)."""
    resp = await call_next(request)
    if request.url.path == "/" or request.url.path.startswith("/static"):
        resp.headers["Cache-Control"] = "no-store"
    return resp
sim = SimulationManager()
if getattr(sys, "frozen", False):  # PyInstaller bundle
    FRONTEND = Path(sys._MEIPASS) / "webapp" / "frontend"
else:
    FRONTEND = Path(__file__).resolve().parents[1] / "frontend"

@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")

DATA_DIR = ROOT / "data"


@app.get("/api/results/sacop")
def sacop_results():
    """Offline SACOP thesis results (built by tools/build_sacop_results.py)."""
    f = DATA_DIR / "sacop" / "results.json"
    if not f.exists():
        return JSONResponse({"available": False, "hint": "Run: python tools/build_sacop_results.py"}, status_code=404)
    return FileResponse(f, media_type="application/json")


@app.get("/api/state")
def state():
    return sim.state()

@app.post("/api/run")
def run():
    sim.start()
    return sim.state()

@app.post("/api/pause")
def pause():
    sim.pause()
    return sim.state()

@app.post("/api/resume")
def resume():
    sim.resume()
    return sim.state()

@app.post("/api/reset")
def reset():
    sim.reset()
    return sim.state()

@app.post("/api/speed/{speed}")
def speed(speed: float):
    sim.set_speed(speed)
    return sim.state()

@app.post("/api/mode/{mode}")
def mode(mode: str):
    sim.set_mode(mode)
    return sim.state()

@app.post("/api/scenario/{scenario}")
def scenario(scenario: str):
    sim.set_scenario(scenario.replace("_", " "))
    return sim.state()

@app.post("/api/comparison/clear")
def clear_comparison():
    sim.clear_comparison()
    return sim.state()

@app.get("/api/export.csv")
def export_csv():
    fields = ["time", "vehicles", "waiting_time", "queue_length", "throughput", "delay", "speed_avg",
              "reward", "action", "mode", "scenario", "data_source",
              "sacop_queue", "del_rosario_queue", "sacop_waiting", "del_rosario_waiting"]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fields)
    writer.writeheader()
    writer.writerows({k: r.get(k) for k in fields} for r in list(sim.history))
    return StreamingResponse(
        iter([out.getvalue().encode()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=traffic_results.csv"}
    )

@app.websocket("/ws")
async def websocket(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            await ws.send_json(sim.state())
            await asyncio.sleep(0.25)
    except Exception:
        pass

if DATA_DIR.exists():
    app.mount("/data", StaticFiles(directory=DATA_DIR), name="data")
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
