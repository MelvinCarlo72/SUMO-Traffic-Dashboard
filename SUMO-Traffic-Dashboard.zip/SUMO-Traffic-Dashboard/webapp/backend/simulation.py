"""Simulation manager for the SAC traffic dashboard.

Two data sources feed the same state schema:

* ``sumo``  - real SUMO via TraCI (only when the scenario config loads).
* ``demo``  - a small queueing model used when SUMO is unavailable. It is
              always flagged as ``data_source: "demo"`` so the UI can label it.

The demo model is a simple two-phase junction model (arrivals, queues, signal
discharge). It is not SUMO output and must never be presented as such.
"""
import math
import os
import random
import threading
import time
from collections import deque

try:
    import traci
except Exception:  # pragma: no cover - traci is optional
    traci = None

from .config import SUMO_CFG, SAC_MODEL, SUMO_BINARY, TLS_IDS
from .sac_controller import SACController

DIRS = ("N", "S", "E", "W")
GROUP_OF = {"N": "NS", "S": "NS", "E": "EW", "W": "EW"}
GROUP_DIRS = {"NS": ("N", "S"), "EW": ("E", "W")}
GROUP_NAME = {"NS": "North-South", "EW": "East-West"}

# Approach type per junction:
#   signal = controlled by the traffic light / SAC
#   free   = "always go": never stopped by the signal, not part of the SAC phase choice
#   absent = no road on that side (T-junction)
ARMS = {
    "sacop": {"N": "absent", "S": "signal", "E": "signal", "W": "signal"},
    "del_rosario": {"N": "signal", "S": "signal", "E": "signal", "W": "signal"},
}
DIR_NAME = {"N": "North", "S": "South", "E": "East", "W": "West"}

# Uncontrolled ("always go") lanes inside a signalised approach. From the SACOP YOLO movement data only
# movement M04 (San Agustin -> Makatao, right turn) has control_type UNCONTROLLED: 820 of the 2,485
# vehicles entering from the west approach (33%). It uses the outer lane (rightmost lane = SUMO lane index 0).
FREE_LANES = {
    "sacop": {"W": {"share": 0.33, "movement": "M04 San Agustin \u2192 Makatao (right turn)",
                    "sumo_lane_index": 0, "canvas_lane": 1}},
}


def group_label(key, g):
    """Name of a phase group using only the signalised arms that exist at this junction."""
    dirs = [d for d in GROUP_DIRS[g] if ARMS[key][d] == "signal"]
    return GROUP_NAME[g] if len(dirs) != 1 else DIR_NAME[dirs[0]]


INTERSECTIONS = {
    "sacop": {"name": "SACOP", "tls": None, "env": "SACOP_TLS_ID"},
    "del_rosario": {"name": "Del Rosario", "tls": None, "env": "DEL_ROSARIO_TLS_ID"},
}

SCENARIOS = ("Normal Traffic", "Peak Hours", "Traffic Incident")
SCENARIO_ALIASES = {"Peak Traffic": "Peak Hours", "Heavy Traffic": "Traffic Incident"}

# Demo model only: arrivals per approach per second, and per-junction bias.
DEMO_RATE = {"Normal Traffic": 0.085, "Peak Hours": 0.14, "Traffic Incident": 0.10}
# SACOP arrival mix = observed YOLO movement counts by origin (E 39%, W 41%, S 20%) scaled so the mean is ~1.
DEMO_BIAS = {
    "sacop": {"N": 0.0, "S": 0.59, "E": 1.18, "W": 1.22},
    "del_rosario": {"N": 1.3, "S": 1.3, "E": 0.85, "W": 0.85},
}
DEMO_SEED = {"Normal Traffic": 11, "Peak Hours": 23, "Traffic Incident": 37}


class DemoJunction:
    """Two-phase junction used only by the demo data source."""
    MIN_GREEN, YELLOW, FIXED_GREEN, TRAVEL, DECIDE_EVERY = 10, 3, 30, 10, 5
    SATURATION = 0.5  # vehicles / second / approach while green

    def __init__(self, key):
        self.key = key
        self.q = {d: deque() for d in DIRS}
        self.fly = {d: deque() for d in DIRS}
        self.fly_free = {d: deque() for d in DIRS}
        self.credit = {d: 0.0 for d in DIRS}
        self.group = "NS"
        self.pending = None
        self.yellow_left = 0
        self.elapsed = 0
        self.served = 0
        self.served_wait = 0.0
        self.rate_scale = {d: 1.0 for d in DIRS}

    def step(self, t, rng, lam, mode, rec_fn, incident):
        bias = DEMO_BIAS[self.key]
        arms = ARMS[self.key]
        for d in DIRS:
            if arms[d] != "absent" and rng.random() < lam * bias[d]:
                fl = FREE_LANES.get(self.key, {}).get(d)
                if fl and rng.random() < fl["share"]:
                    self.fly_free[d].append(t + self.TRAVEL)  # uncontrolled lane: never queues
                else:
                    self.fly[d].append(t + self.TRAVEL)
            while self.fly_free[d] and self.fly_free[d][0] <= t:
                self.fly_free[d].popleft()
                self.served += 1
            while self.fly[d] and self.fly[d][0] <= t:
                self.q[d].append(self.fly[d].popleft())
        # signal logic
        if self.yellow_left > 0:
            self.yellow_left -= 1
            if self.yellow_left == 0:
                self.group, self.pending, self.elapsed = self.pending, None, 0
        else:
            self.elapsed += 1
            want = None
            if mode == "fixed":
                if self.elapsed >= self.FIXED_GREEN:
                    want = "EW" if self.group == "NS" else "NS"
            elif self.elapsed >= self.MIN_GREEN and self.elapsed % self.DECIDE_EVERY == 0:
                rec = rec_fn(self)
                if rec and rec != self.group:
                    want = rec
            if want:
                self.pending, self.yellow_left = want, self.YELLOW
        # discharge: free arms always flow; signalised arms only on their green
        for d in DIRS:
            if arms[d] == "free":
                while self.q[d]:
                    joined = self.q[d].popleft()
                    self.served += 1
                    self.served_wait += t - joined
        if self.yellow_left == 0:
            for d in GROUP_DIRS[self.group]:
                if arms[d] != "signal":
                    continue
                scale = 0.5 if (incident and self.key == "sacop" and d == "E") else 1.0
                self.credit[d] = min(2.0, self.credit[d] + self.SATURATION * scale)
                while self.credit[d] >= 1 and self.q[d]:
                    joined = self.q[d].popleft()
                    self.credit[d] -= 1
                    self.served += 1
                    self.served_wait += t - joined
        return self

    def waits(self, t):
        return [t - j for d in DIRS for j in self.q[d]]


class SimulationManager:
    def __init__(self):
        self.lock = threading.RLock()
        self.running = False
        self.paused = False
        self.connected = False
        self.time = 0
        self.speed = 1.0
        self.mode = "sac"
        self.scenario = "Normal Traffic"
        self.controller = SACController(SAC_MODEL)
        self.last_error = None
        self.history = []
        self.runs = {}
        self.run_id = 0
        self.decisions = deque(maxlen=12)
        self.last_action = "Waiting"
        self.last_reward = 0.0
        self.arrived_total = 0
        self._prev_arrived = 0
        self._prev_time = 0
        self._gen = 0
        self._thread = None
        self._lane_cache = {}
        self._last_dec = {}
        self._demo_init()
        self.inter = {k: self._empty_inter(k) for k in INTERSECTIONS}
        self.metrics = self._empty_metrics()

    # ---------- helpers ----------
    @property
    def source(self):
        return "sumo" if self.connected else "demo"

    def _empty_metrics(self):
        return {"vehicles": 0, "waiting_time": 0.0, "queue_length": 0.0, "throughput": 0,
                "delay": 0.0, "speed_avg": 0.0, "reward": 0.0}

    def _empty_inter(self, key):
        return {"id": key, "name": INTERSECTIONS[key]["name"], "tls": INTERSECTIONS[key]["tls"],
                "has_data": False, "phase": "Not started", "arms": dict(ARMS[key]),
                "free_lanes": {d: {k: v for k, v in fl.items() if k != "sumo_lane_index"} for d, fl in FREE_LANES.get(key, {}).items()},
                "signal": {"NS": "R", "EW": "R", "green": None, "remaining": None, "phase_index": None,
                           "approach": {d: None for d in DIRS}},
                "queues": {d: 0 for d in DIRS}, "vehicles_on_approach": {d: 0 for d in DIRS},
                "queue_total": 0, "waiting_time": 0.0, "speed_avg": 0.0, "density": 0.0,
                "reward": None, "decision": None, "model_input": None}

    def _demo_init(self):
        sc = self.scenario
        self.arr_rng = random.Random(DEMO_SEED.get(sc, 1))
        self.junctions = {k: DemoJunction(k) for k in INTERSECTIONS}

    def _stat_summary(self, b):
        if not b or b["seconds"] <= 0:
            return None
        s = b["seconds"]
        return {"seconds": round(s), "waiting_time": round(b["wait"] / s, 2),
                "queue_length": round(b["queue"] / s, 2), "delay": round(b["delay"] / s, 2),
                "throughput_per_hr": round(b["arrived"] / s * 3600, 1), "total_arrived": b["arrived"]}

    # ---------- lifecycle ----------
    def start(self):
        with self.lock:
            if self.running:
                self.paused = False
                return
            if self.time > 0:
                self._reset_locked()
            self.last_error = None
            self._gen += 1
            gen = self._gen
            try:
                self._sumo_start()
            except Exception as exc:  # SUMO unavailable -> labelled demo data source
                self.last_error = str(exc)
                self.connected = False
            self.run_id += 1
            if not self.connected:
                self._demo_init()
            self.running, self.paused = True, False
            self._thread = threading.Thread(target=self._loop, args=(gen,), daemon=True)
            self._thread.start()

    def pause(self):
        self.paused = True

    def resume(self):
        self.paused = False

    def reset(self):
        with self.lock:
            self._reset_locked()

    def _reset_locked(self):
        self._gen += 1
        self.running = self.paused = False
        if self.connected and traci:
            try:
                traci.close()
            except Exception:
                pass
        self.connected = False
        self.time = 0
        self.history = []
        self.decisions.clear()
        self.last_action, self.last_reward = "Waiting", 0.0
        self.arrived_total = self._prev_arrived = self._prev_time = 0
        self.last_error = None
        self._lane_cache = {}
        self._last_dec = {}
        for v in INTERSECTIONS.values():
            v["tls"] = None
        self._demo_init()
        self.inter = {k: self._empty_inter(k) for k in INTERSECTIONS}
        self.metrics = self._empty_metrics()

    def set_speed(self, speed):
        self.speed = max(0.5, min(10.0, float(speed)))

    def set_mode(self, mode):
        self.mode = mode if mode in ("sac", "fixed") else "sac"

    def set_scenario(self, scenario):
        scenario = SCENARIO_ALIASES.get(scenario, scenario)
        self.scenario = scenario if scenario in SCENARIOS else "Normal Traffic"
        if not self.running and self.time == 0:
            self._demo_init()

    def clear_comparison(self):
        with self.lock:
            self.runs = {}

    # ---------- SUMO ----------
    def _sumo_start(self):
        if traci is None:
            raise RuntimeError("TraCI is not installed. Run pip install -r webapp/requirements.txt")
        if not SUMO_CFG.exists():
            raise RuntimeError(f"SUMO configuration not found: {SUMO_CFG}")
        cmd = [SUMO_BINARY, "-c", str(SUMO_CFG), "--no-step-log", "--no-warnings", "--quit-on-end"]
        if "gui" in os.path.basename(SUMO_BINARY).lower():
            cmd += ["--start"]  # --start is a sumo-gui option; plain sumo rejects it
        traci.start(cmd)
        self.connected = True
        self._find_tls()

    def _find_tls(self):
        ids = traci.trafficlight.getIDList()
        for key, item in INTERSECTIONS.items():
            forced = TLS_IDS.get(key) or os.getenv(item["env"])
            if forced and forced not in ids:
                self.last_error = f"Traffic light '{forced}' for {item['name']} is not in the SUMO network."
            if forced and forced in ids:
                item["tls"] = forced
                self._build_lane_cache(key, forced)
                continue
            target = item["name"].lower().replace(" ", "")
            m = [x for x in ids if target in x.lower().replace(" ", "")]
            item["tls"] = m[0] if m else None
            if item["tls"]:
                self._build_lane_cache(key, item["tls"])

    @staticmethod
    def _approach_of(lane):
        """Compass approach of an incoming lane from its geometry (traveling south = North approach)."""
        shape = traci.lane.getShape(lane)
        (x1, y1), (x2, y2) = shape[-2], shape[-1]
        dx, dy = x2 - x1, y2 - y1
        if abs(dx) >= abs(dy):
            return "W" if dx > 0 else "E"
        return "S" if dy > 0 else "N"

    def _build_lane_cache(self, key, tls):
        lanes = {d: [] for d in DIRS}
        for lane in sorted(set(traci.trafficlight.getControlledLanes(tls))):
            try:
                lanes[self._approach_of(lane)].append(lane)
            except Exception:
                pass
        link_dir = []
        for idx, links in enumerate(traci.trafficlight.getControlledLinks(tls)):
            try:
                lane_id = links[0][0] if links else None
                link_dir.append((self._approach_of(lane_id), int(lane_id.rsplit("_", 1)[1])) if lane_id else (None, None))
            except Exception:
                link_dir.append((None, None))
        self._lane_cache[key] = {"lanes": lanes, "link_dir": link_dir}

    def _real_inter(self, key):
        item, cache = INTERSECTIONS[key], self._lane_cache.get(key)
        out = self._empty_inter(key)
        tls = item["tls"]
        if not tls or not cache:
            out["phase"] = "No traffic light matched"
            return out
        out["has_data"], out["tls"] = True, tls
        lanes = cache["lanes"]
        arms = ARMS[key]
        nveh = tot_wait = 0.0
        spd_w = occ = occ_n = 0.0
        for d in DIRS:
            q = v = 0
            for ln in lanes[d]:
                q += traci.lane.getLastStepHaltingNumber(ln)
                n = traci.lane.getLastStepVehicleNumber(ln)
                v += n
                tot_wait += traci.lane.getWaitingTime(ln)
                spd_w += traci.lane.getLastStepMeanSpeed(ln) * n
                occ += traci.lane.getLastStepOccupancy(ln)
                occ_n += 1
            out["queues"][d], out["vehicles_on_approach"][d] = q, v
            nveh += v
        out["queue_total"] = sum(out["queues"].values())
        out["waiting_time"] = round(tot_wait / nveh, 2) if nveh else 0.0
        out["speed_avg"] = round(spd_w / nveh * 3.6, 1) if nveh else 0.0
        out["density"] = round(occ / occ_n, 1) if occ_n else 0.0
        try:
            state = traci.trafficlight.getRedYellowGreenState(tls)
            st = {"NS": "R", "EW": "R"}
            appr = {d: ("G" if arms[d] == "free" else None if arms[d] == "absent" else "R") for d in DIRS}
            for ch, (d, lane_idx) in zip(state, cache["link_dir"]):
                if d is None or arms[d] != "signal":
                    continue  # free / absent arms do not take part in the phase
                fl = FREE_LANES.get(key, {}).get(d)
                if fl and lane_idx == fl["sumo_lane_index"]:
                    continue  # uncontrolled lane: its signal char says nothing about the phase
                g = GROUP_OF[d]
                if ch in "Gg":
                    st[g] = "G"; appr[d] = "G"
                elif ch in "yY":
                    if st[g] != "G":
                        st[g] = "Y"
                    if appr[d] != "G":
                        appr[d] = "Y"
            green = "NS" if st["NS"] == "G" and st["EW"] != "G" else "EW" if st["EW"] == "G" and st["NS"] != "G" else None
            rem = max(0.0, traci.trafficlight.getNextSwitch(tls) - traci.simulation.getTime())
            out["signal"] = {**st, "green": green, "remaining": round(rem, 1),
                             "phase_index": traci.trafficlight.getPhase(tls), "approach": appr}
            out["phase"] = f"Phase {out['signal']['phase_index']}"
        except Exception:
            out["phase"] = "Unknown"
        return out

    # ---------- demo ----------
    def _demo_inter(self, key):
        j, t = self.junctions[key], self.time
        out = self._empty_inter(key)
        out["has_data"] = True
        out["queues"] = {d: len(j.q[d]) for d in DIRS}
        out["vehicles_on_approach"] = {d: len(j.q[d]) + len(j.fly[d]) + len(j.fly_free[d]) for d in DIRS}
        out["queue_total"] = sum(out["queues"].values())
        w = j.waits(t)
        out["waiting_time"] = round(sum(w) / len(w), 2) if w else 0.0
        veh = sum(out["vehicles_on_approach"].values())
        moving = veh - out["queue_total"]
        out["speed_avg"] = round(38.0 * moving / veh, 1) if veh else 0.0
        out["density"] = round(min(100.0, veh / 48.0 * 100), 1)
        st = {"NS": "R", "EW": "R"}
        if j.yellow_left > 0:
            st[j.group] = "Y"
            green = None
        else:
            st[j.group] = "G"
            green = j.group
        rem = None
        if self.mode == "fixed":
            rem = float(j.FIXED_GREEN - j.elapsed) if j.yellow_left == 0 else float(j.yellow_left)
        elif j.yellow_left > 0:
            rem = float(j.yellow_left)
        appr = {d: (None if ARMS[key][d] == "absent" else "G" if ARMS[key][d] == "free" else st[GROUP_OF[d]]) for d in DIRS}
        out["signal"] = {**st, "green": green, "remaining": rem, "phase_index": 0 if j.group == "NS" else 2,
                         "approach": appr}
        out["phase"] = (group_label(key, j.group) + (" yellow" if j.yellow_left else " green"))
        return out

    def _demo_rec(self, key):
        def rec(j):
            obs = self._observation(self._demo_inter_light(j))
            try:
                a = self.controller.predict(obs)
            except Exception as exc:
                self.last_error = f"SAC predict failed: {exc}"
                return None
            return GROUP_OF[DIRS[a % 4]]
        return rec

    def _demo_inter_light(self, j):
        return {"queues": {d: len(j.q[d]) for d in DIRS}, "signal": {"green": j.group}}

    # ---------- controller ----------
    @staticmethod
    def _observation(inter):
        q = inter["queues"]
        g = inter["signal"].get("green")
        return [float(q["N"]), float(q["S"]), float(q["E"]), float(q["W"]), 0.0 if g == "NS" else 1.0]

    @staticmethod
    def _explain(key, q, rec):
        sums = {g: sum(q[d] for d in GROUP_DIRS[g] if ARMS[key][d] == "signal") for g in ("NS", "EW")}
        ns, ew = sums["NS"], sums["EW"]
        hi, lo = ("EW", "NS") if ew >= ns else ("NS", "EW")
        a, b = max(ns, ew), min(ns, ew)
        if a == b:
            body = f"{group_label(key, 'EW')} and {group_label(key, 'NS')} queues are equal ({ns} each)."
        elif a > b * 1.5 + 2:
            body = f"{group_label(key, hi)} queue ({a}) is significantly higher than {group_label(key, lo)} ({b})."
        else:
            body = f"{group_label(key, hi)} queue ({a}) is slightly higher than {group_label(key, lo)} ({b})."
        if rec != hi and a != b:
            body += f" The model still chose {group_label(key, rec)} priority."
        return body

    def _decide(self, key, inter):
        """Build the decision record for display from the *actual* controller output."""
        green = inter["signal"].get("green")
        q = inter["queues"]
        if self.mode == "fixed":
            return {"mode": "fixed", "action": "FIXED TIMING", "recommended": None, "confidence": None,
                    "reason": "Fixed-time plan: the signal cycles on a timer and ignores queue length."}
        obs = self._observation(inter)
        try:
            a = self.controller.predict(obs)
        except Exception as exc:
            self.last_error = f"SAC predict failed: {exc}"
            return {"mode": "sac", "action": "MODEL ERROR", "recommended": None, "confidence": None,
                    "reason": str(exc)}
        rec = GROUP_OF[DIRS[a % 4]]
        if green is None:
            label = "TRANSITION"
        else:
            label = "EXTEND GREEN" if rec == green else "SWITCH PHASE"
        return {"mode": "sac", "action": label, "recommended": rec, "action_index": int(a),
                "confidence": None, "reason": self._explain(key, q, rec), "reason_basis": "derived from input queues"}

    # ---------- stepping ----------
    def _advance(self):
        if self.connected:
            self.time += 1
            traci.simulationStep()
            self.arrived_total += int(traci.simulation.getArrivedNumber())
            if traci.simulation.getMinExpectedNumber() <= 0:
                self.running = False
                self.last_error = "SUMO scenario finished (no more vehicles expected)."
        else:
            self.time += 1
            lam = DEMO_RATE[self.scenario]
            for key, j in self.junctions.items():
                j.step(self.time, self.arr_rng, lam, self.mode, self._demo_rec(key),
                       self.scenario == "Traffic Incident")
            self.arrived_total = sum(j.served for j in self.junctions.values())

    def _collect(self):
        self.inter = {k: (self._real_inter(k) if self.connected else self._demo_inter(k)) for k in INTERSECTIONS}
        rewards = []
        for k, it in self.inter.items():
            if not it["has_data"]:
                continue
            it["reward"] = round(max(-1.0, min(1.0, 1.0 - it["queue_total"] / 100.0)), 3)
            rewards.append(it["reward"])
            it["model_input"] = {"N": it["queues"]["N"], "S": it["queues"]["S"], "E": it["queues"]["E"],
                                 "W": it["queues"]["W"], "phase": it["signal"].get("green") or "transition",
                                 "vector": self._observation(it)}
            dec = self._decide(k, it)
            it["decision"] = dec
            if self.mode == "sac":
                sig = (dec["action"], dec.get("recommended"))
                if sig != self._last_dec.get(k):
                    self._last_dec[k] = sig
                    self.decisions.appendleft({"time": self.time, "intersection": it["name"],
                                               "action": dec["action"], "recommended": dec.get("recommended"),
                                               "reason": dec["reason"]})
        self.last_reward = round(sum(rewards) / len(rewards), 3) if rewards else 0.0
        decs = [i["decision"]["action"] for i in self.inter.values() if i["decision"]]
        self.last_action = " / ".join(decs) if decs else "Waiting"
        self.metrics = self._network_metrics()
        row = {"time": self.time, **self.metrics, "action": self.last_action, "mode": self.mode,
               "scenario": self.scenario, "data_source": self.source,
               "sacop_queue": self.inter["sacop"]["queue_total"],
               "del_rosario_queue": self.inter["del_rosario"]["queue_total"],
               "sacop_waiting": self.inter["sacop"]["waiting_time"],
               "del_rosario_waiting": self.inter["del_rosario"]["waiting_time"]}
        self.history.append(row)
        self._record_comparison()

    def _network_metrics(self):
        r = self.last_reward
        if self.connected:
            ids = traci.vehicle.getIDList()
            n = len(ids)
            speeds = [traci.vehicle.getSpeed(v) for v in ids]
            waits = [traci.vehicle.getAccumulatedWaitingTime(v) for v in ids]
            loss = []
            for v in ids:
                try:
                    loss.append(traci.vehicle.getTimeLoss(v))
                except Exception:
                    pass
            return {"vehicles": n, "waiting_time": round(sum(waits) / n, 2) if n else 0.0,
                    "queue_length": float(sum(1 for s in speeds if s < 0.1)),
                    "throughput": self.arrived_total,
                    "delay": round(sum(loss) / len(loss), 2) if loss else 0.0,
                    "speed_avg": round(sum(speeds) / n * 3.6, 2) if n else 0.0, "reward": r}
        t = self.time
        waits = [w for j in self.junctions.values() for w in j.waits(t)]
        served = sum(j.served for j in self.junctions.values())
        swait = sum(j.served_wait for j in self.junctions.values())
        veh = sum(sum(i["vehicles_on_approach"].values()) for i in self.inter.values())
        spd = [i["speed_avg"] * sum(i["vehicles_on_approach"].values()) for i in self.inter.values()]
        return {"vehicles": veh, "waiting_time": round(sum(waits) / len(waits), 2) if waits else 0.0,
                "queue_length": float(sum(i["queue_total"] for i in self.inter.values())),
                "throughput": served, "delay": round(swait / served, 2) if served else 0.0,
                "speed_avg": round(sum(spd) / veh, 2) if veh else 0.0, "reward": r}

    def _record_comparison(self):
        key = f"{self.source}|{self.scenario}|{self.mode}"
        b = self.runs.get(key)
        if not b or b["run_id"] != self.run_id:
            b = self.runs[key] = {"run_id": self.run_id, "seconds": 0.0, "wait": 0.0, "queue": 0.0,
                                  "delay": 0.0, "arrived": 0}
        dt = self.time - self._prev_time
        if dt > 0:
            m = self.metrics
            b["seconds"] += dt
            b["wait"] += m["waiting_time"] * dt
            b["queue"] += m["queue_length"] * dt
            b["delay"] += m["delay"] * dt
            b["arrived"] += self.arrived_total - self._prev_arrived
        self._prev_time, self._prev_arrived = self.time, self.arrived_total

    def _loop(self, gen):
        last, credit = time.monotonic(), 0.0
        while self.running and gen == self._gen:
            now = time.monotonic()
            dt, last = now - last, now
            if not self.paused:
                credit += self.speed * dt
                n = min(int(credit), 40)
                credit = credit - int(credit) if n else credit
                if n:
                    try:
                        with self.lock:
                            if gen != self._gen:
                                break
                            for _ in range(n):
                                self._advance()
                                if not self.running:
                                    break
                            self._collect()
                    except Exception as exc:
                        self.last_error = f"Simulation loop stopped: {exc}"
                        self.running = False
            time.sleep(0.05)

    # ---------- outputs ----------
    def _series(self, limit=240):
        h = self.history
        stride = max(1, math.ceil(len(h) / limit))
        keep = ("time", "waiting_time", "queue_length", "reward", "throughput", "delay", "mode",
                "sacop_queue", "del_rosario_queue", "sacop_waiting", "del_rosario_waiting")
        rows = h[::stride]
        if h and rows[-1] is not h[-1]:
            rows.append(h[-1])
        return [{k: r[k] for k in keep} for r in rows]

    def state(self):
        with self.lock:
            cur = f"{self.source}|{self.scenario}|"
            comp = {"source": self.source, "scenario": self.scenario,
                    "fixed": self._stat_summary(self.runs.get(cur + "fixed")),
                    "sac": self._stat_summary(self.runs.get(cur + "sac"))}
            return {
                "running": self.running, "paused": self.paused, "connected": self.connected,
                "data_source": self.source, "time": self.time, "speed": self.speed, "mode": self.mode,
                "scenario": self.scenario, "scenarios": list(SCENARIOS), "metrics": self.metrics,
                "action": self.last_action, "reward": self.last_reward,
                "sac": self.controller.status(), "error": self.last_error,
                "system": {"traci_installed": traci is not None, "sumo_cfg_found": SUMO_CFG.exists(),
                           "sumo_connected": self.connected, "traci_connected": self.connected},
                "intersections": [self.inter[k] for k in INTERSECTIONS],
                "history": self._series(), "decisions": list(self.decisions), "comparison": comp,
            }
