/* Browser traffic view. It is a schematic driven by live state from the backend:
   per-approach vehicle counts, queues and signal state. It is NOT the SUMO GUI and
   individual vehicle positions are illustrative; the counts and signals are real
   (from SUMO when connected, or from the labelled demo model). */
(function () {
  const W = 1000, H = 540, HALF = 40, STOP = 50, VL = 15, VW = 7, GAP = 19, VMAX = 58, LANES = [13, 29];
  const J = { sacop: { x: 300, y: 270 }, del_rosario: { x: 700, y: 270 } };
  const EXIT = STOP * 2 + 60;
  const C = { road: "#151c26", edge: "#2a3442", dash: "#3b475a", bg: "#0a0e14", ok: "#3ecf8e", warn: "#e8b34a", bad: "#ee5d5d", ml: "#5aa9ff", veh: "#a9b8cf" };

  const armOf = (k, d) => { const it = typeof inter === "function" ? inter(k) : null; return (it && it.arms && it.arms[d]) || (k === "sacop" && d === "N" ? "absent" : k === "sacop" && d === "W" ? "free" : "signal"); };
  const END_LABELS = [
    { t: "\u2190 To San Agustin Rd", x: 14, y: 270 - HALF - 16, a: "left" },
    { t: "To Sindalan \u2192", x: 986, y: 270 - HALF - 16, a: "right" },
    { t: "\u2191 To Del Rosario", x: 700, y: 16, a: "center" },
    { t: "\u2193 To Makatao Rd", x: 300, y: H - 10, a: "center" },
    { t: "\u2193 To Tourism Rd", x: 700, y: H - 10, a: "center" },
  ];
  function armLen(k, d) {
    if (d === "W" && k === "sacop") return 230;
    if (d === "E" && k === "del_rosario") return 230;
    return { N: 190, S: 170, E: 140, W: 140 }[d];
  }
  function pos(k, d, s, lane) {
    const { x: cx, y: cy } = J[k], off = LANES[lane];
    switch (d) {
      case "N": return { x: cx - off, y: cy - STOP + s, a: Math.PI / 2 };
      case "S": return { x: cx + off, y: cy + STOP - s, a: -Math.PI / 2 };
      case "E": return { x: cx + STOP - s, y: cy - off, a: Math.PI };
      default: return { x: cx - STOP + s, y: cy + off, a: 0 };
    }
  }

  class Traffic {
    constructor() { this.veh = []; this.state = null; this.lastTime = 0; this.cool = {}; this.n = 0; }
    sync(s) {
      if (s.time < this.lastTime || (!s.running && s.time === 0)) this.veh = [];
      this.lastTime = s.time; this.state = s;
    }
    timeScale() { const s = this.state; return s && s.running && !s.paused ? Math.min(3, Math.sqrt(s.speed || 1)) : 0; }
    step(dt) {
      const s = this.state; if (!s) return;
      dt = Math.min(dt, 0.1);
      const ts = this.timeScale(), sdt = dt * ts;
      for (const k of KEYS) {
        const it = s.intersections.find(i => i.id === k); if (!it) continue;
        for (const d of DIRS) {
          const L = armLen(k, d), arm = (it.arms && it.arms[d]) || "signal", fl = it.free_lanes && it.free_lanes[d];
          if (arm === "absent") continue;
          const grp = d === "N" || d === "S" ? "NS" : "EW", ap = it.signal.approach && it.signal.approach[d];
          const go = () => (arm === "free" ? true : (ap || it.signal[grp]) === "G");
          const lane = this.veh.filter(v => v.k === k && v.d === d);
          if (ts > 0) {
            for (let li = 0; li < 2; li++) {
              const ls = lane.filter(v => v.lane === li && !v.dying).sort((a, b) => b.s - a.s);
              let lead = null;
              for (const v of ls) {
                let smax = lead ? lead.s - GAP : Infinity;
                const freeLane = fl && li === fl.canvas_lane;  // uncontrolled lane (e.g. San Agustin right turn)
                const green = freeLane || go(), yellow = arm !== "free" && (ap || it.signal[grp]) === "Y";
                if (arm !== "free" && !freeLane && v.s <= 0 && !green && !(yellow && v.s > -12)) smax = Math.min(smax, -2);
                const vdes = Math.max(0, Math.min(VMAX, 2.4 * (smax - v.s)));
                v.v += Math.max(-220 * sdt, Math.min(110 * sdt, vdes - v.v));
                v.s = Math.min(v.s + v.v * sdt, smax);
                lead = v;
              }
            }
          }
          lane.forEach(v => { if (v.dying) v.alpha -= dt * 2; });
          // keep the approach populated to match the real per-approach vehicle count
          const target = Math.min(12, it.has_data ? it.vehicles_on_approach[d] : 0);
          const key = k + d;
          this.cool[key] = (this.cool[key] || 0) - sdt;
          const live = lane.filter(v => v.s <= 2 && !v.dying);
          if (ts > 0 && live.length < target && this.cool[key] <= 0) {
            const l0 = live.filter(v => v.lane === 0).length, l1 = live.length - l0;
            const li = fl ? (Math.random() < fl.share ? fl.canvas_lane : 1 - fl.canvas_lane) : (l0 <= l1 ? 0 : 1);
            if (!live.some(v => v.lane === li && v.s < -L + 24)) {
              this.veh.push({ k, d, lane: li, s: -L, v: VMAX * 0.8, alpha: 1, dying: false, id: ++this.n });
              this.cool[key] = 0.22;
            }
          } else if (ts > 0 && live.length > target + 1) {
            const far = live.reduce((a, b) => (a && a.s < b.s ? a : b), null);
            if (far && far.s < -L + 60) far.dying = true;
          }
        }
      }
      this.veh = this.veh.filter(v => v.alpha > 0 && v.s < EXIT);
    }
  }

  class SimView {
    constructor(el, traffic) {
      this.el = el; this.t = traffic;
      el.innerHTML = '<canvas aria-label="Live traffic simulation"></canvas>' +
        '<div class="hud tl"></div><div class="hud bl"></div>' +
        KEYS.map(k => `<div class="jlabel" data-k="${k}"></div>`).join("") + '<div class="idle-msg" hidden></div>';
      this.cv = el.querySelector("canvas"); this.ctx = this.cv.getContext("2d");
      this.tl = el.querySelector(".tl"); this.bl = el.querySelector(".bl"); this.idle = el.querySelector(".idle-msg");
      this.labels = {}; el.querySelectorAll(".jlabel").forEach(l => (this.labels[l.dataset.k] = l));
      this.geo = { s: 1, ox: 0, oy: 0 };
      this.cv.addEventListener("click", e => {
        const r = this.cv.getBoundingClientRect(), g = this.geo;
        const wx = (e.clientX - r.left - g.ox) / g.s, wy = (e.clientY - r.top - g.oy) / g.s;
        let best = null, bd = 1e9;
        for (const k of KEYS) { const d = Math.hypot(wx - J[k].x, wy - J[k].y); if (d < bd) { bd = d; best = k; } }
        if (bd < 150) { TD.sel = best; TD.hooks.forEach(h => h(TD.state)); }
      });
    }
    visible() { return this.el.offsetParent !== null && this.el.clientWidth > 40; }
    updateText() {
      const s = TD.state; if (!s) return;
      const src = s.data_source === "sumo" ? "SUMO live" : "demo model";
      this.tl.innerHTML = `<span class="pill">t <b>${fmt.time(s.time)}</b></span><span class="pill"><b>${s.speed}x</b></span><span class="pill">${s.mode === "sac" ? "SAC control" : "Fixed-time control"}</span>`;
      this.bl.innerHTML = `<span class="lg"><i></i>moving</span><span class="lg"><i class="q"></i>queued</span><span>Schematic view &middot; counts and signals from ${src}</span>`;
      for (const k of KEYS) {
        const it = inter(k), l = this.labels[k]; if (!it) continue;
        const lv = levelOf(it.queue_total);
        l.classList.toggle("focus", TD.sel === k);
        l.innerHTML = it.has_data
          ? `<b><span class="dot ${lv}"></span>${NAMES[k]}</b><small>queue ${it.queue_total} &middot; ${esc(sigText(it.signal, it.arms))}</small>`
          : `<b><span class="dot"></span>${NAMES[k]}</b><small>no data yet</small>`;
      }
      this.idle.hidden = started();
      this.idle.textContent = "Press Run to start the simulation";
    }
    draw() {
      const cv = this.cv, w = this.el.clientWidth, h = this.el.clientHeight, dpr = window.devicePixelRatio || 1;
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
      const ctx = this.ctx, pad = 14, s = Math.min((w - pad * 2) / W, (h - pad * 2) / H);
      const ox = (w - W * s) / 2, oy = (h - H * s) / 2 + 12;
      this.geo = { s, ox, oy };
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = C.bg; ctx.fillRect(0, 0, w, h);
      ctx.save(); ctx.translate(ox, oy); ctx.scale(s, s);
      this.roads(ctx);
      const st = TD.state;
      if (st) {
        for (const k of KEYS) { const it = inter(k); if (it && it.has_data) this.tint(ctx, k, it); }
        for (const k of KEYS) this.junction(ctx, k, inter(k));
        for (const v of this.t.veh) this.car(ctx, v);
      }
      ctx.restore();
      for (const k of KEYS) { const l = this.labels[k]; l.style.left = ox + (J[k].x + HALF + 14) * s + "px"; l.style.top = Math.max(44, oy + 70 * s) + "px"; }
    }
    roads(ctx) {
      ctx.fillStyle = "#0d1219";
      for (let x = 0; x <= W; x += 50) for (let y = 0; y <= H; y += 50) ctx.fillRect(x - 1, y - 1, 2, 2);
      const top = k => (armOf(k, "N") === "absent" ? J[k].y - HALF : 0), bot = k => (armOf(k, "S") === "absent" ? J[k].y + HALF : H);
      const cy = J.sacop.y;
      ctx.fillStyle = C.road; ctx.fillRect(0, cy - HALF, W, HALF * 2);
      for (const k of KEYS) ctx.fillRect(J[k].x - HALF, top(k), HALF * 2, bot(k) - top(k));
      ctx.strokeStyle = C.edge; ctx.lineWidth = 2; ctx.beginPath();
      for (const y of [cy - HALF, cy + HALF]) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      for (const k of KEYS) for (const dx of [-HALF, HALF]) { ctx.moveTo(J[k].x + dx, top(k)); ctx.lineTo(J[k].x + dx, bot(k)); }
      ctx.stroke();
      const box = k => { ctx.fillStyle = C.road; ctx.fillRect(J[k].x - HALF + 1, J[k].y - HALF + 1, HALF * 2 - 2, HALF * 2 - 2); };
      KEYS.forEach(box);
      ctx.strokeStyle = C.dash; ctx.lineWidth = 1.2; ctx.setLineDash([10, 9]); ctx.beginPath();
      for (const y of [cy - 21, cy + 21]) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      for (const k of KEYS) for (const dx of [-21, 21]) { ctx.moveTo(J[k].x + dx, top(k)); ctx.lineTo(J[k].x + dx, bot(k)); }
      ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = "#5a4e2a"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy);
      for (const k of KEYS) { ctx.moveTo(J[k].x, top(k)); ctx.lineTo(J[k].x, bot(k)); }
      ctx.stroke();
      KEYS.forEach(box);
      // road-end labels
      ctx.font = "600 15px " + getComputedStyle(document.body).fontFamily; ctx.textBaseline = "middle";
      for (const l of END_LABELS) { ctx.textAlign = l.a; ctx.fillStyle = "#9aa2ab"; ctx.fillText(l.t, l.x, l.y); }
    }
    tint(ctx, k, it) {
      const { x: cx, y: cy } = J[k];
      for (const d of DIRS) {
        const q = it.queues[d], L = armLen(k, d); if (!q || armOf(k, d) === "absent") continue;
        const col = q >= 9 ? C.bad : q >= 4 ? C.warn : C.ok, len = Math.min(L, 14 + q * 19);
        const r = { N: [cx - HALF, cy - STOP - len, HALF, len, 0, 1], S: [cx, cy + STOP, HALF, len, 0, 0],
          E: [cx + STOP, cy - HALF, len, HALF, 0, 0], W: [cx - STOP - len, cy, len, HALF, 1, 0] }[d];
        const [x, y, w, h] = r, horiz = d === "E" || d === "W";
        const near = d === "N" ? y + h : d === "W" ? x + w : d === "S" ? y : x;
        const far = d === "N" ? y : d === "W" ? x : d === "S" ? y + h : x + w;
        const g = horiz ? ctx.createLinearGradient(near, 0, far, 0) : ctx.createLinearGradient(0, near, 0, far);
        g.addColorStop(0, col + "55"); g.addColorStop(1, col + "00");
        ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
      }
    }
    junction(ctx, k, it) {
      const { x: cx, y: cy } = J[k], has = it && it.has_data, ap = has && it.signal.approach ? it.signal.approach : {};
      const arm = d => armOf(k, d);
      ctx.fillStyle = "#222c39";
      for (let i = -HALF + 4; i < HALF; i += 8) {
        if (arm("N") !== "absent") ctx.fillRect(cx + i, cy - STOP - 2, 4, 7);
        if (arm("S") !== "absent") ctx.fillRect(cx + i, cy + STOP - 5, 4, 7);
        if (arm("W") !== "absent") ctx.fillRect(cx - STOP - 2, cy + i, 7, 4);
        if (arm("E") !== "absent") ctx.fillRect(cx + STOP - 5, cy + i, 7, 4);
      }
      const heads = { N: [cx - HALF - 8, cy - STOP + 2], S: [cx + HALF + 8, cy + STOP - 2], E: [cx + STOP - 2, cy - HALF - 8], W: [cx - STOP + 2, cy + HALF + 8] };
      for (const d of DIRS) {
        if (arm(d) === "absent") continue;
        const [x, y] = heads[d], st = ap[d], c = !has ? "#3a475a" : st === "G" ? C.ok : st === "Y" ? C.warn : C.bad;
        ctx.fillStyle = "#06090d"; ctx.beginPath(); ctx.arc(x, y, 6.5, 0, 7); ctx.fill();
        ctx.fillStyle = c; ctx.shadowColor = c; ctx.shadowBlur = has && st !== "R" ? 10 : 0;
        ctx.beginPath(); ctx.arc(x, y, 4.2, 0, 7); ctx.fill(); ctx.shadowBlur = 0;
      }
      // stop lines only where a signal controls the approach ("always go" arms have none)
      ctx.strokeStyle = "#cdd6e3"; ctx.lineWidth = 2; ctx.beginPath();
      if (arm("N") === "signal") { ctx.moveTo(cx - HALF, cy - STOP); ctx.lineTo(cx, cy - STOP); }
      if (arm("S") === "signal") { ctx.moveTo(cx, cy + STOP); ctx.lineTo(cx + HALF, cy + STOP); }
      if (arm("E") === "signal") { ctx.moveTo(cx + STOP, cy - HALF); ctx.lineTo(cx + STOP, cy); }
      if (arm("W") === "signal") { ctx.moveTo(cx - STOP, cy); ctx.lineTo(cx - STOP, cy + HALF); }
      ctx.stroke();
      // uncontrolled ("always go") lanes / arms: green strip at the stop line + label
      const fls = (it && it.free_lanes) || {};
      const strip = { W: [cx - STOP - 2, cy + 21, 4, HALF - 21], E: [cx + STOP - 2, cy - HALF, 4, HALF - 21], N: [cx - HALF, cy - STOP - 2, HALF - 21, 4], S: [cx + 21, cy + STOP - 2, HALF - 21, 4] };
      const mk = { W: [cx - STOP - 95, cy + HALF + 14], E: [cx + STOP + 95, cy - HALF - 14], N: [cx + HALF + 60, cy - STOP - 70], S: [cx - HALF - 60, cy + STOP + 70] };
      ctx.fillStyle = "rgba(62,207,142,.9)"; ctx.font = "700 11px " + getComputedStyle(document.body).fontFamily; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      for (const d of DIRS) {
        if (fls[d]) { ctx.fillRect(...strip[d]); ctx.fillText("RIGHT TURN: ALWAYS GO", mk[d][0], mk[d][1]); }
        else if (arm(d) === "free") ctx.fillText("ALWAYS GO", mk[d][0], mk[d][1]);
      }
      if (TD.sel === k) {
        ctx.strokeStyle = C.ml; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
        ctx.strokeRect(cx - STOP - 14, cy - STOP - 14, (STOP + 14) * 2, (STOP + 14) * 2); ctx.setLineDash([]);
      }
    }
    car(ctx, v) {
      const p = pos(v.k, v.d, v.s - VL / 2, v.lane), queued = v.v < 3 && v.s <= 0;
      ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, v.alpha, (EXIT - v.s) / 40));
      ctx.translate(p.x, p.y); ctx.rotate(p.a);
      ctx.fillStyle = queued ? C.warn : C.veh;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(-VL / 2, -VW / 2, VL, VW, 1.8) : ctx.rect(-VL / 2, -VW / 2, VL, VW); ctx.fill();
      ctx.fillStyle = "rgba(6,9,13,.55)"; ctx.fillRect(VL / 2 - 4.5, -VW / 2 + 1, 2.5, VW - 2);
      ctx.restore();
    }
  }
  window.Traffic = Traffic; window.SimView = SimView;
})();
