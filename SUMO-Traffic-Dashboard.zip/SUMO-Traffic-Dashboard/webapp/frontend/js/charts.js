/* Small dependency-free line charts. Shaded bands show which controller was active. */
(function () {
  const COL = { grid: "#1b2430", axis: "#6c788a", fixed: "rgba(124,135,152,.16)", sac: "rgba(90,169,255,.10)" };
  function draw(cv, o) {
    const box = o.mini ? cv : cv.parentElement, w = box.clientWidth, h = box.clientHeight, dpr = window.devicePixelRatio || 1;
    if (!w || !h) return;
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    const ctx = cv.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    const rows = (o.rows || []).filter(r => r[o.key] != null);
    const L = o.mini ? 0 : 40, R = o.mini ? 0 : 22, T = o.mini ? 2 : 8, B = o.mini ? 2 : 22;
    cv._chart = { o, rows, L, R, T, B, w, h };
    if (rows.length < 2) {
      if (!o.mini) { ctx.fillStyle = COL.axis; ctx.font = "13px " + getComputedStyle(document.body).fontFamily; ctx.textAlign = "center"; ctx.fillText("No data yet - run the simulation", w / 2, h / 2); }
      return;
    }
    const x0 = rows[0].time, x1 = rows[rows.length - 1].time || 1;
    let lo = o.min != null ? o.min : 0, hi = Math.max(...rows.map(r => r[o.key]));
    if (o.max != null) hi = o.max; else hi = hi <= lo ? lo + 1 : hi * 1.12;
    if (o.min == null) lo = Math.min(0, ...rows.map(r => r[o.key]));
    const X = t => L + (t - x0) / Math.max(1, x1 - x0) * (w - L - R), Y = v => T + (1 - (v - lo) / (hi - lo)) * (h - T - B);
    if (!o.mini) {
      ctx.font = "11.5px " + getComputedStyle(document.body).fontFamily; ctx.fillStyle = COL.axis; ctx.strokeStyle = COL.grid; ctx.lineWidth = 1;
      ctx.textAlign = "right"; ctx.textBaseline = "middle";
      for (let i = 0; i <= 4; i++) {
        const v = lo + (hi - lo) * i / 4, y = Math.round(Y(v)) + .5;
        ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(w - R, y); ctx.stroke();
        ctx.fillText((hi - lo) < 5 ? v.toFixed(1) : Math.round(v), L - 6, y);
      }
      ctx.textAlign = "center"; ctx.textBaseline = "top";
      for (let i = 0; i <= 4; i++) { const t = x0 + (x1 - x0) * i / 4; ctx.fillText(fmt.time(t), X(t), h - B + 6); }
      // controller bands
      let s = 0;
      for (let i = 1; i <= rows.length; i++) {
        if (i === rows.length || rows[i].mode !== rows[s].mode) {
          const a = X(rows[s].time), b = X(rows[Math.min(i, rows.length - 1)].time);
          ctx.fillStyle = rows[s].mode === "fixed" ? COL.fixed : COL.sac; ctx.fillRect(a, T, Math.max(1, b - a), h - T - B); s = i;
        }
      }
    }
    ctx.beginPath();
    rows.forEach((r, i) => (i ? ctx.lineTo(X(r.time), Y(r[o.key])) : ctx.moveTo(X(r.time), Y(r[o.key]))));
    ctx.strokeStyle = o.color; ctx.lineWidth = o.mini ? 1.5 : 2; ctx.lineJoin = "round"; ctx.stroke();
    if (!o.mini) {
      ctx.lineTo(X(x1), Y(lo)); ctx.lineTo(X(x0), Y(lo)); ctx.closePath();
      const g = ctx.createLinearGradient(0, T, 0, h - B); g.addColorStop(0, o.color + "30"); g.addColorStop(1, o.color + "00");
      ctx.fillStyle = g; ctx.fill();
      const last = rows[rows.length - 1]; ctx.fillStyle = o.color; ctx.beginPath(); ctx.arc(X(last.time), Y(last[o.key]), 3.2, 0, 7); ctx.fill();
    }
    cv._chart.X = X; cv._chart.Y = Y;
  }
  function hover(cv) {
    if (cv._hover) return; cv._hover = true;
    const tip = document.createElement("div"); tip.className = "tip"; tip.hidden = true; cv.parentElement.appendChild(tip);
    cv.addEventListener("mousemove", e => {
      const c = cv._chart; if (!c || !c.X) return;
      const r = cv.getBoundingClientRect(), mx = e.clientX - r.left;
      let best = c.rows[0]; for (const row of c.rows) if (Math.abs(c.X(row.time) - mx) < Math.abs(c.X(best.time) - mx)) best = row;
      tip.hidden = false; tip.style.left = c.X(best.time) + "px"; tip.style.top = c.Y(best[c.o.key]) + "px";
      tip.innerHTML = `${fmt.time(best.time)} &middot; <b>${(+best[c.o.key]).toFixed(c.o.dec == null ? 1 : c.o.dec)}${c.o.unit || ""}</b> &middot; ${best.mode === "sac" ? "SAC" : "Fixed"}`;
    });
    cv.addEventListener("mouseleave", () => (tip.hidden = true));
  }
  window.Charts = { draw, hover };
})();
