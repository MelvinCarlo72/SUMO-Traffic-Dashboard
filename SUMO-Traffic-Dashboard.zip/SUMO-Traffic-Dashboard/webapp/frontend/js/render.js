/* Renderers. Each [data-r="name"] element is filled from the latest backend state. */
(function () {
  const METRICS = [
    { k: "waiting_time", label: "Avg waiting time", unit: "s", d: 1, lead: 1, color: "#e8b34a" },
    { k: "queue_length", label: "Queue length", unit: "veh", d: 0, lead: 1, color: "#d9dee7" },
    { k: "vehicles", label: "Vehicles", unit: "", d: 0 },
    { k: "speed_avg", label: "Avg speed", unit: "km/h", d: 1 },
    { k: "throughput", label: "Throughput", unit: "veh", d: 0 },
    { k: "delay", label: "Avg delay", unit: "s", d: 1 },
  ];
  const cmpRow = { waiting_time: "waiting_time", queue_length: "queue_length", throughput: "throughput_per_hr", delay: "delay" };
  const PRES = ["waiting_time", "queue_length", "throughput", "delay"];
  const CMP = [
    { k: "waiting_time", label: "Waiting time", unit: "s", d: 1, better: "lower", hint: "avg seconds waited" },
    { k: "queue_length", label: "Queue length", unit: "veh", d: 1, better: "lower", hint: "avg halted vehicles" },
    { k: "throughput_per_hr", label: "Throughput", unit: "veh/h", d: 0, better: "higher", hint: "vehicles completed per hour" },
    { k: "delay", label: "Delay", unit: "s", d: 1, better: "lower", hint: "avg time lost per vehicle" },
  ];
  const apLevel = q => (q < 4 ? "free" : q < 9 ? "moderate" : "congested");
  const setHtml = (el, h) => { if (el._h !== h) { el.innerHTML = h; el._h = h; } };
  const selKey = el => (el.dataset.sel ? TD.sel : el.dataset.i);
  const chipFor = d => {
    if (!d) return `<span class="chip">\u2014</span>`;
    if (d.mode === "fixed") return `<span class="chip">FIXED TIMING</span>`;
    return `<span class="chip ${d.action === "MODEL ERROR" ? "err" : "ml"}">${esc(d.action)}</span>`;
  };

  /* ---------- metrics ---------- */
  function rMetrics(el) {
    const list = el.dataset.set === "pres" ? METRICS.filter(m => PRES.includes(m.k)) : METRICS;
    if (!el._built) {
      el.innerHTML = list.map(m => `<div class="metric ${m.lead ? "lead" : ""}" data-m="${m.k}"><div class="k"><span>${m.label}</span></div><div class="v"><b>\u2014</b><u>${m.unit}</u></div><div class="dl"></div>${m.lead ? `<canvas></canvas>` : ""}</div>`).join("");
      el._built = true;
    }
    const s = TD.state, on = started();
    list.forEach(m => {
      const box = el.querySelector(`[data-m="${m.k}"]`), b = box.querySelector("b"), v = on ? fmt.n(s.metrics[m.k], m.d) : "\u2014";
      if (b.textContent !== v) { b.textContent = v; box.classList.remove("flash"); void box.offsetWidth; box.classList.add("flash"); }
      const dl = box.querySelector(".dl"), row = cmpRow[m.k] && cmp().rows.find(x => x.k === cmpRow[m.k]);
      if (dl) { if (on && row && row.pct != null) { dl.className = "dl " + row.cls; dl.textContent = (row.pct < 0 ? "\u25BC " : "\u25B2 ") + Math.abs(row.pct).toFixed(1) + "% vs Fixed-Time"; } else { dl.className = "dl"; dl.textContent = ""; } }
      const cv = box.querySelector("canvas");
      if (cv) Charts.draw(cv, { rows: s.history, key: m.k, color: m.color, mini: true, min: 0 });
    });
  }

  /* ---------- intersection visuals ---------- */
  function crossSvg(it) {
    const arm = d => (it.arms && it.arms[d]) || "signal";
    const ap = it.has_data && it.signal.approach ? it.signal.approach : {};
    const col = d => ({ G: "#3ecf8e", Y: "#e8b34a", R: "#ee5d5d" }[ap[d]] || "#3a475a");
    const bar = (d, x, y, w, h) => {
      const q = it.queues[d], c = { free: "#3ecf8e", moderate: "#e8b34a", congested: "#ee5d5d" }[apLevel(q)], n = Math.min(38, q * 3.4);
      if (!q || arm(d) === "absent") return "";
      return d === "N" ? `<rect x="${x}" y="${y - n}" width="${w}" height="${n}" rx="2" fill="${c}" opacity=".8"/>`
        : d === "S" ? `<rect x="${x}" y="${y}" width="${w}" height="${n}" rx="2" fill="${c}" opacity=".8"/>`
        : d === "E" ? `<rect x="${x}" y="${y}" width="${n}" height="${h}" rx="2" fill="${c}" opacity=".8"/>`
        : `<rect x="${x - n}" y="${y}" width="${n}" height="${h}" rx="2" fill="${c}" opacity=".8"/>`;
    };
    const top = arm("N") === "absent" ? 40 : 0, left = arm("W") === "absent" ? 40 : 0;
    const head = (d, x, y) => (arm(d) === "absent" ? "" : `<circle class="sig" cx="${x}" cy="${y}" r="3.6" fill="${col(d)}"/>`);
    const lab = (d, x, y, t) => (arm(d) === "absent" ? "" : `<text x="${x}" y="${y}">${t}</text>`);
    return `<svg class="cross" viewBox="0 0 104 104" role="img" aria-label="Signal state">
      <rect x="40" y="${top}" width="24" height="${104 - top}" fill="#18202b"/><rect x="${left}" y="40" width="${104 - left}" height="24" fill="#18202b"/>
      <path d="M52 ${top}V40M52 64V104M${left} 52H40M64 52H104" stroke="#3b475a" stroke-dasharray="3 3"/>
      ${it.has_data ? bar("N", 41, 38, 10, 0) + bar("S", 53, 66, 10, 0) + bar("E", 66, 41, 0, 10) + bar("W", 38, 53, 0, 10) : ""}
      ${head("N", 35, 36)}${head("S", 69, 68)}${head("E", 69, 36)}${head("W", 35, 68)}
      <g fill="#6c788a" font-size="8.5" text-anchor="middle">${lab("N", 52, 8, "N")}${lab("S", 52, 102, "S")}${lab("E", 99, 55, "E")}${lab("W", 5, 55, "W")}</g></svg>`;
  }
  function headerChips(it) {
    if (!it.has_data) return `<span class="chip">No data yet</span>`;
    const lv = levelOf(it.queue_total);
    return `<span class="chip ${lv}" title="Queue \u22647 flowing, 8\u201317 moderate, \u226518 congested (dashboard thresholds)">${LEVEL_TEXT[lv].toUpperCase()}</span>`;
  }
  function rIpanel(el) {
    const k = el.dataset.i, it = inter(k); if (!it) return;
    el.classList.toggle("sel", TD.sel === k);
    const d = it.decision;
    setHtml(el, `<div class="panel-h"><h3>${NAMES[k]}</h3><div class="hdr-chips">${headerChips(it)}${it.has_data ? chipFor(d) : ""}</div></div>
      <div class="body">${crossSvg(it)}<dl class="kv">
        <dt>Signal</dt><dd>${esc(it.has_data ? sigText(it.signal, it.arms) : "\u2014")}</dd>
        <dt>Queue</dt><dd>${it.has_data ? it.queue_total + " veh" : "\u2014"}</dd>
        <dt>Waiting</dt><dd>${it.has_data ? fmt.n(it.waiting_time) + " s" : "\u2014"}</dd>
        <dt>Avg speed</dt><dd>${it.has_data ? fmt.n(it.speed_avg) + " km/h" : "\u2014"}</dd>
        <dt>Density</dt><dd>${it.has_data ? fmt.n(it.density, 0) + " %" : "\u2014"}</dd>
        <dt>Reward</dt><dd title="1 \u2212 queue/100, computed by the dashboard">${it.has_data ? fmt.n(it.reward, 2) : "\u2014"}</dd></dl></div>`);
  }
  const DCOL = { N: "#5aa9ff", S: "#2f6fb8", E: "#9ccbff", W: "#4a5f7a" };
  function donut(it) {
    const tot = DIRS.reduce((a, d) => a + it.queues[d], 0), R = 34, C = 2 * Math.PI * R;
    let off = 0, segs = "";
    if (it.has_data && tot) DIRS.forEach(d => { const f = it.queues[d] / tot * C; if (f > 0) { segs += `<circle cx="50" cy="50" r="${R}" fill="none" stroke="${DCOL[d]}" stroke-width="12" stroke-dasharray="${f} ${C - f}" stroke-dashoffset="${-off}" transform="rotate(-90 50 50)"/>`; off += f; } });
    return `<svg viewBox="0 0 100 100" role="img" aria-label="Queue share by approach"><circle cx="50" cy="50" r="${R}" fill="none" stroke="#23272c" stroke-width="12"/>${segs}<text x="50" y="49" text-anchor="middle" font-size="19">${it.has_data ? tot : "\u2014"}</text><text x="50" y="63" text-anchor="middle" font-size="8.5" style="fill:#666e77;font-weight:400">queued</text></svg>`;
  }
  const armOf = (it, d) => (it.arms && it.arms[d]) || "signal";
  function armLabel(it, g) {
    return (g === "NS" ? ["N", "S"] : ["E", "W"]).filter(d => armOf(it, d) !== "absent").map(d => d + (armOf(it, d) === "free" ? "*" : "")).join("/");
  }
  function freeNote(it) {
    const f = DIRS.filter(d => armOf(it, d) === "free"), n = DIRS.filter(d => armOf(it, d) === "absent"), fl = it.free_lanes || {};
    const t = [];
    Object.keys(fl).forEach(d => t.push(`${DIR_NAME[d]} approach, outer lane (${fl[d].movement}): always go, not controlled by SAC`));
    if (f.length) t.push(f.map(d => DIR_NAME[d]).join(", ") + " approach: always go (no signal, not controlled by SAC)");
    if (n.length) t.push(n.map(d => DIR_NAME[d]).join(", ") + ": no road (T-junction)");
    return t.length ? `<div class="hint" style="margin-bottom:.2rem">* ${esc(t.join(". "))}.</div>` : "";
  }
  function light(g, st) { return `<div class="light ${st}"><div class="case"><i></i><i></i><i></i></div>${g}</div>`; }
  function rIdetail(el) {
    const k = el.dataset.i, it = inter(k), s = TD.state; if (!it) return;
    const sg = it.signal, st = g => (it.has_data ? sg[g] : "-");
    const order = sg.green === "EW" || (sg.EW === "Y") ? ["EW", "NS"] : ["NS", "EW"];
    const word = g => ({ G: "green", Y: "yellow", R: "red" }[st(g)] || "\u2014");
    const rem = !it.has_data ? "\u2014" : sg.remaining != null ? fmt.n(sg.remaining, 0) + " s" : s.mode === "sac" ? "Set by SAC" : "\u2014";
    const d = it.decision;
    setHtml(el, `<div class="panel-h"><h3>${NAMES[k]}</h3><div class="hdr-chips">${headerChips(it)}${it.has_data ? chipFor(d) : ""}</div></div>
      <div class="body"><div class="top">
        <div class="lights">${light(armLabel(it, "NS"), st("NS"))}${light(armLabel(it, "EW"), st("EW"))}</div>
        <div class="sigline">${order.map(g => `<span class="${st(g)}"><i></i>${gname(it.arms, g)} ${word(g)}</span>`).join("")}</div>
        ${crossSvg(it).replace('class="cross"', 'class="cross" style="margin-left:auto"')}
      </div>
      <div class="grid-kv">
        <div><small>Next change in</small><b>${rem}</b></div><div><small>Queue length</small><b>${it.has_data ? it.queue_total + " veh" : "\u2014"}</b></div>
        <div><small>Waiting time</small><b>${it.has_data ? fmt.n(it.waiting_time) + " s" : "\u2014"}</b></div><div><small>Average speed</small><b>${it.has_data ? fmt.n(it.speed_avg) + " km/h" : "\u2014"}</b></div>
        <div><small>Traffic density</small><b>${it.has_data ? fmt.n(it.density, 0) + " %" : "\u2014"}</b></div><div><small>Reward</small><b title="1 \u2212 queue/100, computed by the dashboard">${it.has_data ? fmt.n(it.reward, 2) : "\u2014"}</b></div>
      </div>
      <div class="node"><h4>Queue by approach</h4><div class="donutbox">${donut(it)}<div>${DIRS.filter(x => armOf(it, x) !== "absent").map(x => qrow(x, it.queues[x], it.has_data)).join("")}</div></div></div>
      ${freeNote(it)}<div class="hint">${d ? esc(d.reason) : "Waiting for simulation data."}</div></div>`);
  }
  const qrow = (d, q, has) => `<div class="qrow"><span>${d}</span><div class="qbar"><i class="${apLevel(q)}" style="width:${has ? Math.min(100, q / 14 * 100) : 0}%"></i></div><em>${has ? q : "\u2014"}</em></div>`;

  /* ---------- SAC flow ---------- */
  function flowHtml(k, compact) {
    const it = inter(k), s = TD.state; if (!it) return "";
    if (!it.has_data) return `<div class="empty">${started() ? "No traffic light matched for " + NAMES[k] + " in the SUMO network." : "Waiting for simulation data. Press Run."}</div>`;
    const d = it.decision || {}, fixed = s.mode === "fixed", loaded = s.sac.loaded;
    if (compact === 2) {
      const mi = DIRS.filter(x => armOf(it, x) !== "absent").map(x => `<div class="${apLevel(it.queues[x])}"><small>${x}</small><b>${it.queues[x]}</b></div>`).join("");
      return `<div class="mini"><div class="mini-in" style="grid-template-columns:repeat(${DIRS.filter(x => armOf(it, x) !== "absent").length},1fr)" title="Queue per approach (model input)">${mi}</div><span class="arrow">&rarr;</span><span class="mini-model ${fixed ? "dimmed" : ""}" title="${loaded ? "Trained SAC model" : "Fallback rule, not SAC"}">${fixed ? "FIXED" : loaded ? "SAC" : "RULE"}</span><span class="arrow">&rarr;</span><div class="mini-out"><div class="act" style="${fixed ? "color:var(--dim)" : ""}">${esc(d.action || "\u2014")}</div><small>${esc(sigText(it.signal, it.arms))}</small></div></div><div class="mini-why">${esc(d.reason || "")}${!fixed && !loaded ? " (fallback rule, not a trained SAC model)" : ""}</div>`;
    }
    const input = `<div class="node"><h4>Model input &middot; traffic state</h4>${DIRS.filter(x => armOf(it, x) !== "absent").map(x => qrow(x, it.queues[x], true).replace(`<span>${x}</span>`, `<span title="${DIR_NAME[x]} queue">${x}</span>`)).join("")}<div class="phase-line"><span>Current phase</span><b>${esc(sigText(it.signal, it.arms))}</b></div></div>`;
    const model = `<div class="node model ${fixed ? "dimmed" : ""}"><b>SAC</b><small>${fixed ? "bypassed (Fixed-Time mode)" : loaded ? "trained model" : "fallback rule, no model file"}</small>${fixed ? "" : `<span class="chip ${loaded ? "ml solid" : "warn"}" style="margin-top:.4rem">${loaded ? "TRAINED" : "NOT SAC"}</span>`}</div>`;
    const rec = d.recommended ? `Model favours ${gname(it.arms, d.recommended)}.` : "";
    const dec = `<div class="node decision"><h4>Decision &middot; signal action</h4><div class="act ${fixed ? "" : "ml"}" data-act>${esc(d.action || "\u2014")}</div><div class="why">${esc(d.reason || "")} ${rec}</div>
      <div class="meta"><span title="1 \u2212 queue/100, computed by the dashboard">Reward <b>${fmt.n(it.reward, 2)}</b></span><span title="The controller returns an action only; no confidence value is available">Confidence <b>n/a</b></span></div></div>`;
    return `<div class="flow ${compact ? "compact" : ""}">${input}<div class="arrow">&rarr;</div>${model}<div class="arrow">&rarr;</div>${dec}</div>`;
  }
  function rFlow(el) { const k = selKey(el); setHtml(el, flowHtml(k, false)); }
  function rFlowpanel(el) {
    const k = el.dataset.i, it = inter(k); if (!it) return;
    setHtml(el, `<div class="flow-title"><span>${NAMES[k]}</span><span class="hdr-chips">${headerChips(it)}</span></div><div class="panel-b">${flowHtml(k, el.dataset.compact === "2" ? 2 : true)}</div>`);
    const a = el.querySelector("[data-act]");
    if (a) { const prev = el._act; if (prev && prev !== a.textContent && TD.state.mode === "sac") { a.classList.add("flash-ml"); } el._act = a.textContent; }
  }
  const ABBR = { sacop: "SA", del_rosario: "DR" };
  function rSelnav(el) {
    setHtml(el, KEYS.map(k => { const it = inter(k), lv = it && it.has_data ? levelOf(it.queue_total) : "";
      return `<button class="selrow" data-selk="${k}" aria-pressed="${TD.sel === k}" title="${NAMES[k]}"><span class="dot ${lv}"></span><span class="ab">${ABBR[k]}</span><span class="nm">${NAMES[k]}</span><em>${it && it.has_data ? "Q " + it.queue_total : ""}</em></button>`; }).join(""));
  }
  function rSelector(el) {
    setHtml(el, KEYS.map(k => `<button data-selk="${k}" aria-pressed="${TD.sel === k}">${NAMES[k]}</button>`).join(""));
  }
  function rObs(el) {
    const it = inter(TD.sel), v = it && it.model_input && it.model_input.vector;
    setHtml(el, v ? `Input vector [N, S, E, W, phase] = [${v.join(", ")}] &nbsp;<span class="mute">phase 0 = North-South green, 1 = otherwise</span>` : "Model input vector appears once the simulation runs.");
  }
  function rChain(el) {
    const k = selKey(el), it = inter(k), s = TD.state; if (!it) return;
    if (!it.has_data) { setHtml(el, `<div class="empty">Waiting for simulation data.</div>`); return; }
    const d = it.decision || {}, q = it.queues, key = k + "_queue", h = s.history;
    let trend = "observing\u2026";
    const old = [...h].reverse().find(r => r.time <= s.time - 10 && r[key] != null);
    if (old) { const df = it.queue_total - old[key]; trend = (df > 0 ? "+" : df < 0 ? "\u2212" : "\u00b1") + Math.abs(df) + " vs 10 s ago"; }
    const fixed = s.mode === "fixed";
    setHtml(el, `<div class="chain">
      <div class="step"><h4>Input &middot; traffic state</h4><b>Queues N${q.N} S${q.S} E${q.E} W${q.W}</b><p>Phase: ${esc(sigText(it.signal, it.arms))}</p></div>
      <div class="step ml"><h4>SAC model</h4><b>${fixed ? "Bypassed" : s.sac.loaded ? "Trained policy" : "Fallback rule"}</b><p>${fixed ? "Fixed-Time mode" : esc(s.sac.backend)}</p></div>
      <div class="step"><h4>Output &middot; signal action</h4><b>${esc(d.action || "\u2014")}</b><p>${esc(d.recommended ? "Favours " + gname(it.arms, d.recommended) : fixed ? "Timer decides" : "")}</p></div>
      <div class="step"><h4>Traffic light</h4><b>${esc(sigText(it.signal, it.arms))}</b><p>${it.signal.remaining != null ? fmt.n(it.signal.remaining, 0) + " s to next change" : "Switch time set by controller"}</p></div>
      <div class="step"><h4>New traffic state</h4><b>Queue ${it.queue_total} veh</b><p>${trend}</p></div></div>
      <div class="loopback">&#8634; the new traffic state is the next model input</div>`);
  }
  function rCtlinfo(el) {
    const s = TD.state, m = s.sac;
    setHtml(el, `<dl class="kv"><dt>Policy</dt><dd>${m.loaded ? "Trained SAC" : "Fallback rule"}</dd><dt>Backend</dt><dd title="${esc(m.backend)}">${esc(m.backend)}</dd>
      <dt>Active mode</dt><dd>${s.mode === "sac" ? "SAC" : "Fixed-Time"}</dd><dt>Data source</dt><dd>${!started() ? "none yet" : s.data_source === "sumo" ? "SUMO" : "demo model"}</dd></dl>
      <div class="obs mono" style="white-space:normal">${esc(m.model_path)}</div>
      ${m.loaded ? "" : `<p class="hint" style="margin:.6rem 0 0">No trained model file found. SAC mode currently runs a largest-queue-first rule so the interface can be tested. It is not a SAC prediction. Put <b>sac_controller.zip</b> in ml/models/ to use the trained policy.</p>`}`);
  }
  function rDecisions(el) {
    const s = TD.state, rows = s.decisions.slice(0, 9);
    if (!rows.length) { setHtml(el, `<div class="empty">${s.mode === "fixed" ? "Fixed-Time mode makes no SAC decisions." : "No decisions yet. Run the simulation."}</div>`); return; }
    setHtml(el, `<table><thead><tr><th>Time</th><th>Junction</th><th>Action</th></tr></thead><tbody>${rows.map(r => `<tr title="${esc(r.reason)}"><td class="mono">${fmt.time(r.time)}</td><td>${esc(r.intersection)}</td><td><span class="chip ml">${esc(r.action)}</span>${r.recommended ? ` <span class="mute">${r.recommended}</span>` : ""}</td></tr>`).join("")}</tbody></table>`);
  }

  /* ---------- comparison ---------- */
  function cmp() {
    const c = TD.state.comparison, ok = !!(c.fixed && c.sac && c.fixed.seconds >= 20 && c.sac.seconds >= 20);
    let better = 0, worse = 0;
    const rows = CMP.map(r => {
      const f = c.fixed ? c.fixed[r.k] : null, a = c.sac ? c.sac[r.k] : null;
      let pct = null, cls = "same";
      if (ok && f != null && a != null && f !== 0) {
        pct = (a - f) / f * 100;
        const imp = r.better === "lower" ? pct < 0 : pct > 0;
        if (Math.abs(pct) >= 1) { cls = imp ? "good" : "bad"; imp ? better++ : worse++; }
      }
      return { ...r, f, a, pct, cls };
    });
    return { c, ok, rows, better, worse };
  }
  const val = (v, r) => (v == null ? "\u2014" : fmt.n(v, r.d) + " " + r.unit);
  function rCmpsub(el) {
    const c = TD.state.comparison;
    el.textContent = (c.source === "sumo" ? "SUMO runs" : "demo model runs") + " \u00b7 " + c.scenario;
  }
  function incompleteMsg(c) {
    const f = c.fixed ? c.fixed.seconds + " s recorded" : "not run", a = c.sac ? c.sac.seconds + " s recorded" : "not run";
    return `Fixed-Time: ${f} &middot; SAC: ${a}. Run each mode in the same scenario (Reset between runs) to compare. Needs 20 s or more per mode.`;
  }
  function rTiles(el) {
    const d = cmp();
    setHtml(el, `<div class="tiles">${d.rows.map(r => `<div class="tile ${r.cls}"><small>${r.label}</small><div class="from">${d.ok ? `${val(r.f, r)} \u2192 ${val(r.a, r)}` : `Fixed ${val(r.f, r)} \u00b7 SAC ${val(r.a, r)}`}</div><b>${r.pct == null ? "\u2014" : fmt.pct(r.pct)}</b></div>`).join("")}</div>${d.ok ? "" : `<div class="cmp-note">${incompleteMsg(d.c)}</div>`}`);
  }
  function rCompare(el) {
    const d = cmp(), c = d.c;
    const verdict = !d.ok ? `<span class="chip">INCOMPLETE</span><b class="dim">Waiting for both runs</b>`
      : d.better > d.worse ? `<span class="chip ml solid">SAC AHEAD</span><b>SAC is better on ${d.better} of 4 metrics</b>`
      : d.worse > d.better ? `<span class="chip warn">FIXED-TIME AHEAD</span><b>Fixed-Time is better on ${d.worse} of 4 metrics</b>`
      : `<span class="chip">LEVEL</span><b>No clear difference between controllers</b>`;
    const bars = (r) => { const m = Math.max(r.f || 0, r.a || 0) || 1; return `<div class="cmp-bars"><div class="cmp-bar fx"><div class="track"><i style="width:${r.f == null ? 0 : r.f / m * 100}%"></i></div><span>${val(r.f, r)}</span></div><div class="cmp-bar sc"><div class="track"><i style="width:${r.a == null ? 0 : r.a / m * 100}%"></i></div><span>${val(r.a, r)}</span></div></div>`; };
    const diff = d.ok && Math.abs(c.fixed.seconds - c.sac.seconds) / Math.max(c.fixed.seconds, c.sac.seconds) > 0.2;
    setHtml(el, `<div class="cmp-verdict">${verdict}</div>
      <div class="cmp-head"><span></span><span class="legend"><span><i style="background:#7c8798"></i>Fixed-Time</span><span><i style="background:#5aa9ff"></i>SAC</span></span><span style="text-align:right">Change with SAC</span></div>
      ${d.rows.map(r => `<div class="cmp-row"><div class="name"><b>${r.label}</b><small>${r.hint}</small></div>${bars(r)}<div class="delta ${r.cls}"><b>${r.pct == null ? "\u2014" : fmt.pct(r.pct)}</b><small>${r.better} is better</small></div></div>`).join("")}
      <div class="cmp-note"><span>${d.ok ? `Averages over each run: Fixed-Time ${c.fixed.seconds} s, SAC ${c.sac.seconds} s.${diff ? " Run lengths differ by more than 20%, so treat the comparison with care." : ""}` : incompleteMsg(c)}</span><span style="margin-left:auto"><button class="btn ghost" data-act="clear">Clear comparison</button></span></div>`);
  }

  /* ---------- charts ---------- */
  const SERIES = {
    waiting: { net: "waiting_time", sacop: "sacop_waiting", del_rosario: "del_rosario_waiting", color: "#e8b34a", unit: " s" },
    queue: { net: "queue_length", sacop: "sacop_queue", del_rosario: "del_rosario_queue", color: "#d9dee7", unit: " veh", dec: 0 },
    reward: { net: "reward", color: "#5aa9ff", unit: "", dec: 2, max: 1 },
    throughput: { net: "throughput", color: "#3ecf8e", unit: " veh", dec: 0 },
  };
  function rChart(cv) {
    const sp = SERIES[cv.dataset.chart], sc = cv.dataset.scope === "auto" ? TD.scope : cv.dataset.scope;
    Charts.hover(cv);
    Charts.draw(cv, { rows: TD.state.history, key: sp[sc] || sp.net, color: sp.color, unit: sp.unit, dec: sp.dec, min: sp.min, max: sp.max });
  }

  /* ---------- chrome ---------- */
  function badge(el, cls, text) { el.className = "badge " + cls; el.lastElementChild.textContent = text; }
  function chrome(s) {
    const on = started(), run = s.running && !s.paused;
    const chip = $("#runChip"); chip.className = "run-chip " + (run ? "running" : s.running ? "paused" : ""); chip.lastElementChild.textContent = run ? "RUNNING" : s.running ? "PAUSED" : "STOPPED";
    $("#clock").textContent = fmt.time(s.time);
    $$("#speedSeg button").forEach(b => b.setAttribute("aria-pressed", String(+b.dataset.v === s.speed)));
    $$("#modeSeg button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.mode === s.mode)));
    const sel = $("#scenarioSel"); if (document.activeElement !== sel) sel.value = s.scenario;
    const bRun = $("#btnRun"); bRun.disabled = run; bRun.lastElementChild.textContent = s.running && s.paused ? "Resume" : "Run";
    $("#btnPause").disabled = !run; $("#btnReset").disabled = !on;
    badge($("#srcBadge"), !on ? "" : s.data_source === "sumo" ? "ok" : "warn", !on ? "Idle" : s.data_source === "sumo" ? "SUMO live data" : "Demo data, not SUMO");
    badge($("#sacBadge"), s.mode === "fixed" ? "" : s.sac.loaded ? "ml" : "warn", s.mode === "fixed" ? "Fixed-Time control" : s.sac.loaded ? "SAC model loaded" : "SAC: fallback rule");
    const n = $("#notice"); let msg = "", bad = false;
    if (on && !s.connected) msg = "Demo data from a simple queueing model, not SUMO." + (s.error ? " SUMO did not start: " + s.error.split(/\. |\n/)[0] + "." : "");
    else if (s.error) { msg = s.error; bad = true; }
    if (on && s.mode === "sac" && !s.sac.loaded) msg += (msg ? " " : "") + "SAC mode uses a largest-queue rule: no trained model loaded.";
    n.hidden = !msg; n.textContent = msg; n.classList.toggle("bad", bad);
    const st = (cls, name, v) => `<span class="${cls}"><i></i>${name} <b>${v}</b></span>`;
    const sys = s.system;
    $("#statusbar").innerHTML = [
      st(sys.sumo_connected ? "on" : "off", "SUMO", sys.sumo_connected ? "Connected" : "Disconnected"),
      st(sys.traci_connected ? "on" : "off", "TraCI", sys.traci_connected ? "Connected" : sys.traci_installed ? "Disconnected" : "Not installed"),
      st(s.sac.loaded ? "on" : "warn", "SAC model", s.sac.loaded ? "Loaded" : "Not loaded"),
      st(TD.ws ? "on" : "off", "WebSocket", TD.ws ? "Connected" : "Disconnected (polling)"),
      st(run ? "on" : s.running ? "warn" : "", "Simulation", run ? "Running" : s.running ? "Paused" : "Stopped"),
      `<span class="sp">UI v2 &middot; Data: <b>${!on ? "none yet" : s.data_source === "sumo" ? "SUMO" : "demo model"}</b></span>`,
    ].join("");
  }

  const R = { results: el => window.renderResults && window.renderResults(el), selnav: rSelnav, metrics: rMetrics, ipanel: rIpanel, idetail: rIdetail, flow: rFlow, flowpanel: rFlowpanel, selector: rSelector, obs: rObs, chain: rChain, ctlinfo: rCtlinfo, decisions: rDecisions, tiles: rTiles, compare: rCompare, cmpsub: rCmpsub };
  window.renderAll = function () {
    const s = TD.state; if (!s) return;
    chrome(s);
    $$("[data-r]").forEach(el => { if (el.offsetParent !== null && R[el.dataset.r]) R[el.dataset.r](el); });
    $$("canvas[data-chart]").forEach(cv => { if (cv.offsetParent !== null) rChart(cv); });
  };
})();
