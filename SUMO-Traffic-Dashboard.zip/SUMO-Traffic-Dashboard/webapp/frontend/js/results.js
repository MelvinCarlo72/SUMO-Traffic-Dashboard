/* Results page: offline SACOP thesis evaluation (Fixed-time vs DQN vs DDQN) + observed demand + data checks.
   Every value comes from /api/results/sacop (built from the thesis files); nothing is computed beyond sums/ratios. */
(function () {
  const C = { fixed: "Fixed-time", dqn: "DQN", ddqn: "DDQN" };
  const int = v => (v == null ? "\u2014" : Math.round(v).toLocaleString("en-US"));
  const pct = (a, b) => (b ? (a - b) / b * 100 : null);
  const dl = p => (p == null ? "" : `<span class="d ${p < -0.5 ? "good" : p > 0.5 ? "bad" : "same"}">${p > 0 ? "+" : p < 0 ? "\u2212" : ""}${Math.abs(p).toFixed(1)}%</span>`);
  const bar = (v, max, cls, label) => `<div class="rb ${cls}"><div class="track"><i style="width:${max ? Math.max(1, v / max * 100) : 0}%"></i></div><span>${label}</span></div>`;
  const dayLabel = w => `${w.weekday.slice(0, 3)} ${w.date.slice(8)} ${["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][+w.date.slice(5, 7)]}`;

  function load() {
    if (TD.results || TD.resultsLoading) return;
    TD.resultsLoading = true;
    fetch("/api/results/sacop").then(r => (r.ok ? r.json() : Promise.reject())).then(d => { TD.results = d; }).catch(() => { TD.results = { available: false }; }).finally(() => { TD.resultsLoading = false; renderAll(); });
  }

  window.renderResults = function (el) {
    const d = TD.results;
    if (!d) { load(); el.innerHTML = '<div class="panel"><div class="empty">Loading thesis results\u2026</div></div>'; el._h = null; return; }
    if (d.available === false) { el.innerHTML = '<div class="panel"><div class="empty">No SACOP results found. Run <b>python tools/build_sacop_results.py</b> after placing the files in data/sacop.</div></div>'; return; }
    const S = Object.fromEntries(d.summary.map(r => [r.controller, r])), fx = S["Fixed-time"], dq = S["DQN"], dd = S["DDQN"];
    const maxW = Math.max(fx.total_wait_vehicle_seconds, dq.total_wait_vehicle_seconds, dd.total_wait_vehicle_seconds);
    const maxQ = Math.max(fx.mean_queue_vehicles, dq.mean_queue_vehicles, dd.mean_queue_vehicles);
    const best = [dq, dd].sort((a, b) => b.wait_reduction_vs_fixed_percent - a.wait_reduction_vs_fixed_percent)[0];
    const card = (s, cls) => `<div class="panel res-kpi ${cls}"><div class="k">${s.controller}<small>${s.seeds} seed${s.seeds > 1 ? "s" : ""}${s.controller === "Fixed-time" ? ", baseline" : ", mean"}</small></div>
      <div class="v">${int(s.total_wait_vehicle_seconds)}<u>veh\u00b7s</u></div>
      <div class="r">${s.controller === "Fixed-time" ? '<span class="d same">baseline</span>' : dl(-s.wait_reduction_vs_fixed_percent)} <small>total wait</small></div>
      <div class="m"><span>Mean queue <b>${s.mean_queue_vehicles.toFixed(2)}</b></span><span>Arrived <b>${int(s.arrived)}/${int(s.scheduled)}</b></span><span>Collisions <b>${s.max_collisions}</b></span><span>Teleports <b>${s.max_teleports}</b></span></div></div>`;
    const pwMax = Math.max(...d.per_window.flatMap(w => [w.fixed.wait, w.dqn.wait, w.ddqn.wait]));
    const pw = d.per_window.map(w => `<tr><td><b>${dayLabel(w)}</b><small>${w.time} &middot; ${int(w.scheduled)} veh</small></td><td class="bars">
      ${bar(w.fixed.wait, pwMax, "fixed", int(w.fixed.wait))}${bar(w.dqn.wait, pwMax, "dqn", int(w.dqn.wait) + " " + dl(pct(w.dqn.wait, w.fixed.wait)))}${bar(w.ddqn.wait, pwMax, "ddqn", int(w.ddqn.wait) + " " + dl(pct(w.ddqn.wait, w.fixed.wait)))}</td></tr>`).join("");
    const seeds = d.per_seed.map(r => `<tr><td>${r.controller}</td><td class="num">${r.seed}</td><td class="num">${r.selected_cycle}</td><td class="num">${dl(-r.wait_reduction_percent)}</td><td class="num">${r.improved_windows}/8</td><td class="num">${r.mean_queue.toFixed(2)}</td><td class="num">${r.collisions}/${r.teleports}</td></tr>`).join("");
    // observed demand
    const dw = d.demand.windows, sel = TD.dwin != null && dw[+TD.dwin] ? +TD.dwin : dw.length - 2, cur = dw[sel];
    const mvMax = Math.max(...Object.values(cur.movements), 1);
    const mvRows = d.movements.map(m => { const id = m.id.split("_")[1], ctl = d.demand.control_type[id]; return `<div class="mv"><div class="n"><b>${m.label}</b> ${m.origin} \u2192 ${m.destination} <small>${m.turn}</small>${ctl === "UNCONTROLLED" ? ' <span class="chip free">ALWAYS GO</span>' : ""}</div>${bar(cur.movements[id], mvMax, "dqn", int(cur.movements[id]))}</div>`; }).join("");
    const opts = dw.map((w, i) => `<option value="${i}" ${i === sel ? "selected" : ""}>${dayLabel(w)} ${w.time}</option>`).join("");
    const v = d.validation;
    const tile = (k, val, sub) => `<div class="tile"><small>${k}</small><b style="font-size:1.4rem">${val}</b><div class="from">${sub}</div></div>`;
    el.innerHTML = `<div class="res">
      <div class="res-banner"><b>Offline SUMO evaluation &middot; ${d.site}</b> &middot; ${d.per_window.length} demand windows, ${d.per_window[0].date.slice(8)}\u2013${d.per_window[d.per_window.length - 1].date.slice(8)} Sep 2026 &middot; not a live run <span class="chip warn">Controllers evaluated: DQN and DDQN</span></div>
      <div class="grid-3">${card(fx, "fixed")}${card(dq, "dqn")}${card(dd, "ddqn")}</div>
      <div class="panel"><div class="cmp-verdict"><span class="chip ml solid">RESULT</span><b>${best.controller} cut total waiting time by ${best.wait_reduction_vs_fixed_percent.toFixed(1)}% vs fixed-time</b><span class="mute">(DQN ${dq.wait_reduction_vs_fixed_percent.toFixed(1)}%, DDQN ${dd.wait_reduction_vs_fixed_percent.toFixed(1)}%, mean of 3 seeds; ${int(fx.arrived)} vehicles, no collisions or teleports)</span></div></div>
      <div class="grid-2">
        <div class="panel"><div class="panel-h"><h3>Total waiting time</h3><span class="sub">vehicle-seconds, all 8 windows (lower is better)</span></div><div class="panel-b">${bar(fx.total_wait_vehicle_seconds, maxW, "fixed", "Fixed-time " + int(fx.total_wait_vehicle_seconds))}${bar(dq.total_wait_vehicle_seconds, maxW, "dqn", "DQN " + int(dq.total_wait_vehicle_seconds))}${bar(dd.total_wait_vehicle_seconds, maxW, "ddqn", "DDQN " + int(dd.total_wait_vehicle_seconds))}</div></div>
        <div class="panel"><div class="panel-h"><h3>Mean approach queue</h3><span class="sub">vehicles (lower is better)</span></div><div class="panel-b">${bar(fx.mean_queue_vehicles, maxQ, "fixed", "Fixed-time " + fx.mean_queue_vehicles.toFixed(2))}${bar(dq.mean_queue_vehicles, maxQ, "dqn", "DQN " + dq.mean_queue_vehicles.toFixed(2))}${bar(dd.mean_queue_vehicles, maxQ, "ddqn", "DDQN " + dd.mean_queue_vehicles.toFixed(2))}</div></div>
      </div>
      <div class="panel"><div class="panel-h"><h3>Waiting time per window</h3><span class="sub legend"><span><i style="background:#7c8798"></i>Fixed-time</span><span><i style="background:#5aa9ff"></i>DQN</span><span><i style="background:#7ee0e8"></i>DDQN</span></span></div><table class="wt"><tbody>${pw}</tbody></table></div>
      <div class="grid-2">
        <div class="panel"><div class="panel-h"><h3>Results by seed</h3><span class="sub">wait change vs fixed-time</span></div><table><thead><tr><th>Controller</th><th class="num">Seed</th><th class="num">Cycle</th><th class="num">Wait</th><th class="num">Better in</th><th class="num">Queue</th><th class="num">Coll/tele</th></tr></thead><tbody>${seeds}</tbody></table></div>
        <div class="panel"><div class="panel-h"><h3>Observed demand (YOLO)</h3><select data-dwin style="min-width:12rem">${opts}</select></div><div class="panel-b"><div class="hint" style="margin-bottom:.5rem">${int(cur.total)} vehicles with a confirmed movement in this 30-minute window</div>${mvRows}</div></div>
      </div>
      <div class="grid-2">
        <div class="panel"><div class="panel-h"><h3>Count accuracy: YOLO vs manual</h3><span class="sub">${v.clip_count} one-minute clips</span></div><div class="tiles">
          ${tile("Pooled YOLO / manual", (v.pooled_count_ratio * 100).toFixed(1) + "%", int(v.yolo_confirmed_total) + " vs " + int(v.manual_total) + " vehicles")}
          ${tile("Count bias", (v.pooled_count_bias_fraction * 100).toFixed(1) + "%", "YOLO counts fewer vehicles")}
          ${tile("Error per clip", v.clip_total_mae_vehicles.toFixed(1) + " veh", "mean absolute (" + (v.clip_total_mape_fraction * 100).toFixed(1) + "% MAPE)")}
          ${tile("Per-movement error", (v.movement_cell_wape_fraction * 100).toFixed(1) + "%", "weighted absolute % error")}</div>
          <div class="cmp-note">Aggregate counts over three clips, not detection precision or recall. Observed demand above is therefore a lower bound.</div></div>
        <div class="panel"><div class="panel-h"><h3>Evaluation figure</h3><span class="sub">from the thesis run</span></div><div class="panel-b"><img class="fig" src="/data/sacop/evaluation/three_controller_comparison.png" alt="Three-controller comparison figure"></div></div>
      </div>
      <div class="panel"><div class="panel-h"><h3>Limits of these results</h3></div><div class="panel-b"><ul class="notes">${d.notes.map(n => `<li>${n}</li>`).join("")}</ul></div></div></div>`;
  };
})();
