/* Wiring: controls, navigation, presentation mode, animation loop. */
(function () {
  const traffic = new Traffic();
  const views = $$("[data-sim]").map(el => new SimView(el, traffic));

  TD.hooks.push(s => { if (!s) return; traffic.sync(s); renderAll(); views.forEach(v => v.updateText()); });

  /* controls */
  $("#btnRun").onclick = () => post("run");
  $("#btnPause").onclick = () => post("pause");
  $("#btnReset").onclick = () => post("reset");
  $$("#speedSeg button").forEach(b => (b.onclick = () => post("speed/" + b.dataset.v)));
  $$("#modeSeg button").forEach(b => (b.onclick = () => post("mode/" + b.dataset.mode)));
  $("#scenarioSel").onchange = e => post("scenario/" + encodeURIComponent(e.target.value.replace(/ /g, "_")));

  /* navigation */
  function showPage(p) {
    TD.page = p; document.body.dataset.page = p; const cr = $("#crumb"); if (cr) cr.textContent = ({ overview: "Overview", live: "Live simulation", controller: "SAC controller", intersections: "Intersections", analytics: "Analytics", results: "Thesis results" })[p];
    $$(".tab").forEach(t => t.setAttribute("aria-selected", String(t.dataset.page === p)));
    $$(".page").forEach(x => x.classList.toggle("active", x.id === "page-" + p));
    $("#main").scrollTop = 0; renderAll(); views.forEach(v => v.updateText());
  }
  $$(".tab").forEach(t => (t.onclick = () => showPage(t.dataset.page)));

  /* presentation mode */
  function setPres(on) {
    if (window.pywebview && pywebview.api && pywebview.api.set_fullscreen) pywebview.api.set_fullscreen(on);
    TD.pres = on; document.body.classList.toggle("presenting", on); $("#main").scrollTop = 0;
    $("#presBtn").textContent = on ? "Exit presentation" : "Present";
    if (on) { $$(".page").forEach(x => x.classList.remove("active")); $("#page-present").classList.add("active"); try { if (!window.pywebview) document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); } catch (e) {} }
    else { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); showPage(TD.page); return; }
    renderAll(); views.forEach(v => v.updateText());
  }
  $("#presBtn").onclick = () => setPres(!TD.pres);
  document.addEventListener("fullscreenchange", () => { if (!document.fullscreenElement && TD.pres) setPres(false); });
  document.addEventListener("keydown", e => {
    if (/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if (e.key === "p" || e.key === "P") setPres(!TD.pres);
    else if (e.key === "Escape" && TD.pres) setPres(false);
    else if (e.key === " " && TD.state) { e.preventDefault(); const s = TD.state; post(s.running && !s.paused ? "pause" : "run"); }
  });

  /* delegated clicks inside rendered panels */
  document.addEventListener("click", e => {
    const sk = e.target.closest("[data-selk]"); if (sk) { TD.sel = sk.dataset.selk; renderAll(); views.forEach(v => v.updateText()); }
    const act = e.target.closest("[data-act='clear']"); if (act) post("comparison/clear");
  });
  document.addEventListener("change", e => { if (e.target.matches("[data-dwin]")) { TD.dwin = e.target.value; renderAll(); } });
  $$("#scopeTabs button").forEach(b => (b.onclick = () => { TD.scope = b.dataset.scope; $$("#scopeTabs button").forEach(x => x.setAttribute("aria-pressed", String(x === b))); renderAll(); }));

  const main = $("#main"), setAvail = () => document.documentElement.style.setProperty("--avail", main.clientHeight + "px");
  new ResizeObserver(() => { setAvail(); TD.state && renderAll(); }).observe(main); setAvail();
  window.addEventListener("resize", () => TD.state && renderAll());

  /* animation loop */
  let last = performance.now();
  (function frame(now) {
    const dt = (now - last) / 1000; last = now;
    traffic.step(dt);
    views.forEach(v => v.visible() && v.draw());
    requestAnimationFrame(frame);
  })(last);

  connectLive();
})();
