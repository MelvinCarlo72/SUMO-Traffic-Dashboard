/* Shared state, helpers, API + live connection (WebSocket with polling fallback). */
const TD = { state: null, sel: "sacop", scope: "net", ws: false, pres: false, page: "overview", hooks: [] };
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const KEYS = ["sacop", "del_rosario"];
const NAMES = { sacop: "SACOP", del_rosario: "Del Rosario" };
const GROUP_NAME = { NS: "North-South", EW: "East-West" };
const DIRS = ["N", "S", "E", "W"];
const DIR_NAME = { N: "North", S: "South", E: "East", W: "West" };

const fmt = {
  n: (v, d = 1) => (v == null || Number.isNaN(+v) ? "\u2014" : (+v).toFixed(d)),
  i: v => (v == null || Number.isNaN(+v) ? "\u2014" : String(Math.round(+v))),
  time: s => { s = Math.max(0, Math.floor(s || 0)); return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0"); },
  pct: p => (p > 0 ? "+" : p < 0 ? "\u2212" : "") + Math.abs(p).toFixed(1) + "%",
};
/* Dashboard thresholds for the traffic-state label (queue = halted vehicles at one junction). */
function levelOf(q) { return q < 8 ? "free" : q < 18 ? "moderate" : "congested"; }
const LEVEL_TEXT = { free: "Flowing", moderate: "Moderate", congested: "Congested" };
function inter(key) { return TD.state && TD.state.intersections.find(i => i.id === key); }
function started() { const s = TD.state; return !!s && (s.running || s.time > 0); }
/* Phase-group name using only the signalised arms that exist (a T-junction has no "North-South"). */
function gname(arms, g) {
  const dirs = (g === "NS" ? ["N", "S"] : ["E", "W"]).filter(d => !arms || (arms[d] || "signal") === "signal");
  return dirs.length === 1 ? DIR_NAME[dirs[0]] : GROUP_NAME[g];
}
function sigText(sig, arms) {
  if (!sig) return "\u2014";
  if (sig.green) return gname(arms, sig.green) + " green";
  const y = sig.NS === "Y" ? "NS" : sig.EW === "Y" ? "EW" : null;
  return y ? gname(arms, y) + " yellow" : "All red";
}
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

function applyState(s) {
  if (!s || !s.intersections) return;
  TD.state = s;
  TD.hooks.forEach(h => h(s));
}
function post(path) {
  return fetch("/api/" + path, { method: "POST" }).then(r => r.json()).then(applyState).catch(() => {});
}
function connectLive() {
  let poll = null;
  const startPoll = () => { if (!poll) poll = setInterval(() => fetch("/api/state").then(r => r.json()).then(applyState).catch(() => {}), 1000); };
  const stopPoll = () => { clearInterval(poll); poll = null; };
  const open = () => {
    let ws;
    try { ws = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws"); } catch (e) { startPoll(); return; }
    ws.onopen = () => { TD.ws = true; stopPoll(); TD.hooks.forEach(h => h(TD.state)); };
    ws.onmessage = e => applyState(JSON.parse(e.data));
    ws.onclose = () => { TD.ws = false; startPoll(); if (TD.state) TD.hooks.forEach(h => h(TD.state)); setTimeout(open, 1500); };
    ws.onerror = () => ws.close();
  };
  fetch("/api/state").then(r => r.json()).then(applyState).catch(() => {});
  open();
}
