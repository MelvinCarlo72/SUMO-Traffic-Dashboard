# SAC Traffic Optimization Dashboard

Scope: San Fernando, Pampanga — SACOP + Del Rosario.

## Run
Double-click `RUN_WEB.bat`, then open http://127.0.0.1:8000

## Real SUMO
Install SUMO and place the verified `scenario.sumocfg` and its referenced network/route files in `pipeline/06_simulation/`.

## Real SAC
Place a Stable-Baselines3 SAC model at `ml/models/sac_controller.zip`.
The dashboard automatically attempts to load it.

Until both are supplied, the UI runs a clearly-labeled demo fallback so the interface remains testable.

## Features
- SUMO/TraCI integration
- SAC model adapter
- Run/Pause/Resume/Reset
- SACOP + Del Rosario
- Live simulation visualization
- Traffic-light state
- SAC decision panel
- Fixed-Time vs SAC mode
- Live waiting/queue charts
- Scenario presets
- Model input/output panel
- Intersection cards
- Reward tracking
- CSV export
- Presentation-friendly dark UI
- Simulation speed controls
- Loading/error/status handling

## Frontend layout (webapp/frontend)
- `index.html` - page shell, controls, five pages + presentation mode
- `css/app.css` - design tokens and components (no external fonts or CDNs; works offline)
- `js/core.js` - shared state, API calls, WebSocket with polling fallback
- `js/traffic.js` - browser traffic view (schematic driven by live counts and signal state)
- `js/charts.js` - dependency-free line charts
- `js/render.js` - panels: metrics, intersections, SAC flow, comparison, status bar
- `js/app.js` - wiring, navigation, presentation mode (press P, Space = run/pause)

## Honest data labelling
- Header badge shows `SUMO live data` or `Demo data, not SUMO`.
- Without `ml/models/sac_controller.zip` the SAC panels say `RULE` / `NOT SAC` (largest-queue fallback).
- Confidence is shown as n/a: the controller returns an action only.
- Reward is a dashboard score (1 - queue/100), labelled as such.
- Fixed-Time vs SAC percentages appear only after both modes have run in the same scenario.

## Backend changes (webapp/backend)
- Per-intersection state: signal, queues by approach (N/S/E/W), waiting, speed, density, decision.
- Speed accepts 0.5; scenarios are Normal Traffic, Peak Hours, Traffic Incident.
- `/api/comparison/clear` added; CSV gained mode, scenario, data_source and per-intersection columns.
- Set `SACOP_TLS_ID` / `DEL_ROSARIO_TLS_ID` if the SUMO traffic-light IDs do not contain the intersection names.

## Visual system (v2)
- Accent `#5aa9ff` (blue) marks brand, active nav and ML/SAC information. Green/yellow/red are reserved for traffic state.
- Layout: left sidebar (collapses to icons below 1500 px), top bar with breadcrumb, controls card, KPI cards, right-hand decision feed on screens 1700 px and wider.
- KPI cards show a "vs Fixed-Time" delta only after both modes have run in the same scenario.

## Standalone desktop app
- `RUN_APP.bat` - runs the dashboard in its own window (no browser). Installs dependencies on first run.
- `BUILD_EXE.bat` - builds `dist\SUMO-Traffic-Dashboard\SUMO-Traffic-Dashboard.exe` with PyInstaller. Copy the whole folder to another PC; SUMO must be installed there.
- `ml\models\` and `pipeline\06_simulation\` are copied next to the exe and read from there, so you can drop in `sac_controller.zip` without rebuilding.
- To include the trained model in the build, `pip install stable-baselines3` in the project's `.venv` before running `BUILD_EXE.bat` (the exe becomes much larger because of PyTorch).
- Logs: `traffic_dashboard.log` next to the app. The window uses Edge WebView2 (preinstalled on Windows 10/11).
- `dashboard\RUN_DASHBOARD.bat` now calls `RUN_APP.bat`; the old Tkinter prototype is `dashboard\RUN_DESKTOP_PROTOTYPE.bat`.

## Road layout (SACOP / Del Rosario)
- SACOP is a T-junction (J02): arms Del Rosario (east), San Agustin (west), Makatao (south); no north arm.
- "Always go": in the SACOP YOLO movement data only M04 (San Agustin -> Makatao, right turn) is `UNCONTROLLED`. It is drawn as the west approach's outer lane with a green stop-line strip, never queues, and is not part of SAC's phase choice (`FREE_LANES` in `webapp/backend/simulation.py`; share 33% from the observed counts).
- SACOP's demo arrival mix uses the observed origin shares (East 39%, West 41%, South 20%).
- Edit `ARMS` / `FREE_LANES` in `webapp/backend/simulation.py` to change approach types; the UI follows automatically.
- Road-end labels are in `END_LABELS` in `webapp/frontend/js/traffic.js`.
- The SAC input vector keeps the 5 values [N, S, E, W, phase]; a missing north arm is always 0.

## SACOP thesis data (data/sacop)
- Imported from `SACOP-...zip`: offline SUMO evaluation (Fixed-time vs DQN vs DDQN), seed summaries, YOLO movement counts for 24 windows, manual count check, training histories.
- The **Results** page reads `data/sacop/results.json`, built by `python tools/build_sacop_results.py` (re-run after replacing files).
- Not copied (too large / not used by the app): the six `best.pt` checkpoints, per-episode training CSVs, per-window YOLO folders. Keep the original zip.
- The evaluated controllers are **DQN and DDQN**; the data contains no SAC results.
