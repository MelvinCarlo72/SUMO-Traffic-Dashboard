NOTE: RUN_DASHBOARD.bat now starts the web dashboard (webapp/) and opens it in the browser.
The original Tkinter prototype (sample data only) is RUN_DESKTOP_PROTOTYPE.bat.

SUMO Traffic Dashboard — Modular Build

Run:
    python sumo_dashboard.py

Files:
    sumo_dashboard.py          Entry point
    dashboard.py               Tkinter UI
    data_provider.py           Provider interface + data models
    prototype_data_provider.py Draft/presentation sample data
    sumo_data_provider.py      SUMO/TraCI provider
    config.py                  Project configuration

Draft:
    Uses PrototypeDataProvider.
    Values are simulated/sample values.

Final:
    Build the final provider separately, then change the provider imported in
    sumo_dashboard.py. The dashboard UI should not need major changes.

SUMO IDs:
    Add final traffic-light IDs to TLS_IDS in config.py.
