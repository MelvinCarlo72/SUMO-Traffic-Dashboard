import random

from data_provider import (
    DataProvider,
    NetworkMetrics,
    ComparisonMetrics,
    IntersectionMetrics,
    ControllerState,
)


class PrototypeDataProvider(DataProvider):
    SCENARIO_METRICS = {
        "Normal Traffic": NetworkMetrics(
            vehicles=160, waiting_time=29.4, queue_length=5.2,
            throughput=980, delay=12.1, density=42
        ),
        "Peak Hours": NetworkMetrics(
            vehicles=247, waiting_time=42.5, queue_length=8.3,
            throughput=1247, delay=18.7, density=64
        ),
        "Traffic Incident": NetworkMetrics(
            vehicles=318, waiting_time=67.8, queue_length=13.6,
            throughput=1095, delay=31.2, density=88
        ),
    }

    INTERSECTIONS = {
        "SACOP": IntersectionMetrics(queue=7, wait=35),
        "Del Rosario": IntersectionMetrics(queue=8, wait=39),
    }

    COMPARISON = ComparisonMetrics(
        fixed={"wait": 58.2, "queue": 11.8, "throughput": 1052, "delay": 26.4},
        adaptive={"wait": 42.5, "queue": 8.3, "throughput": 1247, "delay": 18.7},
    )

    def __init__(self):
        self.rng = random.Random(100)
        self.reset()

    def reset(self):
        base = self.SCENARIO_METRICS["Peak Hours"]
        self._metrics = NetworkMetrics(**vars(base))
        self._comparisons = ComparisonMetrics(
            fixed=dict(self.COMPARISON.fixed),
            adaptive=dict(self.COMPARISON.adaptive),
        )
        self._intersections = {
            name: IntersectionMetrics(item.queue, item.wait)
            for name, item in self.INTERSECTIONS.items()
        }
        self._controller = ControllerState()
        self._history = [35, 52, 48, 42, 38, 45, 51, 47, 39, 35]
        self._log = [
            ("13:42:18", "Extended E-W green +8s", "High E-W queue", "+0.82"),
            ("13:42:06", "Switched to N-S green", "Queue balanced", "+0.74"),
            ("13:41:54", "Extended N-S green +5s", "Increased traffic", "+0.68"),
        ]

    def set_scenario(self, scenario):
        base = self.SCENARIO_METRICS[scenario]
        self._metrics = NetworkMetrics(**vars(base))
        self._history = [base.waiting_time] * 10

    def step(self, speed, scenario, mode):
        base = self.SCENARIO_METRICS[scenario]
        noise = self.rng.uniform(-1.0, 1.0)

        self._metrics.waiting_time = max(12, base.waiting_time + noise)
        self._metrics.queue_length = max(
            3, self._metrics.queue_length + self.rng.uniform(-0.3, 0.35)
        )
        self._metrics.throughput = max(
            600, int(self._metrics.throughput + self.rng.randint(-9, 12))
        )
        self._metrics.delay = max(7, self._metrics.waiting_time * 0.44)
        self._metrics.vehicles = max(
            80, int(self._metrics.vehicles + self.rng.randint(-5, 7))
        )
        self._metrics.density = min(98, max(18, self._metrics.vehicles / 3.85))
        self._metrics.speed_avg = max(15, 48 - self._metrics.density * 0.22)
        self._metrics.reward = max(
            0.2, min(0.98, self._metrics.reward + self.rng.uniform(-0.025, 0.025))
        )
        self._metrics.confidence = max(
            82,
            min(97, int(self._metrics.confidence + self.rng.choice([-1, 0, 0, 1])))
        )

        self._history = self._history[1:] + [self._metrics.waiting_time]

        for item in self._intersections.values():
            item.queue = max(2, min(16, item.queue + self.rng.choice([-1, 0, 0, 1])))
            item.wait = max(5, item.wait + self.rng.choice([-2, -1, 0, 1, 2]))

        if mode == "Adaptive ML":
            self._controller.action = "EXTEND GREEN"
            self._controller.adjustment = "+8 seconds"
            self._controller.reward = self._metrics.reward
            self._controller.reason = "East-West queue is higher than North-South."
        else:
            self._controller.action = "FOLLOW FIXED CYCLE"
            self._controller.adjustment = "0 seconds"
            self._controller.reward = 0.0
            self._controller.reason = "Conventional timing plan is controlling this signal."

    def metrics(self):
        return self._metrics

    def comparisons(self):
        return self._comparisons

    def intersections(self):
        return self._intersections

    def controller(self):
        return self._controller

    def wait_history(self):
        return self._history

    def decision_log(self):
        return self._log
