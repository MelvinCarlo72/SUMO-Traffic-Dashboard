import random
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

from config import (
    APP_TITLE, WINDOW_SIZE, PRESENTATION_SIZE, SCENARIOS, SPEED_OPTIONS,
    INTERSECTIONS, DEFAULT_SCENARIO, DEFAULT_MODE, DEFAULT_SIM_TIME, PHASES,
    BG, PANEL, CARD, CARD2, BORDER, TEXT, MUTED,
    BLUE, CYAN, GREEN, YELLOW, RED, PURPLE, PINK,
)


class TrafficDashboard(tk.Tk):
    """A section-based SUMO dashboard with an iOS/macOS-inspired layout."""

    def __init__(self, provider):
        super().__init__()
        self.provider = provider
        self.title(APP_TITLE)
        self.geometry(WINDOW_SIZE)
        self.minsize(1180, 760)
        self.option_add("*Entry.insertBackground", TEXT)
        self.configure(bg=BG)

        available = set(tkfont.families())
        self.font_family = "Inter" if "Inter" in available else "Segoe UI"

        self.running = True
        self.speed = 1
        self.scenario = DEFAULT_SCENARIO
        self.mode = DEFAULT_MODE
        self.selected = next(iter(INTERSECTIONS.values()))
        self.phase_index = 0
        self.phase = PHASES[0]
        self.remaining = 18
        self.sim_time = DEFAULT_SIM_TIME
        self.frame = 0
        self.pages = {}
        self.nav_buttons = {}
        self.current_page = "Dashboard"

        self._styles()
        self._build_shell()
        self.show_page("Dashboard")
        self.after(500, self.tick)

    # ---------- visual helpers ----------
    def _styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(
            "TCombobox", fieldbackground=PANEL, background=PANEL,
            foreground=TEXT, bordercolor=BORDER, arrowcolor=MUTED,
            padding=8, relief="flat"
        )
        s.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", TEXT)])

    def lbl(self, parent, text="", size=10, color=TEXT, bold=False, bg=None, **kwargs):
        return tk.Label(
            parent, text=text, bg=parent.cget("bg") if bg is None else bg,
            fg=color, font=(self.font_family, size, "bold" if bold else "normal"),
            **kwargs
        )

    def rule(self, parent, pady=0):
        line = tk.Frame(parent, bg=BORDER, height=1)
        line.pack(fill="x", pady=pady)
        return line

    def button(self, parent, text, command, bg=PANEL, fg=TEXT, width=None):
        b = tk.Button(
            parent, text=text, command=command, bg=bg, fg=fg,
            activebackground=CARD2, activeforeground=TEXT,
            relief="flat", bd=0, cursor="hand2",
            font=(self.font_family, 9, "bold"), padx=12, pady=9,
            highlightthickness=0
        )
        if width:
            b.config(width=width)
        return b

    def section_header(self, parent, title, subtitle=None):
        box = tk.Frame(parent, bg=BG)
        box.pack(fill="x", pady=(0, 18))
        self.lbl(box, title, 24, TEXT, True).pack(anchor="w")
        if subtitle:
            self.lbl(box, subtitle, 10, MUTED).pack(anchor="w", pady=(4, 0))
        return box

    def page_frame(self, name):
        page = tk.Frame(self.page_host, bg=BG)
        self.pages[name] = page
        return page

    # ---------- app shell ----------
    def _build_shell(self):
        root = tk.Frame(self, bg=BG)
        root.pack(fill="both", expand=True)

        self._sidebar(root)
        main = tk.Frame(root, bg=BG)
        main.pack(side="left", fill="both", expand=True)

        self._topbar(main)
        self.page_host = tk.Frame(main, bg=BG)
        self.page_host.pack(fill="both", expand=True, padx=32, pady=(12, 24))

        self._build_dashboard_page()
        self._build_live_page()
        self._build_ml_page()
        self._build_analytics_page()
        self._build_impact_page()
        self._build_settings_page()

    def _topbar(self, parent):
        bar = tk.Frame(parent, bg=BG, height=62)
        bar.pack(fill="x", padx=24, pady=(8, 0))
        bar.pack_propagate(False)

        self.page_title = self.lbl(bar, "Overview", 10, MUTED, True)
        self.page_title.pack(side="left", pady=14)

        search_wrap = tk.Frame(bar, bg=BG)
        search_wrap.pack(expand=True, fill="both")
        search = tk.Frame(search_wrap, bg="#0c0f12", highlightbackground=BORDER, highlightthickness=1)
        search.place(relx=.5, rely=.5, anchor="center", width=290, height=36)
        self.lbl(search, "⌕", 13, MUTED, bg="#0c0f12").pack(side="left", padx=(11, 5))
        self.search_var = tk.StringVar()
        entry = tk.Entry(search, textvariable=self.search_var, bg="#0c0f12", fg=TEXT,
                         insertbackground=TEXT, relief="flat", bd=0,
                         font=(self.font_family, 9))
        entry.insert(0, "Search")
        entry.config(fg=MUTED)
        entry.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=6)
        entry.bind("<FocusIn>", lambda _e: self._clear_search_placeholder(entry))
        entry.bind("<Return>", lambda _e: self._search_navigation())

        right = tk.Frame(bar, bg=BG)
        right.pack(side="right", fill="y")
        self.status_label = self.lbl(right, "●  RUNNING", 8, GREEN, True)
        self.status_label.pack(side="left", padx=(0, 14), pady=17)
        avatar = tk.Canvas(right, width=32, height=32, bg=BG, highlightthickness=0)
        avatar.pack(side="left", pady=8)
        avatar.create_oval(2, 2, 30, 30, fill="#2a3138", outline=BORDER)
        avatar.create_oval(10, 7, 22, 19, fill="#697586", outline="")
        avatar.create_arc(7, 15, 25, 29, start=0, extent=180, fill="#697586", outline="")

        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=24)

    def _clear_search_placeholder(self, entry):
        if entry.get() == "Search":
            entry.delete(0, "end")
            entry.config(fg=TEXT)

    def _search_navigation(self):
        q = self.search_var.get().strip().lower()
        aliases = {"overview": "Dashboard", "dashboard": "Dashboard", "simulation": "Live Simulation",
                   "live": "Live Simulation", "ml": "ML Controller", "controller": "ML Controller",
                   "analytics": "Analytics", "impact": "Impact", "settings": "Settings"}
        for key, page in aliases.items():
            if key in q:
                self.show_page(page)
                return
    def _sidebar(self, parent):
        side = tk.Frame(parent, bg=PANEL, width=215)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        brand = tk.Frame(side, bg=PANEL, height=62)
        brand.pack(fill="x", padx=16)
        brand.pack_propagate(False)
        self.lbl(brand, "☰", 18, MUTED, bg=PANEL).pack(side="left", pady=14)
        logo = tk.Frame(brand, bg=PANEL)
        logo.pack(side="left", padx=13, pady=12)
        self.lbl(logo, "SUMO", 17, GREEN, True, bg=PANEL).pack(side="left")
        self.lbl(logo, "TRAFFIC", 5, MUTED, True, bg=PANEL).pack(side="left", padx=(2, 0), pady=(8, 0))
        self.rule(side)

        nav = [
            ("Dashboard", "⌂", "Overview", "System overview"),
            ("Live Simulation", "⌁", "Live Simulation", "Network activity"),
            ("ML Controller", "◈", "ML Controller", "Signal decisions"),
            ("Analytics", "⌁", "Analytics", "Performance trends"),
            ("Impact", "⇄", "Impact", "Before vs optimized"),
        ]
        for key, icon_text, label, tip in nav:
            self._nav_button(side, key, icon_text, label, tip)

        tk.Frame(side, bg=PANEL).pack(fill="both", expand=True)
        self.rule(side, pady=(0, 10))
        bottom = tk.Frame(side, bg=PANEL)
        bottom.pack(fill="x", padx=0, pady=(0, 14))
        self._nav_button(bottom, "Settings", "⚙", "Settings", "Preferences")

    def _simulation_strip(self, parent):
        strip = tk.Frame(parent, bg=PANEL)
        strip.pack(fill="x", padx=12, pady=(8, 12))
        self.lbl(strip, "SIMULATION", 7, MUTED, True, bg=PANEL).pack(anchor="w", padx=10, pady=(8, 1))
        self.sim_clock = self.lbl(strip, "08:00:00", 16, TEXT, True, bg=PANEL)
        self.sim_clock.pack(anchor="w", padx=10)
        self.lbl(strip, "Local simulation time", 8, MUTED, bg=PANEL).pack(anchor="w", padx=10, pady=(0, 7))
    def _nav_button(self, parent, key, icon_text, label, tooltip):
        b = tk.Button(
            parent, text=f"{icon_text}   {label}", command=lambda k=key: self.show_page(k),
            anchor="w", bg=PANEL, fg="#b8c0c9", activebackground="#3b4249",
            activeforeground=TEXT, relief="flat", bd=0, cursor="hand2",
            font=(self.font_family, 9, "normal"), padx=12, pady=10,
            highlightthickness=0
        )
        b.pack(fill="x", padx=8, pady=2)
        self.nav_buttons[key] = b

    def show_page(self, name):
        for page in self.pages.values():
            page.pack_forget()
        self.pages[name].pack(fill="both", expand=True)
        self.current_page = name
        self.page_title.config(text="Overview" if name == "Dashboard" else name)
        for key, button in self.nav_buttons.items():
            active = key == name
            button.config(bg="#3d444b" if active else PANEL, fg=TEXT if active else "#b8c0c9",
                          font=(self.font_family, 10, "bold" if active else "normal"))
        self.update_all()

    # ---------- dashboard ----------
    def _build_dashboard_page(self):
        p = self.page_frame("Dashboard")
        p.configure(bg=BG)

        # Single grouped metric band: separated information, not floating cards.
        metrics = tk.Frame(p, bg="#0c0f12", highlightbackground=BORDER, highlightthickness=1)
        metrics.pack(fill="x", pady=(8, 16))
        self.kpi = {}
        items = [
            ("vehicles", "Vehicles", GREEN),
            ("wait", "Avg wait time", TEXT),
            ("queue", "Queue length", TEXT),
            ("throughput", "Throughput", TEXT),
        ]
        for i, (key, title, color) in enumerate(items):
            if i:
                tk.Frame(metrics, bg=BORDER, width=1).pack(side="left", fill="y", pady=14)
            cell = tk.Frame(metrics, bg="#0c0f12", height=80)
            cell.pack(side="left", fill="both", expand=True)
            cell.pack_propagate(False)
            self.lbl(cell, title, 8, MUTED, True, bg="#0c0f12").pack(anchor="w", padx=16, pady=(13, 1))
            value = self.lbl(cell, "—", 17, TEXT, True, bg="#0c0f12")
            value.pack(anchor="w", padx=16)
            delta = self.lbl(cell, "", 7, color, bg="#0c0f12")
            delta.pack(anchor="e", padx=16, pady=(0, 10))
            self.kpi[key] = (value, delta)

        # Large chart section inspired by the reference's clean bordered container.
        trend = tk.Frame(p, bg="#0c0f12", highlightbackground=BORDER, highlightthickness=1)
        trend.pack(fill="both", expand=True, pady=(0, 16))
        head = tk.Frame(trend, bg="#0c0f12")
        head.pack(fill="x", padx=16, pady=(14, 4))
        self.lbl(head, "NETWORK PERFORMANCE", 9, TEXT, True, bg="#0c0f12").pack(side="left")
        self.lbl(head, "This session", 8, "#c6ccd3", bg="#2c3339", padx=9, pady=5).pack(side="left", padx=12)
        self.lbl(head, "Live", 8, MUTED, bg="#0c0f12").pack(side="left")
        self.trend_canvas = tk.Canvas(trend, bg="#0c0f12", highlightthickness=0, height=245)
        self.trend_canvas.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.trend_canvas.bind("<Configure>", lambda _e: self.draw_wait())

        table = tk.Frame(p, bg="#0c0f12", highlightbackground=BORDER, highlightthickness=1, height=210)
        table.pack(fill="x")
        self.lbl(table, "INTERSECTION STATUS", 11, TEXT, True, bg="#0c0f12").pack(anchor="w", padx=16, pady=(14, 12))
        inner = tk.Frame(table, bg="#0c0f12")
        inner.pack(fill="x", padx=8, pady=(0, 4))
        self.dashboard_table = inner
        self._build_status_rows(self.dashboard_table, compact=True)
    def _build_status_rows(self, parent, compact=False):
        self.status_rows = [] if not hasattr(self, "status_rows") else self.status_rows
        headers = ["INTERSECTION", "LOCATION", "QUEUE", "WAIT", "STATUS"]
        widths = [16, 38, 12, 12, 16]
        for j, header in enumerate(headers):
            self.lbl(parent, header, 8, MUTED, True).grid(row=0, column=j, sticky="w", padx=8, pady=(0, 8))
            parent.grid_columnconfigure(j, weight=widths[j])
        for i, (iid, name) in enumerate(INTERSECTIONS.items(), 1):
            row = []
            for j in range(5):
                lab = self.lbl(parent, "—", 9, TEXT, j == 0)
                lab.grid(row=i * 2, column=j, sticky="w", padx=8, pady=8)
                row.append(lab)
            line = tk.Frame(parent, bg=BORDER, height=1)
            line.grid(row=i * 2 + 1, column=0, columnspan=5, sticky="ew")
            self.status_rows.append((iid, name, row))

    # ---------- live simulation ----------
    def _build_live_page(self):
        p = self.page_frame("Live Simulation")
        self.section_header(p, "Live simulation", "Real-time prototype view of the monitored SUMO network")

        top = tk.Frame(p, bg=BG)
        top.pack(fill="x", pady=(0, 12))
        self.lbl(top, "NETWORK VIEW", 9, MUTED, True).pack(side="left")
        self.density_label = self.lbl(top, "DENSITY —", 9, GREEN, True)
        self.density_label.pack(side="right")
        self.rule(p, pady=(0, 12))

        body = tk.Frame(p, bg=BG)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True)
        self.sim_canvas = tk.Canvas(left, bg="#0b1018", height=480, highlightthickness=0)
        self.sim_canvas.pack(fill="both", expand=True)
        self.sim_canvas.bind("<Configure>", lambda _e: self.draw_sim())

        right = tk.Frame(body, bg=BG, width=290)
        right.pack(side="right", fill="y", padx=(26, 0))
        right.pack_propagate(False)
        self.lbl(right, "SIMULATION CONTROLS", 9, MUTED, True).pack(anchor="w")
        self.rule(right, pady=(8, 12))

        self.lbl(right, "Scenario", 9, TEXT, True).pack(anchor="w")
        self.scenario_var = tk.StringVar(value=self.scenario)
        cb = ttk.Combobox(right, textvariable=self.scenario_var, values=SCENARIOS, state="readonly")
        cb.pack(fill="x", pady=(6, 18))
        cb.bind("<<ComboboxSelected>>", lambda _e: self.change_scenario())

        self.lbl(right, "Simulation speed", 9, TEXT, True).pack(anchor="w")
        speeds = tk.Frame(right, bg=BG)
        speeds.pack(fill="x", pady=(7, 18))
        self.speed_buttons = {}
        for value in SPEED_OPTIONS:
            b = self.button(speeds, f"{value}×", lambda v=value: self.set_speed(v), bg=CARD2 if value == 1 else PANEL)
            b.pack(side="left", fill="x", expand=True, padx=2)
            self.speed_buttons[value] = b

        self.lbl(right, "Current intersection", 9, TEXT, True).pack(anchor="w")
        self.intersection_var = tk.StringVar(value=self.selected)
        cb2 = ttk.Combobox(right, textvariable=self.intersection_var, values=list(INTERSECTIONS.values()), state="readonly")
        cb2.pack(fill="x", pady=(6, 18))
        cb2.bind("<<ComboboxSelected>>", lambda _e: self.select_intersection())

        self.rule(right, pady=(0, 14))
        self.live_phase = self.lbl(right, "—", 14, BLUE, True, wraplength=260, justify="left")
        self.live_phase.pack(anchor="w")
        self.live_remaining = self.lbl(right, "—", 9, MUTED)
        self.live_remaining.pack(anchor="w", pady=(3, 0))

    # ---------- ML controller ----------
    def _build_ml_page(self):
        p = self.page_frame("ML Controller")
        self.section_header(p, "ML controller", "Adaptive signal decisions, confidence, and model reasoning")
        self.lbl(p, "CONTROL MODE", 9, MUTED, True).pack(anchor="w")
        mode_row = tk.Frame(p, bg=BG)
        mode_row.pack(fill="x", pady=(8, 12))
        self.mode_label = self.lbl(mode_row, "ADAPTIVE ML", 22, BLUE, True)
        self.mode_label.pack(side="left")
        self.mode_btn = self.button(mode_row, "Switch to Fixed-Time", self.toggle_mode, bg=BLUE)
        self.mode_btn.pack(side="right")
        self.lbl(p, "The model observes queue conditions and traffic flow before selecting a signal action.", 10, MUTED).pack(anchor="w")
        self.rule(p, pady=(20, 14))

        self.ctrl_labels = {}
        grid = tk.Frame(p, bg=BG)
        grid.pack(fill="x")
        for i, (key, title, color) in enumerate([
            ("phase", "CURRENT PHASE", BLUE),
            ("remaining", "TIME REMAINING", TEXT),
            ("action", "ML DECISION", GREEN),
            ("adjustment", "ADJUSTMENT", YELLOW),
            ("reward", "REWARD", PURPLE),
            ("confidence", "MODEL CONFIDENCE", CYAN),
        ]):
            cell = tk.Frame(grid, bg=BG)
            cell.grid(row=i // 2, column=i % 2, sticky="ew", padx=(0 if i % 2 == 0 else 30, 0), pady=12)
            grid.grid_columnconfigure(i % 2, weight=1)
            self.lbl(cell, title, 8, MUTED, True).pack(anchor="w")
            lab = self.lbl(cell, "—", 14, color, True, wraplength=420, justify="left")
            lab.pack(anchor="w", pady=(4, 0))
            self.ctrl_labels[key] = lab
        self.rule(p, pady=(16, 12))
        self.lbl(p, "MODEL REASONING", 9, MUTED, True).pack(anchor="w")
        self.reason_label = self.lbl(p, "—", 11, TEXT, wraplength=850, justify="left")
        self.reason_label.pack(anchor="w", pady=(8, 0))

    # ---------- analytics ----------
    def _build_analytics_page(self):
        p = self.page_frame("Analytics")
        self.section_header(p, "Traffic analytics", "Live waiting-time trends and SAC vs fixed-time comparison")
        self.lbl(p, "WAITING TIME OVER TIME", 9, MUTED, True).pack(anchor="w")
        self.analytics_wait_canvas = tk.Canvas(p, bg=BG, height=260, highlightthickness=0)
        self.analytics_wait_canvas.pack(fill="x", pady=(8, 18))
        self.analytics_wait_canvas.bind("<Configure>", lambda _e: self.draw_wait())
        self.rule(p, pady=(0, 16))
        self.lbl(p, "FIXED-TIME VS ADAPTIVE ML", 9, MUTED, True).pack(anchor="w")
        self.compare_canvas = tk.Canvas(p, bg=BG, height=250, highlightthickness=0)
        self.compare_canvas.pack(fill="x", pady=(8, 0))
        self.compare_canvas.bind("<Configure>", lambda _e: self.draw_compare())

    # ---------- impact ----------
    def _build_impact_page(self):
        p = self.page_frame("Impact")
        self.section_header(p, "Optimization impact", "A direct comparison of fixed-time and SAC control")
        headers = tk.Frame(p, bg=BG)
        headers.pack(fill="x")
        for i, h in enumerate(["METRIC", "FIXED-TIME", "ADAPTIVE ML", "IMPROVEMENT"]):
            self.lbl(headers, h, 8, MUTED, True).grid(row=0, column=i, sticky="w", padx=8, pady=(0, 10))
            headers.grid_columnconfigure(i, weight=[3, 2, 2, 2][i])
        self.rule(p, pady=(0, 4))
        self.impact_labels = {}
        for key, title, color in [
            ("wait", "Waiting time", BLUE),
            ("queue", "Queue length", YELLOW),
            ("throughput", "Throughput", GREEN),
            ("delay", "Average delay", CYAN),
        ]:
            row = tk.Frame(p, bg=BG)
            row.pack(fill="x")
            row.grid_columnconfigure(0, weight=3)
            row.grid_columnconfigure(1, weight=2)
            row.grid_columnconfigure(2, weight=2)
            row.grid_columnconfigure(3, weight=2)
            self.lbl(row, title, 12, TEXT, True).grid(row=0, column=0, sticky="w", padx=8, pady=18)
            fixed = self.lbl(row, "—", 12, MUTED)
            fixed.grid(row=0, column=1, sticky="w", padx=8)
            adaptive = self.lbl(row, "—", 13, color, True)
            adaptive.grid(row=0, column=2, sticky="w", padx=8)
            improve = self.lbl(row, "—", 12, color, True)
            improve.grid(row=0, column=3, sticky="w", padx=8)
            self.impact_labels[key] = (fixed, adaptive, improve)
            self.rule(p)

    # ---------- settings ----------
    def _build_settings_page(self):
        p = self.page_frame("Settings")
        self.section_header(p, "Settings", "Application preferences and presentation options")
        self.lbl(p, "APPLICATION", 9, MUTED, True).pack(anchor="w")
        rows = tk.Frame(p, bg=BG)
        rows.pack(fill="x", pady=(8, 18))
        self._setting_row(rows, "Interface font", "Inter", 0)
        self._setting_row(rows, "Data source", "Prototype / Sample Data", 1)
        self._setting_row(rows, "Study network", "3 monitored intersections", 2)
        self.rule(p, pady=(0, 18))

        self.lbl(p, "PRESENTATION", 9, MUTED, True).pack(anchor="w")
        self.presentation_var = tk.BooleanVar(value=False)
        check = tk.Checkbutton(
            p, text="Presentation Mode", variable=self.presentation_var,
            command=self.presentation_mode, bg=BG, fg=TEXT,
            activebackground=BG, activeforeground=TEXT,
            selectcolor=PANEL, font=(self.font_family, 10), highlightthickness=0
        )
        check.pack(anchor="w", pady=(8, 0))
        self.lbl(p, "Expands the window for classroom or project presentations.", 9, MUTED).pack(anchor="w", pady=(3, 0))

    def _setting_row(self, parent, left, right, row):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="x")
        self.lbl(f, left, 11, TEXT).pack(side="left", pady=13)
        self.lbl(f, right, 10, MUTED).pack(side="right", pady=13)
        self.rule(parent)

    # ---------- data updates ----------
    def update_kpis(self):
        if not hasattr(self, "kpi"):
            return
        m = self.provider.metrics()
        values = {
            "vehicles": (f"{m.vehicles:,}", "live network"),
            "wait": (f"{m.waiting_time:.1f}s", "prototype metric"),
            "queue": (f"{m.queue_length:.1f}", "vehicles"),
            "throughput": (f"{m.throughput:,}", "vehicles / hour"),
        }
        for key, (value, delta) in self.kpi.items():
            value.config(text=values[key][0])
            delta.config(text=values[key][1])
        if hasattr(self, "network_summary"):
            self.network_summary.config(text=f"{m.vehicles:,} vehicles active • {m.density:.0f}% network density")

    def update_status_table(self):
        if not hasattr(self, "status_rows"):
            return
        data = self.provider.intersections()
        for iid, name, labels in self.status_rows:
            metrics = data.get(name)
            if metrics is None:
                continue
            status = "CONGESTED" if metrics.queue >= 10 else "NORMAL"
            vals = [iid, name, f"{metrics.queue:.0f}", f"{metrics.wait:.0f}s", status]
            colors = [BLUE, TEXT, YELLOW if metrics.queue >= 10 else TEXT, TEXT, RED if status == "CONGESTED" else GREEN]
            for lab, value, color in zip(labels, vals, colors):
                lab.config(text=value, fg=color)

    def update_controller(self):
        if not hasattr(self, "ctrl_labels"):
            return
        state = self.provider.controller()
        self.ctrl_labels["phase"].config(text=self.phase)
        self.ctrl_labels["remaining"].config(text=f"{self.remaining} seconds")
        self.ctrl_labels["action"].config(text=state.action)
        self.ctrl_labels["adjustment"].config(text=state.adjustment)
        self.ctrl_labels["reward"].config(text=f"+{state.reward:.2f}" if self.mode == "Adaptive ML" else "—")
        self.ctrl_labels["confidence"].config(text=f"{state.confidence:.0f}%")
        self.reason_label.config(text=state.reason)
        self.live_phase.config(text=self.phase)
        self.live_remaining.config(text=f"{self.remaining} seconds remaining • {self.mode}")

    def update_impact(self):
        if not hasattr(self, "impact_labels"):
            return
        comparison = self.provider.comparisons()
        for key, (fixed_label, adaptive_label, improve_label) in self.impact_labels.items():
            fixed = comparison.fixed.get(key)
            adaptive = comparison.adaptive.get(key)
            if fixed is None or adaptive is None:
                fixed_label.config(text="—"); adaptive_label.config(text="—"); improve_label.config(text="No data")
                continue
            if key == "throughput":
                change = (adaptive - fixed) / fixed * 100 if fixed else 0
                improvement = f"↑ {change:.1f}%"
                fixed_text, adaptive_text = f"{fixed:,.0f}", f"{adaptive:,.0f}"
            else:
                change = (fixed - adaptive) / fixed * 100 if fixed else 0
                improvement = f"↓ {change:.1f}%"
                fixed_text, adaptive_text = f"{fixed:.1f}", f"{adaptive:.1f}"
            fixed_label.config(text=fixed_text)
            adaptive_label.config(text=adaptive_text)
            improve_label.config(text=improvement)

    # ---------- drawing ----------
    def draw_sim(self):
        if not hasattr(self, "sim_canvas"):
            return
        c = self.sim_canvas
        c.delete("all")
        w = max(c.winfo_width(), 650)
        h = max(c.winfo_height(), 330)
        road = "#273142"
        c.create_rectangle(0, h * .37, w, h * .63, fill=road, outline="")
        c.create_rectangle(w * .41, 0, w * .59, h, fill=road, outline="")
        for x in range(0, w, 55):
            c.create_rectangle(x, h * .49, x + 28, h * .505, fill="#d1d5db", outline="")
        for y in range(0, h, 55):
            c.create_rectangle(w * .495, y, w * .51, y + 28, fill="#d1d5db", outline="")
        c.create_rectangle(w * .41, h * .37, w * .59, h * .63, fill="#1a2330", outline=BLUE, width=2)

        ew_green = "EAST" in self.phase
        ns_green = "NORTH" in self.phase
        for x, y, col in [
            (w * .39, h * .32, GREEN if ew_green else RED), (w * .61, h * .68, GREEN if ew_green else RED),
            (w * .39, h * .68, GREEN if ns_green else RED), (w * .61, h * .32, GREEN if ns_green else RED),
        ]:
            c.create_oval(x - 8, y - 8, x + 8, y + 8, fill=col, outline="")

        scenario_counts = {"Peak Hours": 22, "Normal Traffic": 13, "Traffic Incident": 27}
        n = scenario_counts[self.scenario]
        for i in range(n):
            lane = i % 4
            if lane < 2:
                y = h * .42 + (i % 3) * 18
                direction = 1 if lane == 0 else -1
                base = (i * 77 + self.frame * 3 * direction) % (w + 90) - 45
                c.create_rectangle(base, y, base + 28, y + 11, fill=BLUE if lane == 0 else CYAN, outline="")
            else:
                x = w * .445 + (i % 3) * 20
                direction = 1 if lane == 2 else -1
                base = (i * 51 + self.frame * 3 * direction) % (h + 90) - 45
                c.create_rectangle(x, base, x + 11, base + 28, fill=YELLOW if lane == 2 else PINK, outline="")
        m = self.provider.metrics()
        c.create_text(18, 18, text="LIVE NETWORK • PROTOTYPE", fill=MUTED, anchor="w", font=(self.font_family, 9, "bold"))
        c.create_text(w - 18, 18, text=f"DENSITY {m.density:.0f}%", fill=YELLOW if m.density > 75 else GREEN, anchor="e", font=(self.font_family, 9, "bold"))
        c.create_text(w / 2, h * .31, text=self.selected, fill=TEXT, font=(self.font_family, 10, "bold"))
        self.density_label.config(text=f"DENSITY {m.density:.0f}%", fg=YELLOW if m.density > 75 else GREEN)

    def draw_wait(self):
        c = getattr(self, "trend_canvas", None) if self.current_page == "Dashboard" else getattr(self, "analytics_wait_canvas", None)
        if not c:
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 500), max(c.winfo_height(), 230)
        pad = 48; history = self.provider.wait_history()
        if not history:
            return
        top = max(60, max(history) * 1.15)
        bottom = h - 30
        for i in range(4):
            y = 28 + i * (bottom - 28) / 3
            c.create_line(pad, y, w - 18, y, fill="#15191d")
            c.create_text(pad - 10, y, text=str(int(top - i * top / 3)), fill="#7f8994", anchor="e", font=(self.font_family, 7))
        pts = []
        for i, value in enumerate(history):
            x = pad + i * (w - pad - 26) / max(1, len(history) - 1)
            y = 28 + (top - value) * (bottom - 28) / top
            pts.extend((x, y))
        if len(pts) >= 4:
            c.create_line(*pts, fill="#63d54d", width=2, smooth=True)
        c.create_text(16, 14, text="WAITING TIME", fill=MUTED, anchor="w", font=(self.font_family, 7, "bold"))
        c.create_text(w - 18, 14, text="LIVE", fill="#63d54d", anchor="e", font=(self.font_family, 7, "bold"))
    def draw_compare(self):
        if not hasattr(self, "compare_canvas"):
            return
        c = self.compare_canvas; c.delete("all")
        w, h = max(c.winfo_width(), 500), max(c.winfo_height(), 230)
        pad = 42; comparison = self.provider.comparisons(); labels = list(INTERSECTIONS.keys())
        fw, aw = comparison.fixed.get("wait"), comparison.adaptive.get("wait")
        if fw is None or aw is None: return
        fixed, adaptive = [fw] * len(labels), [aw] * len(labels)
        base, gap, bw = h - 35, (w - 2 * pad) / len(labels), 18
        scale = max(fixed + adaptive + [1]) * 1.15
        for i, lab in enumerate(labels):
            cx = pad + gap * (i + .5); fh = fixed[i] / scale * (h - 75); ah = adaptive[i] / scale * (h - 75)
            c.create_rectangle(cx - bw - 3, base - fh, cx - 3, base, fill=YELLOW, outline="")
            c.create_rectangle(cx + 3, base - ah, cx + bw + 3, base, fill=GREEN, outline="")
            c.create_text(cx, base + 13, text=lab, fill=MUTED, font=(self.font_family, 8))
        c.create_text(w - 190, 12, text="■ Fixed-Time", fill=YELLOW, anchor="w", font=(self.font_family, 8, "bold"))
        c.create_text(w - 92, 12, text="■ ML Adaptive", fill=GREEN, anchor="w", font=(self.font_family, 8, "bold"))

    # ---------- interactions ----------
    def set_speed(self, value):
        self.speed = value
        for n, button in self.speed_buttons.items():
            button.config(bg=CARD2 if n == value else PANEL)

    def change_scenario(self):
        self.scenario = self.scenario_var.get()
        if hasattr(self.provider, "set_scenario"): self.provider.set_scenario(self.scenario)
        self.update_all()

    def toggle_mode(self):
        if self.mode == "Adaptive ML":
            self.mode = "Fixed-Time"; self.mode_label.config(text="FIXED-TIME CONTROL", fg=YELLOW); self.mode_btn.config(text="Switch to Adaptive ML", bg=YELLOW)
        else:
            self.mode = "Adaptive ML"; self.mode_label.config(text="ADAPTIVE ML", fg=BLUE); self.mode_btn.config(text="Switch to Fixed-Time", bg=BLUE)
        self.update_controller()

    def select_intersection(self):
        self.selected = self.intersection_var.get(); self.draw_sim(); self.update_controller()

    def pause(self):
        self.running = False; self.status_label.config(text="●  PAUSED", fg=YELLOW)

    def resume(self):
        self.running = True; self.status_label.config(text="●  RUNNING", fg=GREEN)

    def reset(self):
        self.running = True; self.scenario = DEFAULT_SCENARIO; self.scenario_var.set(DEFAULT_SCENARIO); self.mode = DEFAULT_MODE
        self.phase_index = 0; self.phase = PHASES[0]; self.remaining = 18; self.sim_time = DEFAULT_SIM_TIME; self.frame = 0
        self.provider.reset()
        self.mode_label.config(text="ADAPTIVE ML", fg=BLUE); self.mode_btn.config(text="Switch to Fixed-Time", bg=BLUE)
        self.status_label.config(text="●  RUNNING", fg=GREEN); self.update_all()

    def tick(self):
        if self.running:
            self.frame += max(1, self.speed); self.sim_time += self.speed; self.remaining -= self.speed
            if self.remaining <= 0:
                self.remaining = random.choice([10, 12, 15, 18, 22]); self.phase = PHASES[self.phase_index % len(PHASES)]; self.phase_index += 1
            self.provider.step(self.speed, self.scenario, self.mode); self.update_all()
        self.after(500, self.tick)

    def update_all(self):
        if hasattr(self, "sim_clock"): self.sim_clock.config(text=self.format_time(self.sim_time))
        self.update_kpis(); self.update_status_table(); self.update_controller(); self.update_impact(); self.draw_sim(); self.draw_wait(); self.draw_compare()

    @staticmethod
    def format_time(seconds):
        seconds = int(seconds) % 86400
        return f"{seconds // 3600:02d}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"

    def presentation_mode(self):
        if self.presentation_var.get():
            self.geometry(PRESENTATION_SIZE); self.status_label.config(text="●  PRESENTATION MODE", fg=GREEN)
        else:
            self.geometry(WINDOW_SIZE); self.status_label.config(text="●  RUNNING" if self.running else "●  PAUSED", fg=GREEN if self.running else YELLOW)
