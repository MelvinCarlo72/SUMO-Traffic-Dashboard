APP_TITLE = "SUMO Traffic Dashboard — ML Traffic Light Optimization"
WINDOW_SIZE = "1500x920"
PRESENTATION_SIZE = "1600x950"

SCENARIOS = ("Normal Traffic", "Peak Hours", "Traffic Incident")
SPEED_OPTIONS = (1, 2, 5, 10)

INTERSECTIONS = {
    "SACOP": "SACOP",
    "DEL_ROSARIO": "Del Rosario",
}

TLS_IDS = {}

DEFAULT_SCENARIO = "Peak Hours"
DEFAULT_MODE = "Adaptive ML"
DEFAULT_SIM_TIME = 8 * 3600

PHASES = (
    "EAST–WEST GREEN",
    "EAST–WEST YELLOW",
    "NORTH–SOUTH GREEN",
    "NORTH–SOUTH YELLOW",
)

BG = "#0b0d0f"
PANEL = "#101315"
CARD = "#0c0f12"
CARD2 = "#161b1f"
BORDER = "#292e33"
TEXT = "#eef1f4"
MUTED = "#8c949d"
BLUE = "#5d8dff"
CYAN = "#22d3ee"
GREEN = "#63d54d"
YELLOW = "#f59e0b"
RED = "#ef4444"
PURPLE = "#a855f7"
PINK = "#ec4899"
