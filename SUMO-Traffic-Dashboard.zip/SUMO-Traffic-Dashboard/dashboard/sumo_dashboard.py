from config import APP_TITLE
from dashboard import TrafficDashboard
from prototype_data_provider import PrototypeDataProvider


def main():
    app = TrafficDashboard(PrototypeDataProvider())
    app.mainloop()


if __name__ == "__main__":
    main()
