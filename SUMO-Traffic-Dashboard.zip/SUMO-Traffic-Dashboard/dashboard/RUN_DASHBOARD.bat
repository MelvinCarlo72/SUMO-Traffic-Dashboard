@echo off
REM Starts the dashboard as a standalone desktop app (see RUN_APP.bat in the project root).
call "%~dp0..\RUN_APP.bat"
