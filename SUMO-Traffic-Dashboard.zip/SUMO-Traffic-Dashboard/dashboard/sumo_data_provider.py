import os
import sys

from data_provider import (
    DataProvider,
    NetworkMetrics,
    ComparisonMetrics,
    IntersectionMetrics,
    ControllerState,
)

if os.environ.get("SUMO_HOME"):
    tools = os.path.join(os.environ["SUMO_HOME"], "tools")
    if tools not in sys.path:
        sys.path.append(tools)

try:
    import traci
except ImportError:
    traci = None


class SumoDataProvider(DataProvider):
    def __init__(self, label_to_tls=None):
        self.label_to_tls = label_to_tls or {}
        self.connected = False

    def connect(self, sumo_binary="sumo-gui", config_file="study.sumocfg"):
        if traci is None:
            raise RuntimeError("TraCI is not available.")
        traci.start([sumo_binary, "-c", config_file])
        self.connected = True

    def reset(self):
        pass

    def step(self, speed, scenario, mode):
        if self.connected:
            for _ in range(max(1, speed)):
                traci.simulationStep()

    def metrics(self):
        if not self.connected:
            return NetworkMetrics()

        ids = traci.vehicle.getIDList()
        n = len(ids)
        speeds = [traci.vehicle.getSpeed(v) for v in ids]
        waiting = [traci.vehicle.getAccumulatedWaitingTime(v) for v in ids]

        return NetworkMetrics(
            vehicles=n,
            speed_avg=sum(speeds) / n if n else 0.0,
            waiting_time=sum(waiting) / n if n else 0.0,
        )

    def comparisons(self):
        return ComparisonMetrics()

    def intersections(self):
        return {}

    def controller(self):
        return ControllerState()

    def wait_history(self):
        return []

    def decision_log(self):
        return []
