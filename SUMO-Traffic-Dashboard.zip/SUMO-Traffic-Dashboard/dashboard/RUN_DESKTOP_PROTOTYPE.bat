@echo off
cd /d "%~dp0"
python "%~dp0sumo_dashboard.py"
if errorlevel 1 pause
