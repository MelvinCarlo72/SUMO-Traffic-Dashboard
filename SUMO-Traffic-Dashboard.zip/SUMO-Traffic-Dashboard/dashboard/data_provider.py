from dataclasses import dataclass, field


@dataclass
class NetworkMetrics:
    vehicles: int = 0
    waiting_time: float = 0.0
    queue_length: float = 0.0
    throughput: int = 0
    delay: float = 0.0
    density: float = 0.0
    speed_avg: float = 0.0
    reward: float = 0.0
    confidence: float = 0.0


@dataclass
class ComparisonMetrics:
    fixed: dict = field(default_factory=dict)
    adaptive: dict = field(default_factory=dict)


@dataclass
class IntersectionMetrics:
    queue: float = 0.0
    wait: float = 0.0


@dataclass
class ControllerState:
    phase: str = "EAST–WEST GREEN"
    remaining: int = 18
    action: str = "EXTEND GREEN"
    adjustment: str = "+8 seconds"
    reward: float = 0.82
    confidence: float = 92.0
    reason: str = "East-West queue is higher than North-South."


class DataProvider:
    def reset(self):
        raise NotImplementedError

    def step(self, speed, scenario, mode):
        raise NotImplementedError

    def metrics(self):
        raise NotImplementedError

    def comparisons(self):
        raise NotImplementedError

    def intersections(self):
        raise NotImplementedError

    def controller(self):
        raise NotImplementedError

    def wait_history(self):
        raise NotImplementedError

    def decision_log(self):
        raise NotImplementedError
