Traffic Project
===============

SUMO-based traffic simulation and validation framework.

Project Structure
-----------------

network_extraction/
    Network construction, backbone extraction,
    study-area generation, and visualization.

boundary_validation/
    Boundary identification and approach analysis.

trip_generation/
    Traffic demand and validation trip generation.

calibration/
    SUMO network and demand calibration.

outputs/
    Reserved for generated intermediate files and results; legacy outputs were removed.

study_areas/
    Reserved for the verified study network, which must be supplied.

Requirements
------------

Python 3.11+
SUMO 1.27.1+

Install Python dependencies:

    pip install -r requirements.txt

Workflow
--------

1. Construct backbone
2. Generate study area and boundary buffer
3. Validate study boundary
4. Analyze entry/exit approaches
5. Generate trips
6. Calibrate simulation
7. Run simulation
8. Evaluate traffic signal models









& "C:\Program Files (x86)\Eclipse\Sumo\bin\netconvert.exe" -s "study_areas\.net.xml" --keep-edges.input-file "outputs\expanded_edges.txt" -o "study_areas\study_area_extracted.net.xml"







SPATIAL TRAVERSAL APPROACH

A network-traversal approach was considered; however, it may introduce network-density bias because the resulting extent is influenced by the number, connectivity, and directionality of roads encountered during traversal. Areas with denser road networks may yield substantially different spatial coverage than areas with fewer or less-connected roads despite having similar geographic proximity to the transportation backbone. Therefore, a spatial buffer was employed to establish a more consistent geographic boundary independent of local network density and topology.
