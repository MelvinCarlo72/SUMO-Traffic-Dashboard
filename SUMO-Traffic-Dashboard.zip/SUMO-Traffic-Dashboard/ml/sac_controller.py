"""SAC controller adapter. Replace DemoSACPolicy with the trained model when available."""
class SACController:
    def __init__(self, model=None): self.model=model
    def predict(self, state):
        if self.model is not None and hasattr(self.model,'predict'):
            return self.model.predict(state)
        # presentation-safe fallback until trained SAC artifact is supplied
        q=max(state.get('north_queue',0),state.get('south_queue',0),state.get('east_queue',0),state.get('west_queue',0))
        return 'EXTEND GREEN' if q>15 else 'HOLD'
