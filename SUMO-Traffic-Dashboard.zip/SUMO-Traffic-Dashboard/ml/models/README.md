Place the trained Stable-Baselines3 SAC model here as:
sac_controller.zip

The dashboard will automatically load it when present.
