import sumolib

net = sumolib.net.readNet("study_areas/study_area_extracted.net.xml")

types = {}

for edge in net.getEdges():

    if edge.getFunction() != "":
        continue

    t = edge.getType()

    types[t] = types.get(t, 0) + 1

for t, n in sorted(types.items()):
    print(f"{t}: {n}")