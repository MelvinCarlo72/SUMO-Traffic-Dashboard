import csv
import sumolib

# Load SUMO network
net = sumolib.net.readNet("study_areas/study_area_extracted.net.xml")

# Determine network boundaries
xmin = ymin = float("inf")
xmax = ymax = float("-inf")

for node in net.getNodes():
    x, y = node.getCoord()
    xmin = min(xmin, x)
    xmax = max(xmax, x)
    ymin = min(ymin, y)
    ymax = max(ymax, y)

margin = 20  # meters from boundary

with open("outputs/boundary_edges.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow([
        "EdgeID",
        "Boundary",
        "FromX",
        "FromY",
        "ToX",
        "ToY"
    ])

    for edge in net.getEdges():

        # Skip internal/pedestrian edges
        if edge.getFunction() != "":
            continue

        fx, fy = edge.getFromNode().getCoord()
        tx, ty = edge.getToNode().getCoord()

        boundary = None

        # Classify by the FROM node
        if fx <= xmin + margin:
            boundary = "WEST"

        elif fx >= xmax - margin:
            boundary = "EAST"

        elif fy <= ymin + margin:
            boundary = "SOUTH"

        elif fy >= ymax - margin:
            boundary = "NORTH"

        if boundary is not None:
            writer.writerow([
                edge.getID(),
                boundary,
                fx,
                fy,
                tx,
                ty
            ])

print("Done! Exported boundary_edges.csv")