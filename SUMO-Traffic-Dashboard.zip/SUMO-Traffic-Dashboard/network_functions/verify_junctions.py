import sumolib
import matplotlib.pyplot as plt

NET_FILE = "study_areas/.net.xml"

SURVEY_JUNCTIONS = [
    "3339675390",   # Intersection 3
    "313908392",    # Intersection 2
    "313910687"     # Intersection 1
]

net = sumolib.net.readNet(NET_FILE)

junctions = {n.getID(): n for n in net.getNodes()}

plt.figure(figsize=(14,14))

# Draw the entire network
for edge in net.getEdges():

    if edge.getFunction() != "":
        continue

    shape = edge.getShape()

    xs = [p[0] for p in shape]
    ys = [p[1] for p in shape]

    plt.plot(xs, ys, color="lightgray", linewidth=0.3)

# Highlight the survey intersections
for jid in SURVEY_JUNCTIONS:

    if jid not in junctions:
        print(f"{jid} not found")
        continue

    node = junctions[jid]
    x, y = node.getCoord()

    plt.scatter(x, y, s=120, c="red")
    plt.text(x, y, jid, fontsize=8)

plt.axis("equal")
plt.title("Survey Intersections")
plt.show()