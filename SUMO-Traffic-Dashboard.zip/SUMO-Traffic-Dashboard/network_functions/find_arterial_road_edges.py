import sumolib
import matplotlib.pyplot as plt

net = sumolib.net.readNet("study_areas/study_area_extracted.net.xml")

ARTERIAL_TYPES = {
    "highway.trunk",
    "highway.primary",
    "highway.secondary",
    # Uncomment if needed
    # "highway.tertiary",
}

plt.figure(figsize=(14,14))

for edge in net.getEdges():

    if edge.getFunction() != "":
        continue

    shape = edge.getShape()

    xs = [p[0] for p in shape]
    ys = [p[1] for p in shape]

    if edge.getType() in ARTERIAL_TYPES:
        plt.plot(xs, ys,
                 color="red",
                 linewidth=2)
    else:
        plt.plot(xs, ys,
                 color="lightgray",
                 linewidth=0.3)

plt.axis("equal")
plt.title("Arterial Roads")
plt.show()