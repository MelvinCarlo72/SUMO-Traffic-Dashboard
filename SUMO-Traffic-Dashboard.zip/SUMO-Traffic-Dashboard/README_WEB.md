# SUMO Traffic Dashboard — Web Build

> The current UI lives in `webapp/` and is started by `RUN_WEB.bat`. `web.backend.main:app` now serves the same app. The status bar shows "UI v2" when you are on the new build; press Ctrl+F5 if the browser shows the old look.

## Run

1. Install Python 3.11+ and SUMO 1.27+.
2. Open this folder in a terminal.
3. Run `RUN_WEB.bat` or:
   `python -m pip install -r requirements-web.txt`
   `python -m uvicorn web.backend.main:app --host 127.0.0.1 --port 8000`
4. Open `http://127.0.0.1:8000`.

## Current scope
- San Fernando, Pampanga
- SACOP + Del Rosario only
- Browser-based network renderer
- Run/Stop/Reset controls
- SAC controller interface and demo fallback
- Live metrics and analytics

## Connecting the real simulation
The next integration point is `web/backend/main.py`: replace the demo Simulation.step loop with a TraCI-backed SimulationManager that starts SUMO, reads vehicle/lane/traffic-light state, sends state to the SAC controller, applies the selected phase through TraCI, and returns the state to the browser.

Do not embed `sumo-gui` in the browser. For the final web version, run SUMO headless and render the network in the browser.
