# Connecting real SUMO to the dashboard

Until the scenario, traffic-light IDs, SUMO executable, and Python dependencies are configured, the app uses clearly labeled demo data.

## 1. Install SUMO
- Install SUMO and make `sumo` available on PATH, or set `SUMO_BINARY` to its executable. Set `SUMO_HOME` if your SUMO installation requires it.
- `RUN_APP.bat` and `BUILD_EXE.bat` install `traci` and `sumolib` from `webapp/requirements.txt`.

## 2. Supply the verified scenario in `pipeline/06_simulation/`
The dashboard needs a SUMO network (`.net.xml`) containing the SACOP and Del Rosario junctions, route demand (`.rou.xml`), and `scenario.sumocfg` that refers to those files. Put the files in this folder and use paths relative to the config.

The attached SACOP export contains training/evaluation results, YOLO movement counts, audit data, and model checkpoints. It does **not** contain a `.net.xml`, `.rou.xml`, or runnable `.sumocfg`. `SACOP/SUMO/training/study_manifest.json` records scenario paths from another computer under `...\\work\\sacop_j4\\`; those paths are not files in the export. The audit and movement labels describe J02 but do not supply a runnable junction network. The actual study area therefore cannot be established from the supplied archives. Do not substitute an unrelated or synthetic network and identify it as the study network.

The cleaned package removes the legacy `study_areas/*.net.xml` networks and generated `outputs/` artifacts because they are not identified as the verified SACOP study data. The actual study area and junction geometry must be confirmed before supplying a replacement network.

## 3. Configure the signal IDs
After the verified network is supplied, run:
```
python tools/list_traffic_lights.py pipeline/06_simulation/<network.net.xml>
```
The tool lists signalized junction IDs, locations, and incoming road directions. Copy `tls_ids.json.example` to `tls_ids.json` and enter the verified IDs for `sacop` and `del_rosario`. SACOP's expected approaches in this dashboard are S, E, and W; verify that geometry against the study before relying on it. The dashboard's current movement assumptions may also need adjustment to match the verified lane connections and signal plan.

## 4. Validate and run
From the project root, run `python tools/check_sumo_setup.py`. It checks SUMO availability, config references, referenced files, and configured signal IDs. It reports missing prerequisites and does not generate any scenario inputs. Then start the app and choose Run. A successful live connection is labeled SUMO live data; otherwise the app reports demo data and an error.

The scenario selector labels a run; the route files supply its demand. Use verified route files for each demand scenario. The dashboard reads approach queues, counts, waiting time, speed, occupancy, signal state, and network-wide metrics from TraCI.
