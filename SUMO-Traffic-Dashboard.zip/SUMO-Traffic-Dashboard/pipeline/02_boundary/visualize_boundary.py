import csv
import sys
from pathlib import Path

# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import sumolib
import matplotlib.pyplot as plt


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / ".net.xml"
)

SPINE_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "backbone_edges.txt"
)

STUDY_AREA_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_area_edges.txt"
)

BUFFER_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "boundary_buffer_edges.txt"
)

BOUNDARY_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "boundary_edges.csv"
)

VISUALIZATION_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "visualizations"
    / "network"
    / "boundary_visualization.png"
)

SHOW_FULL_NETWORK = True


# =====================================================
# CATEGORY COLORS
# =====================================================

COLORS = {
    "network": "lightgray",
    "buffer": "orange",
    "study_area": "royalblue",
    "spine": "black",
    "entry": "green",
    "exit": "red",
}


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD EDGE SETS
# =====================================================

def load_edges(filename):

    with open(filename) as f:

        return {
            line.strip()
            for line in f
            if line.strip()
        }


spine_edges = load_edges(
    SPINE_FILE
)

study_edges = load_edges(
    STUDY_AREA_FILE
)

buffer_edges = load_edges(
    BUFFER_FILE
)


# =====================================================
# LOAD BOUNDARY CLASSIFICATION
# =====================================================

entry_edges = set()
exit_edges = set()

with open(
    BOUNDARY_FILE,
    newline=""
) as f:

    reader = csv.DictReader(f)

    for row in reader:

        edge_id = row["edge_id"]
        direction = row["direction"]

        if direction == "ENTRY":

            entry_edges.add(edge_id)

        elif direction == "EXIT":

            exit_edges.add(edge_id)


# =====================================================
# DRAW EDGE GROUP
# =====================================================

def draw_edges(
    edge_ids,
    color,
    linewidth,
    alpha,
):

    for edge_id in edge_ids:

        edge = net.getEdge(edge_id)

        if edge is None:
            continue

        shape = edge.getShape()

        if len(shape) < 2:
            continue

        xs = [
            point[0]
            for point in shape
        ]

        ys = [
            point[1]
            for point in shape
        ]

        plt.plot(
            xs,
            ys,
            color=color,
            linewidth=linewidth,
            alpha=alpha,
        )


# =====================================================
# FULL NETWORK
# =====================================================

if SHOW_FULL_NETWORK:

    for edge in net.getEdges():

        if edge.isSpecial():
            continue

        shape = edge.getShape()

        if len(shape) < 2:
            continue

        xs = [
            point[0]
            for point in shape
        ]

        ys = [
            point[1]
            for point in shape
        ]

        plt.plot(
            xs,
            ys,
            color=COLORS["network"],
            linewidth=0.4,
            alpha=0.25,
        )


# =====================================================
# BUFFER
# =====================================================

draw_edges(
    buffer_edges,
    color=COLORS["buffer"],
    linewidth=1.2,
    alpha=0.45,
)


# =====================================================
# STUDY AREA
# =====================================================

draw_edges(
    study_edges,
    color=COLORS["study_area"],
    linewidth=1.8,
    alpha=0.65,
)


# =====================================================
# SPINE
# =====================================================

draw_edges(
    spine_edges,
    color=COLORS["spine"],
    linewidth=3.5,
    alpha=1.0,
)


# =====================================================
# ENTRY
# =====================================================

draw_edges(
    entry_edges,
    color=COLORS["entry"],
    linewidth=5.0,
    alpha=1.0,
)


# =====================================================
# EXIT
# =====================================================

draw_edges(
    exit_edges,
    color=COLORS["exit"],
    linewidth=5.0,
    alpha=1.0,
)


# =====================================================
# LEGEND
# =====================================================

legend_items = [
    ("Network", COLORS["network"], 2),
    ("Boundary buffer", COLORS["buffer"], 2),
    ("Study area", COLORS["study_area"], 3),
    ("Spine", COLORS["spine"], 4),
    ("Entry", COLORS["entry"], 4),
    ("Exit", COLORS["exit"], 4),
]

for label, color, linewidth in legend_items:

    plt.plot(
        [],
        [],
        color=color,
        linewidth=linewidth,
        label=label,
    )


# =====================================================
# DISPLAY
# =====================================================

plt.axis("equal")

plt.title(
    "SUMO Study Network Boundary Visualization"
)

plt.legend(
    loc="upper right"
)

plt.tight_layout()


# =====================================================
# SAVE VISUALIZATION
# =====================================================

VISUALIZATION_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

plt.savefig(
    VISUALIZATION_OUTPUT,
    dpi=300,
    bbox_inches="tight",
)

plt.show()


# =====================================================
# SUMMARY
# =====================================================

print(
    f"""
Boundary Visualization
{'=' * 70}

Study area edges:  {len(study_edges)}
Buffer edges:      {len(buffer_edges)}
Entry edges:       {len(entry_edges)}
Exit edges:        {len(exit_edges)}
Boundary edges:    {len(entry_edges | exit_edges)}

Visualization:
{VISUALIZATION_OUTPUT}
"""
)