import csv
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import sumolib


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)

STUDY_AREA_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_area_edges.txt"
)

BUFFER_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "boundary_buffer_edges.txt"
)

DATA_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "boundary_edges.csv"
)

SUMMARY_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "boundary_detection.txt"
)


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD EDGE SETS
# =====================================================

def load_edges(filename):

    with open(
        filename,
        encoding="utf-8",
    ) as f:

        return {
            line.strip()
            for line in f
            if line.strip()
        }


study_edges = load_edges(
    STUDY_AREA_FILE
)

buffer_edges = load_edges(
    BUFFER_FILE
)


# =====================================================
# FIND REVERSE EDGE
# =====================================================

def find_reverse_edge(edge):

    from_id = (
        edge
        .getFromNode()
        .getID()
    )

    to_node = edge.getToNode()

    matches = []

    for candidate in (
        to_node.getOutgoing()
    ):

        if (
            candidate
            .getToNode()
            .getID()
            == from_id
        ):

            matches.append(candidate)

    if not matches:
        return None

    return matches[0]


# =====================================================
# FIND PREDECESSOR EDGES
# =====================================================

def find_boundary_predecessors(edge):

    from_node = edge.getFromNode()

    predecessors = []

    for candidate in (
        from_node.getIncoming()
    ):

        if candidate.isSpecial():
            continue

        predecessors.append(
            candidate
        )

    return predecessors


# =====================================================
# DETECT BOUNDARY FROM STUDY-AREA SIDE
# =====================================================

entry_edges = set()
exit_edges = set()


for edge_id in study_edges:

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue


    # -------------------------------------------------
    # EXIT
    #
    # STUDY EDGE -> BUFFER EDGE
    # -------------------------------------------------

    for next_edge in (
        edge.getOutgoing()
    ):

        if (
            next_edge.getID()
            in buffer_edges
        ):

            exit_edges.add(
                edge_id
            )

            break


    # -------------------------------------------------
    # ENTRY
    #
    # BUFFER EDGE -> STUDY EDGE
    # -------------------------------------------------

    predecessors = (
        find_boundary_predecessors(
            edge
        )
    )

    for previous_edge in predecessors:

        if (
            previous_edge.getID()
            in buffer_edges
        ):

            entry_edges.add(
                edge_id
            )

            break


# =====================================================
# CHECK FOR OVERLAP
# =====================================================

overlapping_edges = (
    entry_edges
    &
    exit_edges
)

if overlapping_edges:

    raise RuntimeError(
        "Boundary classification error: "
        f"{len(overlapping_edges)} study-area "
        "edges are classified as both ENTRY "
        "and EXIT."
    )


# =====================================================
# BUILD BOUNDARY SET
# =====================================================

boundary_edges = (
    entry_edges
    |
    exit_edges
)


# =====================================================
# DETERMINE COUNTERPARTS
# =====================================================

records = []

paired_count = 0
unpaired_count = 0

counterpart_study = 0
counterpart_buffer = 0
counterpart_outside = 0
counterpart_none = 0


for edge_id in sorted(
    boundary_edges
):

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue


    # -------------------------------------------------
    # DIRECTION
    # -------------------------------------------------

    if edge_id in entry_edges:

        direction = "ENTRY"

    else:

        direction = "EXIT"


    # -------------------------------------------------
    # FIND CORRESPONDING OPPOSITE EDGE
    # -------------------------------------------------

    reverse = find_reverse_edge(
        edge
    )


    paired_edge = ""
    paired_location = ""


    if reverse is None:

        counterpart_none += 1
        unpaired_count += 1

    else:

        paired_edge = reverse.getID()

        paired_count += 1


        if paired_edge in study_edges:

            paired_location = "STUDY"
            counterpart_study += 1

        elif paired_edge in buffer_edges:

            paired_location = "BUFFER"
            counterpart_buffer += 1

        else:

            paired_location = "OUTSIDE"
            counterpart_outside += 1


    # -------------------------------------------------
    # RECORD
    # -------------------------------------------------

    records.append({
        "edge_id": edge_id,
        "direction": direction,
        "paired_edge": paired_edge,
        "paired_location": paired_location,
        "road_type": edge.getType(),
    })


# =====================================================
# EXPORT CSV
# =====================================================

DATA_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True
)

with open(
    DATA_OUTPUT,
    "w",
    newline="",
    encoding="utf-8",
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=[
            "edge_id",
            "direction",
            "paired_edge",
            "paired_location",
            "road_type",
        ]
    )

    writer.writeheader()
    writer.writerows(records)


# =====================================================
# SUMMARY
# =====================================================

summary = f"""
SUMO BOUNDARY EDGE DETECTION
{'=' * 70}

EDGE SETS
{'-' * 70}
Study area edges:             {len(study_edges)}
Buffer edges:                 {len(buffer_edges)}

BOUNDARY
{'-' * 70}
Boundary edges:               {len(boundary_edges)}
Entry edges:                  {len(entry_edges)}
Exit edges:                   {len(exit_edges)}

CLASSIFICATION
{'-' * 70}
Study -> Buffer exits:        {len(exit_edges)}
Buffer -> Study entries:      {len(entry_edges)}
Overlapping edges:            {len(overlapping_edges)}

COUNTERPART DIAGNOSTICS
{'-' * 70}
With counterpart:             {paired_count}
Without counterpart:          {unpaired_count}

Counterpart in study:         {counterpart_study}
Counterpart in buffer:        {counterpart_buffer}
Counterpart outside:          {counterpart_outside}
No counterpart:               {counterpart_none}

VALIDATION
{'-' * 70}
Entry + Exit:                 {len(entry_edges) + len(exit_edges)}
Boundary total:               {len(boundary_edges)}

NOTE
{'-' * 70}
Boundary classification is based exclusively
on study-area edges crossing into or from the
buffer.

Buffer edges are never classified as boundary
edges.

Opposite-direction counterparts are recorded
only as diagnostic metadata and do not modify
the boundary classification.

OUTPUTS
{'-' * 70}
Boundary data:                {DATA_OUTPUT}
Summary:                      {SUMMARY_OUTPUT}
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True
)

with open(
    SUMMARY_OUTPUT,
    "w",
    encoding="utf-8",
) as f:

    f.write(
        summary.strip()
    )


# =====================================================
# CONSOLE OUTPUT
# =====================================================

print(summary)