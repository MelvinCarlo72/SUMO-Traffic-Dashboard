import csv
import sys
from pathlib import Path
from collections import defaultdict, deque

import sumolib

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

from config.study_config import SURVEY_JUNCTIONS


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)

BOUNDARY_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "boundary_edges.csv"
)

DATA_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "approach_analysis.csv"
)

SUMMARY_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "approach_analysis.txt"
)

INTERSECTION_SEARCH_DISTANCE = 3000
CLOSE_TO_INTERSECTION_DISTANCE = 500


ROAD_HIERARCHY = {
    "highway.trunk": 1,
    "highway.primary": 2,
    "highway.secondary": 3,
    "highway.tertiary": 4,
    "highway.unclassified": 5,
    "highway.residential": 6,
    "highway.service": 7,
}


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD BOUNDARY DATA
# =====================================================

boundary_edges = []

with open(
    BOUNDARY_FILE,
    newline="",
    encoding="utf-8",
) as f:

    reader = csv.DictReader(f)

    for row in reader:
        boundary_edges.append(row)


# =====================================================
# FIND SURVEY INTERSECTIONS
# =====================================================

intersection_nodes = {}

for junction_id in SURVEY_JUNCTIONS:

    node = net.getNode(junction_id)

    if node is None:

        print(
            f"WARNING: Junction not found: "
            f"{junction_id}"
        )

        continue

    intersection_nodes[junction_id] = node


print(
    f"Survey intersections found: "
    f"{len(intersection_nodes)}"
)


# =====================================================
# FIND NEAREST INTERSECTION
# =====================================================

def find_nearest_intersection(
    start_edge,
    direction,
):

    # -------------------------------------------------
    # ENTRY
    #
    # Buffer -> Study -> Intersection
    #
    # Search forward from the edge's TO node.
    # -------------------------------------------------

    if direction == "ENTRY":

        start_node = start_edge.getToNode()

        queue = deque([
            (start_node, 0.0)
        ])

        visited = {
            start_node.getID(): 0.0
        }

        while queue:

            node, distance = queue.popleft()

            node_id = node.getID()

            if node_id in intersection_nodes:

                return (
                    node_id,
                    distance,
                )

            for edge in node.getOutgoing():

                if edge.isSpecial():
                    continue

                if edge.getFunction() != "":
                    continue

                next_node = edge.getToNode()
                next_node_id = next_node.getID()

                next_distance = (
                    distance
                    + edge.getLength()
                )

                if (
                    next_distance
                    > INTERSECTION_SEARCH_DISTANCE
                ):
                    continue

                if (
                    next_node_id not in visited
                    or next_distance
                    < visited[next_node_id]
                ):

                    visited[next_node_id] = (
                        next_distance
                    )

                    queue.append(
                        (
                            next_node,
                            next_distance,
                        )
                    )


    # -------------------------------------------------
    # EXIT
    #
    # Intersection -> Study -> Buffer
    #
    # Search backward from the edge's FROM node.
    # -------------------------------------------------

    elif direction == "EXIT":

        start_node = start_edge.getFromNode()

        queue = deque([
            (start_node, 0.0)
        ])

        visited = {
            start_node.getID(): 0.0
        }

        while queue:

            node, distance = queue.popleft()

            node_id = node.getID()

            if node_id in intersection_nodes:

                return (
                    node_id,
                    distance,
                )

            for edge in node.getIncoming():

                if edge.isSpecial():
                    continue

                if edge.getFunction() != "":
                    continue

                previous_node = edge.getFromNode()
                previous_node_id = (
                    previous_node.getID()
                )

                next_distance = (
                    distance
                    + edge.getLength()
                )

                if (
                    next_distance
                    > INTERSECTION_SEARCH_DISTANCE
                ):
                    continue

                if (
                    previous_node_id not in visited
                    or next_distance
                    < visited[previous_node_id]
                ):

                    visited[previous_node_id] = (
                        next_distance
                    )

                    queue.append(
                        (
                            previous_node,
                            next_distance,
                        )
                    )

    return None, None


# =====================================================
# ROAD CLASSIFICATION
# =====================================================

def classify_road(road_type):

    hierarchy = ROAD_HIERARCHY.get(
        road_type,
        99,
    )

    if hierarchy <= 2:
        return "MAJOR"

    if hierarchy <= 4:
        return "SECONDARY"

    return "LOCAL"


# =====================================================
# RELEVANCE
# =====================================================

def determine_relevance(
    classification,
    distance,
):

    if distance is None:
        return "NO_INTERSECTION_ACCESS"

    if (
        classification == "MAJOR"
        and distance <= CLOSE_TO_INTERSECTION_DISTANCE
    ):
        return "HIGH"

    if (
        classification == "SECONDARY"
        and distance <= CLOSE_TO_INTERSECTION_DISTANCE
    ):
        return "HIGH"

    if (
        classification == "MAJOR"
        or classification == "SECONDARY"
    ):
        return "MODERATE"

    if (
        classification == "LOCAL"
        and distance <= CLOSE_TO_INTERSECTION_DISTANCE
    ):
        return "POTENTIAL_LOCAL"

    return "LOW"


# =====================================================
# ANALYZE APPROACH
# =====================================================

def analyze_approach(row):

    edge_id = row["edge_id"]
    direction = row["direction"]

    edge = net.getEdge(edge_id)

    if edge is None:
        return None

    road_type = edge.getType()

    hierarchy = ROAD_HIERARCHY.get(
        road_type,
        99,
    )

    classification = classify_road(
        road_type
    )

    intersection_id, distance = (
        find_nearest_intersection(
            edge,
            direction,
        )
    )

    intersection_access = (
        "YES"
        if intersection_id is not None
        else "NO"
    )

    if distance is not None:
        distance = round(
            distance,
            2,
        )

    relevance = determine_relevance(
        classification,
        distance,
    )

    from_node = edge.getFromNode()
    to_node = edge.getToNode()

    from_x, from_y = from_node.getCoord()
    to_x, to_y = to_node.getCoord()

    return {
        "edge_id": edge_id,
        "direction": direction,
        "road_type": road_type,
        "hierarchy": hierarchy,
        "classification": classification,
        "lanes": edge.getLaneNumber(),
        "speed": edge.getSpeed(),
        "length": edge.getLength(),
        "intersection_access": intersection_access,
        "nearest_intersection": (
            intersection_id
            or ""
        ),
        "intersection_distance": (
            distance
            if distance is not None
            else ""
        ),
        "relevance": relevance,
        "from_node": from_node.getID(),
        "to_node": to_node.getID(),
        "from_x": from_x,
        "from_y": from_y,
        "to_x": to_x,
        "to_y": to_y,
    }


# =====================================================
# BUILD ANALYSIS
# =====================================================

approaches = []

for row in boundary_edges:

    result = analyze_approach(row)

    if result:
        approaches.append(result)


# =====================================================
# SUMMARY COUNTS
# =====================================================

classification_counts = defaultdict(
    lambda: {
        "ENTRY": 0,
        "EXIT": 0,
    }
)

access_counts = defaultdict(
    lambda: {
        "ENTRY": 0,
        "EXIT": 0,
    }
)

relevance_counts = defaultdict(
    lambda: {
        "ENTRY": 0,
        "EXIT": 0,
    }
)

road_type_counts = defaultdict(
    lambda: {
        "ENTRY": 0,
        "EXIT": 0,
    }
)


for approach in approaches:

    direction = approach["direction"]

    classification_counts[
        approach["classification"]
    ][direction] += 1

    access_counts[
        approach["intersection_access"]
    ][direction] += 1

    relevance_counts[
        approach["relevance"]
    ][direction] += 1

    road_type_counts[
        approach["road_type"]
    ][direction] += 1


entry_count = sum(
    1
    for approach in approaches
    if approach["direction"] == "ENTRY"
)

exit_count = sum(
    1
    for approach in approaches
    if approach["direction"] == "EXIT"
)


# =====================================================
# WRITE CSV
# =====================================================

DATA_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

fieldnames = [
    "edge_id",
    "direction",
    "road_type",
    "hierarchy",
    "classification",
    "lanes",
    "speed",
    "length",
    "intersection_access",
    "nearest_intersection",
    "intersection_distance",
    "relevance",
    "from_node",
    "to_node",
    "from_x",
    "from_y",
    "to_x",
    "to_y",
]

with open(
    DATA_OUTPUT,
    "w",
    newline="",
    encoding="utf-8",
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
    )

    writer.writeheader()
    writer.writerows(approaches)


# =====================================================
# BUILD SUMMARY
# =====================================================

def format_section_counts(
    groups,
    labels,
):

    lines = []

    lines.append(
        f"{'':30}"
        f"{'ENTRY':>10}"
        f"{'EXIT':>10}"
        f"{'TOTAL':>10}"
    )

    lines.append(
        "-" * 70
    )

    for label in labels:

        entry = groups[label]["ENTRY"]
        exit_count = groups[label]["EXIT"]
        total = entry + exit_count

        lines.append(
            f"{label:<30}"
            f"{entry:>10}"
            f"{exit_count:>10}"
            f"{total:>10}"
        )

    return "\n".join(lines)


classification_table = format_section_counts(
    classification_counts,
    [
        "MAJOR",
        "SECONDARY",
        "LOCAL",
    ],
)

access_table = format_section_counts(
    access_counts,
    [
        "YES",
        "NO",
    ],
)

relevance_table = format_section_counts(
    relevance_counts,
    [
        "HIGH",
        "MODERATE",
        "POTENTIAL_LOCAL",
        "LOW",
        "NO_INTERSECTION_ACCESS",
    ],
)

road_types = [
    road_type
    for road_type in ROAD_HIERARCHY
    if road_type in road_type_counts
]

road_type_table = format_section_counts(
    road_type_counts,
    road_types,
)


summary = f"""
SUMO BOUNDARY APPROACH ANALYSIS
{'=' * 70}

OVERVIEW
{'-' * 70}
{'Boundary edges':<30}{len(approaches):>10}
{'Entry edges':<30}{entry_count:>10}
{'Exit edges':<30}{exit_count:>10}


ROAD CLASSIFICATION
{'-' * 70}
{classification_table}


INTERSECTION ACCESS
{'-' * 70}
{access_table}


APPROACH RELEVANCE
{'-' * 70}
{relevance_table}


ROAD TYPE
{'-' * 70}
{road_type_table}


OUTPUTS
{'-' * 70}
Detailed data:       {DATA_OUTPUT}
Summary:             {SUMMARY_OUTPUT}
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with open(
    SUMMARY_OUTPUT,
    "w",
    encoding="utf-8",
) as f:

    f.write(
        summary.strip()
    )


# =====================================================
# CONSOLE OUTPUT
# =====================================================

print()
print(summary)