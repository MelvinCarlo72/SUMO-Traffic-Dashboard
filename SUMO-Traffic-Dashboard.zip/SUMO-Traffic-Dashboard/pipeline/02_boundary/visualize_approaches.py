import csv
import sys
from pathlib import Path

# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

from config.study_config import SURVEY_JUNCTIONS

import matplotlib.pyplot as plt
import sumolib


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)

ANALYSIS_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "approach_analysis.csv"
)

VISUALIZATION_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "visualizations"
    / "boundary"
    / "approach_relevance.png"
)

SHOW_FULL_NETWORK = True


# =====================================================
# RELEVANCE STYLES
# =====================================================

RELEVANCE_STYLES = {
    "HIGH": {
        "color": "red",
        "linewidth": 4,
        "zorder": 6,
    },

    "MODERATE": {
        "color": "orange",
        "linewidth": 3,
        "zorder": 5,
    },

    "POTENTIAL_LOCAL": {
        "color": "gold",
        "linewidth": 2.5,
        "zorder": 4,
    },

    "LOW": {
        "color": "gray",
        "linewidth": 1.5,
        "zorder": 3,
    },

    "NO_INTERSECTION_ACCESS": {
        "color": "black",
        "linewidth": 3,
        "zorder": 7,
    },
}


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD APPROACH ANALYSIS
# =====================================================

approaches = []

with open(
    ANALYSIS_FILE,
    newline=""
) as f:

    reader = csv.DictReader(f)

    approaches.extend(reader)


# =====================================================
# CREATE FIGURE
# =====================================================

plt.figure(
    figsize=(14, 12)
)


# =====================================================
# DRAW FULL NETWORK
# =====================================================

if SHOW_FULL_NETWORK:

    for edge in net.getEdges():

        if edge.isSpecial():
            continue

        shape = edge.getShape()

        if len(shape) < 2:
            continue

        xs = [
            point[0]
            for point in shape
        ]

        ys = [
            point[1]
            for point in shape
        ]

        plt.plot(
            xs,
            ys,
            color="lightgray",
            linewidth=0.5,
            alpha=0.35,
            zorder=1,
        )


# =====================================================
# DRAW APPROACHES
# =====================================================

drawn_categories = set()

for approach in approaches:

    edge_id = approach["edge_id"]
    relevance = approach["relevance"]

    if relevance not in RELEVANCE_STYLES:
        continue

    edge = net.getEdge(edge_id)

    if edge is None:
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    xs = [
        point[0]
        for point in shape
    ]

    ys = [
        point[1]
        for point in shape
    ]

    style = RELEVANCE_STYLES[
        relevance
    ]

    label = None

    if relevance not in drawn_categories:

        label = relevance

        drawn_categories.add(
            relevance
        )

    plt.plot(
        xs,
        ys,
        color=style["color"],
        linewidth=style["linewidth"],
        alpha=0.95,
        label=label,
        zorder=style["zorder"],
    )


# =====================================================
# DRAW SURVEY INTERSECTIONS
# =====================================================

for junction_id in SURVEY_JUNCTIONS:

    node = net.getNode(junction_id)

    if node is None:
        print(
            f"WARNING: Junction not found: {junction_id}"
        )
        continue

    x, y = node.getCoord()

    plt.scatter(
        x,
        y,
        s=100,
        color="blue",
        edgecolors="black",
        linewidths=1,
        zorder=10,
    )

    plt.annotate(
        junction_id,
        (x, y),
        xytext=(7, 7),
        textcoords="offset points",
        fontsize=8,
        fontweight="bold",
        zorder=11,
    )


# =====================================================
# LEGEND
# =====================================================

plt.legend(
    title="Approach Relevance",
    loc="upper right",
)


# =====================================================
# DISPLAY
# =====================================================

plt.axis("equal")

plt.title(
    "Boundary Approach Relevance"
)

plt.xlabel(
    "X Coordinate"
)

plt.ylabel(
    "Y Coordinate"
)

plt.tight_layout()


# =====================================================
# SAVE VISUALIZATION
# =====================================================

VISUALIZATION_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

plt.savefig(
    VISUALIZATION_OUTPUT,
    dpi=300,
    bbox_inches="tight",
)

plt.show()


# =====================================================
# SUMMARY
# =====================================================

relevance_counts = {}

for approach in approaches:

    relevance = approach["relevance"]

    relevance_counts[relevance] = (
        relevance_counts.get(relevance, 0)
        + 1
    )


summary = f"""
APPROACH RELEVANCE VISUALIZATION
{'=' * 70}

Approaches:             {len(approaches)}

HIGH:                   {relevance_counts.get('HIGH', 0)}
MODERATE:               {relevance_counts.get('MODERATE', 0)}
POTENTIAL_LOCAL:        {relevance_counts.get('POTENTIAL_LOCAL', 0)}
LOW:                    {relevance_counts.get('LOW', 0)}
NO_INTERSECTION_ACCESS: {relevance_counts.get('NO_INTERSECTION_ACCESS', 0)}

Visualization:
{VISUALIZATION_OUTPUT}
"""

print(summary)