import csv
import sys
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import sumolib


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)

BOUNDARY_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "boundary_edges.csv"
)

STUDY_AREA_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_area_edges.txt"
)

BUFFER_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "boundary_buffer_edges.txt"
)

SUMMARY_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "boundary_diagnosis.txt"
)


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD EDGE SETS
# =====================================================

def load_edges(filename):

    with open(
        filename,
        encoding="utf-8",
    ) as f:

        return {
            line.strip()
            for line in f
            if line.strip()
        }


study_edges = load_edges(
    STUDY_AREA_FILE
)

buffer_edges = load_edges(
    BUFFER_FILE
)


# =====================================================
# LOAD BOUNDARY DATA
# =====================================================

boundary_records = []

with open(
    BOUNDARY_FILE,
    newline="",
    encoding="utf-8",
) as f:

    reader = csv.DictReader(f)

    for record in reader:
        boundary_records.append(record)


# =====================================================
# FIND REVERSE EDGE
# =====================================================

def find_reverse_edges(edge):

    from_id = (
        edge
        .getFromNode()
        .getID()
    )

    to_node = edge.getToNode()

    matches = []

    for candidate in (
        to_node.getOutgoing()
    ):

        if (
            candidate
            .getToNode()
            .getID()
            == from_id
        ):

            matches.append(candidate)

    return matches


# =====================================================
# DIAGNOSE
# =====================================================

diagnostics = []

for record in boundary_records:

    edge_id = record["edge_id"]
    direction = record["direction"]

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue

    reverse_edges = find_reverse_edges(
        edge
    )

    if not reverse_edges:

        diagnostics.append({
            "edge": edge,
            "direction": direction,
            "reverse": None,
            "location": "NONE",
        })

        continue

    for reverse in reverse_edges:

        reverse_id = reverse.getID()

        if reverse_id in study_edges:

            location = "STUDY"

        elif reverse_id in buffer_edges:

            location = "BUFFER"

        else:

            location = "OUTSIDE"

        diagnostics.append({
            "edge": edge,
            "direction": direction,
            "reverse": reverse,
            "location": location,
        })


# =====================================================
# IDENTIFY SUSPICIOUS CASES
# =====================================================

suspicious = []

for item in diagnostics:

    if (
        item["direction"] == "ENTRY"
        and item["location"] == "BUFFER"
    ):

        suspicious.append(item)

    elif (
        item["direction"] == "EXIT"
        and item["location"] == "STUDY"
    ):

        suspicious.append(item)


# =====================================================
# STATISTICS
# =====================================================

entry_buffer = sum(
    1
    for item in diagnostics
    if (
        item["direction"] == "ENTRY"
        and item["location"] == "BUFFER"
    )
)

exit_study = sum(
    1
    for item in diagnostics
    if (
        item["direction"] == "EXIT"
        and item["location"] == "STUDY"
    )
)

no_reverse = sum(
    1
    for item in diagnostics
    if item["location"] == "NONE"
)


# =====================================================
# VISUALIZATION
# =====================================================

print(
    "Generating boundary diagnosis..."
)

fig, ax = plt.subplots(
    figsize=(18, 16)
)


# =====================================================
# BUFFER
# =====================================================

for edge_id in buffer_edges:

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    x = [
        point[0]
        for point in shape
    ]

    y = [
        point[1]
        for point in shape
    ]

    ax.plot(
        x,
        y,
        color="lightgray",
        linewidth=1.0,
        alpha=0.65,
        zorder=1,
    )


# =====================================================
# STUDY AREA
# =====================================================

for edge_id in study_edges:

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    x = [
        point[0]
        for point in shape
    ]

    y = [
        point[1]
        for point in shape
    ]

    ax.plot(
        x,
        y,
        color="yellow",
        linewidth=0.9,
        alpha=0.75,
        zorder=2,
    )


# =====================================================
# NORMAL BOUNDARY EDGES
# =====================================================

suspicious_edge_ids = {
    item["edge"].getID()
    for item in suspicious
}


for record in boundary_records:

    edge_id = record["edge_id"]

    if edge_id in suspicious_edge_ids:
        continue

    edge = net.getEdge(
        edge_id
    )

    if edge is None:
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    x = [
        point[0]
        for point in shape
    ]

    y = [
        point[1]
        for point in shape
    ]

    ax.plot(
        x,
        y,
        color="dimgray",
        linewidth=1.5,
        alpha=0.8,
        zorder=3,
    )


# =====================================================
# SUSPICIOUS EDGES
# =====================================================

for item in suspicious:

    boundary_edge = item["edge"]
    reverse_edge = item["reverse"]


    # ---------------------------------------------
    # Boundary edge
    # RED SOLID
    # ---------------------------------------------

    shape = boundary_edge.getShape()

    if len(shape) >= 2:

        x = [
            point[0]
            for point in shape
        ]

        y = [
            point[1]
            for point in shape
        ]

        ax.plot(
            x,
            y,
            color="red",
            linewidth=3.5,
            linestyle=":",
            alpha=1.0,
            zorder=5,
        )


    # ---------------------------------------------
    # Suspected counterpart
    # BLUE DOTTED
    # ---------------------------------------------

    if reverse_edge is not None:

        shape = reverse_edge.getShape()

        if len(shape) >= 2:

            x = [
                point[0]
                for point in shape
            ]

            y = [
                point[1]
                for point in shape
            ]

            ax.plot(
                x,
                y,
                color="blue",
                linewidth=3.5,
                linestyle=":",
                alpha=1.0,
                zorder=6,
            )


# =====================================================
# LEGEND
# =====================================================

legend = [

    Line2D(
        [0],
        [0],
        color="red",
        linewidth=3.5,
        linestyle="-",
        label="Boundary edge",
    ),

    Line2D(
        [0],
        [0],
        color="blue",
        linewidth=3.5,
        linestyle=":",
        label="Suspected counterpart",
    ),

    Line2D(
        [0],
        [0],
        color="gray",
        linewidth=2,
        label="Study area",
    ),

    Line2D(
        [0],
        [0],
        color="lightgray",
        linewidth=2,
        label="Buffer",
    ),
]

ax.legend(
    handles=legend,
    loc="best",
)


# =====================================================
# FORMAT
# =====================================================

ax.set_title(
    "SUMO Boundary Edge Diagnosis",
    fontsize=15,
)

ax.set_xlabel(
    "X"
)

ax.set_ylabel(
    "Y"
)

ax.set_aspect(
    "equal",
    adjustable="box",
)

ax.grid(
    alpha=0.2,
)


plt.tight_layout()


# =====================================================
# SHOW
# =====================================================

print()
print(
    f"Suspicious boundary cases: {len(suspicious)}"
)
print(
    f"ENTRY -> BUFFER: {entry_buffer}"
)
print(
    f"EXIT -> STUDY:   {exit_study}"
)
print(
    f"No reverse:      {no_reverse}"
)
print()
print(
    "Opening visualization..."
)

plt.show()


# =====================================================
# SUMMARY
# =====================================================

summary = f"""
SUMO BOUNDARY DIAGNOSIS
{'=' * 70}

INPUT
{'-' * 70}
Boundary records:             {len(boundary_records)}
Study area edges:             {len(study_edges)}
Buffer edges:                 {len(buffer_edges)}

REVERSE EDGE ANALYSIS
{'-' * 70}
Cases analyzed:               {len(diagnostics)}
No reverse counterpart:       {no_reverse}

SUSPICIOUS CASES
{'-' * 70}
ENTRY -> reverse in BUFFER:   {entry_buffer}
EXIT -> reverse in STUDY:     {exit_study}
Total suspicious:             {len(suspicious)}

VISUALIZATION
{'-' * 70}
Red solid:                    Boundary edge
Blue dotted:                  Suspected counterpart
Gray:                         Study area
Light gray:                   Buffer

This script only diagnoses and visualizes
boundary relationships. It does not modify
any network or edge-list files.
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with open(
    SUMMARY_OUTPUT,
    "w",
    encoding="utf-8",
) as f:

    f.write(
        summary.strip()
    )


print()
print(
    "Boundary diagnosis complete."
)