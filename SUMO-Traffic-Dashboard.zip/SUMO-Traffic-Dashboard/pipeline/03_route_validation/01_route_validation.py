import csv
import sys
from pathlib import Path

import sumolib


# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)

APPROACH_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "approach_analysis.csv"
)

DATA_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "route_validation.csv"
)

SUMMARY_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "route_validation.txt"
)

# None = validate every entry/exit combination
MAX_COMBINATIONS = None


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD APPROACHES
# =====================================================

approaches = []

with open(
    APPROACH_FILE,
    newline=""
) as f:

    reader = csv.DictReader(f)

    approaches.extend(reader)


entries = [
    approach
    for approach in approaches
    if approach["direction"] == "ENTRY"
]

exits = [
    approach
    for approach in approaches
    if approach["direction"] == "EXIT"
]


# =====================================================
# ROUTE VALIDATION
# =====================================================

def find_route(
    entry_edge_id,
    exit_edge_id,
):
    """
    Find the shortest route from an entry
    edge to an exit edge.

    Returns:
        {
            "route": [...],
            "cost": ...
        }

    or None if no route exists.
    """

    start = net.getEdge(
        entry_edge_id
    )

    destination = net.getEdge(
        exit_edge_id
    )

    if start is None or destination is None:
        return None

    try:

        result = net.getShortestPath(
            start,
            destination,
        )

    except Exception:

        return None

    if result is None:
        return None

    route, cost = result

    if not route:
        return None

    return {
        "route": route,
        "cost": cost,
    }


# =====================================================
# VALIDATE ENTRY / EXIT COMBINATIONS
# =====================================================

results = []

combination_count = 0
valid_count = 0
invalid_count = 0


stop_validation = False


for entry in entries:

    for exit_approach in exits:

        if (
            MAX_COMBINATIONS is not None
            and combination_count
            >= MAX_COMBINATIONS
        ):

            stop_validation = True
            break


        combination_count += 1

        entry_id = entry["edge_id"]
        exit_id = exit_approach["edge_id"]


        result = find_route(
            entry_id,
            exit_id,
        )


        if result is None:

            valid_route = "NO"
            route_length = ""
            route_edges = ""

            invalid_count += 1

        else:

            valid_route = "YES"

            route = result["route"]

            route_length = round(
                sum(
                    edge.getLength()
                    for edge in route
                ),
                2,
            )

            route_edges = len(route)

            valid_count += 1


        results.append({
            "entry_edge":
                entry_id,

            "exit_edge":
                exit_id,

            "entry_classification":
                entry["classification"],

            "entry_relevance":
                entry["relevance"],

            "exit_classification":
                exit_approach[
                    "classification"
                ],

            "exit_relevance":
                exit_approach[
                    "relevance"
                ],

            "valid_route":
                valid_route,

            "route_length":
                route_length,

            "route_edges":
                route_edges,
        })


    if stop_validation:
        break


# =====================================================
# VALID ROUTES BY ENTRY RELEVANCE
# =====================================================

relevance_totals = {}

for result in results:

    relevance = result[
        "entry_relevance"
    ]

    if relevance not in relevance_totals:

        relevance_totals[relevance] = {
            "total": 0,
            "valid": 0,
        }

    relevance_totals[
        relevance
    ]["total"] += 1

    if result["valid_route"] == "YES":

        relevance_totals[
            relevance
        ]["valid"] += 1


# =====================================================
# WRITE ROUTE DATA
# =====================================================

DATA_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

fieldnames = [
    "entry_edge",
    "exit_edge",
    "entry_classification",
    "entry_relevance",
    "exit_classification",
    "exit_relevance",
    "valid_route",
    "route_length",
    "route_edges",
]


with open(
    DATA_OUTPUT,
    "w",
    newline="",
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
    )

    writer.writeheader()
    writer.writerows(results)


# =====================================================
# BUILD SUMMARY
# =====================================================

route_validity = (
    valid_count / combination_count * 100
    if combination_count
    else 0
)


relevance_order = [
    "HIGH",
    "MODERATE",
    "POTENTIAL_LOCAL",
    "LOW",
    "NO_INTERSECTION_ACCESS",
]


relevance_lines = []

relevance_lines.append(
    f"{'RELEVANCE':<30}"
    f"{'TESTED':>10}"
    f"{'VALID':>10}"
)

relevance_lines.append(
    "-" * 50
)


for relevance in relevance_order:

    if relevance not in relevance_totals:
        continue

    total = relevance_totals[
        relevance
    ]["total"]

    valid = relevance_totals[
        relevance
    ]["valid"]

    relevance_lines.append(
        f"{relevance:<30}"
        f"{total:>10}"
        f"{valid:>10}"
    )


relevance_table = "\n".join(
    relevance_lines
)


summary = f"""
SUMO ROUTE VALIDATION
{'=' * 70}

OVERVIEW
{'-' * 70}
{'Entry approaches':<30}{len(entries):>10}
{'Exit approaches':<30}{len(exits):>10}
{'Combinations tested':<30}{combination_count:>10}
{'Valid routes':<30}{valid_count:>10}
{'Invalid routes':<30}{invalid_count:>10}
{'Route validity':<30}{route_validity:>9.2f}%


VALID ROUTES BY ENTRY RELEVANCE
{'-' * 70}
{relevance_table}


OUTPUTS
{'-' * 70}
Route data:    {DATA_OUTPUT}
Summary:       {SUMMARY_OUTPUT}
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with open(
    SUMMARY_OUTPUT,
    "w",
) as f:

    f.write(
        summary.strip()
    )


# =====================================================
# CONSOLE OUTPUT
# =====================================================

print(summary)