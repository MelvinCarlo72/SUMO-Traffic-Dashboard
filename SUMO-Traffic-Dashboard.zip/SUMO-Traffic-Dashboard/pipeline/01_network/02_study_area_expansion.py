import sys
from pathlib import Path
from collections import deque

import sumolib
from shapely.geometry import LineString
from shapely.ops import unary_union


# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / ".net.xml"
)

BACKBONE_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "backbone_edges.txt"
)

STUDY_AREA_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_area_edges.txt"
)

BUFFER_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "boundary_buffer_edges.txt"
)

STUDY_NETWORK_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_network_edges.txt"
)

SUMMARY_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "study_network.txt"
)

STUDY_AREA_RADIUS = 400
BUFFER_DISTANCE = 200

TRAVERSE_TYPES = {
    "highway.trunk",
    "highway.primary",
    "highway.secondary",
    "highway.tertiary",
    "highway.unclassified",
    "highway.residential",
    "highway.service",
}


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD BACKBONE
# =====================================================

with open(BACKBONE_FILE) as f:

    backbone_edges = {
        line.strip()
        for line in f
        if line.strip()
    }


# =====================================================
# BUILD EDGE GEOMETRIES
# =====================================================

edge_geometries = {}

for edge in net.getEdges():

    if edge.isSpecial():
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    edge_geometries[edge.getID()] = LineString(
        shape
    )


# =====================================================
# FIND CORRESPONDING REVERSE EDGE
# =====================================================

def find_reverse_edge(edge):

    from_id = edge.getFromNode().getID()
    to_id = edge.getToNode().getID()

    for candidate in edge.getToNode().getOutgoing():

        if candidate.getID() == edge.getID():
            continue

        if (
            candidate.getToNode().getID()
            == from_id
        ):
            return candidate

    return None


# =====================================================
# COMPLETE BIDIRECTIONAL PAIRS
# =====================================================

def complete_edge_pairs(edge_ids):

    completed = set(edge_ids)

    reverse_found = 0
    reverse_added = 0
    reverse_missing = 0

    for edge_id in list(edge_ids):

        edge = net.getEdge(edge_id)

        if edge is None:
            continue

        reverse = find_reverse_edge(edge)

        if reverse is None:

            reverse_missing += 1
            continue

        reverse_found += 1

        reverse_id = reverse.getID()

        if reverse_id not in completed:

            completed.add(reverse_id)
            reverse_added += 1

    return (
        completed,
        reverse_found,
        reverse_added,
        reverse_missing,
    )


# =====================================================
# CREATE BACKBONE GEOMETRY
# =====================================================

backbone_lines = [
    edge_geometries[edge_id]
    for edge_id in backbone_edges
    if edge_id in edge_geometries
]

if not backbone_lines:

    raise RuntimeError(
        "No valid backbone geometries found."
    )


backbone_geometry = unary_union(
    backbone_lines
)

study_area_geometry = backbone_geometry.buffer(
    STUDY_AREA_RADIUS
)


# =====================================================
# INITIAL SPATIAL STUDY-AREA SELECTION
# =====================================================

raw_study_area_edges = set()

for edge_id, geometry in edge_geometries.items():

    if geometry.intersects(
        study_area_geometry
    ):

        raw_study_area_edges.add(edge_id)


raw_study_area_count = len(
    raw_study_area_edges
)


# =====================================================
# TOPOLOGICAL PAIR COMPLETION
# =====================================================

(
    study_area_edges,
    reverse_found,
    reverse_added,
    reverse_missing,
) = complete_edge_pairs(
    raw_study_area_edges
)


# =====================================================
# IDENTIFY STUDY-AREA BOUNDARY NODES
# =====================================================

boundary_nodes = set()

for edge_id in study_area_edges:

    edge = net.getEdge(edge_id)

    if edge is None:
        continue

    from_node = edge.getFromNode()
    to_node = edge.getToNode()

    for connected_edge in (
        from_node.getOutgoing()
    ):

        if (
            connected_edge.getID()
            not in study_area_edges
        ):

            boundary_nodes.add(
                from_node.getID()
            )

            break

    for connected_edge in (
        to_node.getOutgoing()
    ):

        if (
            connected_edge.getID()
            not in study_area_edges
        ):

            boundary_nodes.add(
                to_node.getID()
            )

            break


# =====================================================
# NETWORK BUFFER EXPANSION
# =====================================================

queue = deque()
visited = {}
buffer_edges = set()


for node_id in boundary_nodes:

    queue.append(
        (
            node_id,
            0.0,
        )
    )

    visited[node_id] = 0.0


while queue:

    current_node_id, current_distance = (
        queue.popleft()
    )

    node = net.getNode(
        current_node_id
    )

    for edge in node.getOutgoing():

        if edge.isSpecial():
            continue

        if edge.getFunction() != "":
            continue

        if edge.getType() not in TRAVERSE_TYPES:
            continue

        edge_id = edge.getID()

        if edge_id in study_area_edges:
            continue

        next_distance = (
            current_distance
            + edge.getLength()
        )

        if next_distance > BUFFER_DISTANCE:
            continue

        next_node = edge.getToNode()
        next_node_id = next_node.getID()

        buffer_edges.add(
            edge_id
        )

        if (
            next_node_id not in visited
            or next_distance
            < visited[next_node_id]
        ):

            visited[next_node_id] = (
                next_distance
            )

            queue.append(
                (
                    next_node_id,
                    next_distance,
                )
            )


# =====================================================
# REMOVE ANY STUDY-AREA OVERLAP
# =====================================================

buffer_edges -= study_area_edges


# =====================================================
# COMBINE STUDY NETWORK
# =====================================================

study_network_edges = (
    study_area_edges
    | buffer_edges
)


# =====================================================
# EXPORT EDGE LISTS
# =====================================================

def save_edges(
    output_file,
    edges,
):

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        output_file,
        "w",
    ) as f:

        for edge_id in sorted(edges):

            f.write(
                f"{edge_id}\n"
            )


save_edges(
    STUDY_AREA_FILE,
    study_area_edges,
)

save_edges(
    BUFFER_FILE,
    buffer_edges,
)

save_edges(
    STUDY_NETWORK_FILE,
    study_network_edges,
)


# =====================================================
# SUMMARY
# =====================================================

summary = f"""
SUMO STUDY NETWORK SUMMARY
{'=' * 70}

INPUT
{'-' * 70}
Network file:              {NET_FILE}
Backbone edges:            {len(backbone_edges)}

SPATIAL STUDY AREA
{'-' * 70}
Spatial radius:            {STUDY_AREA_RADIUS} m
Raw selected edges:        {raw_study_area_count}
Final study area edges:    {len(study_area_edges)}

TOPOLOGICAL COMPLETION
{'-' * 70}
Edges checked:             {raw_study_area_count}
Reverse found:             {reverse_found}
Reverse edges added:       {reverse_added}
Reverse unavailable:      {reverse_missing}

NETWORK BUFFER
{'-' * 70}
Boundary seed nodes:       {len(boundary_nodes)}
Network distance:          {BUFFER_DISTANCE} m
Buffer edges:              {len(buffer_edges)}

COMBINED STUDY NETWORK
{'-' * 70}
Total edges:               {len(study_network_edges)}

OUTPUTS
{'-' * 70}
Study area:                {STUDY_AREA_FILE}
Boundary buffer:           {BUFFER_FILE}
Study network:             {STUDY_NETWORK_FILE}
Summary:                   {SUMMARY_FILE}
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_FILE.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with open(
    SUMMARY_FILE,
    "w",
) as f:

    f.write(
        summary.strip()
    )


# =====================================================
# CONSOLE OUTPUT
# =====================================================

print(summary)
