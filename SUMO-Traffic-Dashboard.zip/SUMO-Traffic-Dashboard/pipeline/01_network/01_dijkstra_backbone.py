import sys
import heapq
from pathlib import Path

# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

from config.study_config import SURVEY_JUNCTIONS

import sumolib
import matplotlib.pyplot as plt


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = PROJECT_ROOT / "study_areas" / ".net.xml"

EDGE_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "backbone_edges.txt"
)

VISUALIZATION_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "visualizations"
    / "network"
    / "dijkstra_backbone.png"
)

ALLOWED_TYPES = {
    "highway.trunk",
    "highway.primary",
    "highway.secondary",
    "highway.tertiary",
    "highway.residential",
    "highway.service",
}


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)

nodes = {
    node.getID(): node
    for node in net.getNodes()
}


# =====================================================
# BUILD GRAPH
# =====================================================

graph = {}

for node in net.getNodes():

    graph[node.getID()] = []

    for edge in node.getOutgoing():

        if edge.getFunction() != "":
            continue

        if edge.getType() not in ALLOWED_TYPES:
            continue

        graph[node.getID()].append(
            (
                edge.getToNode().getID(),
                edge.getLength(),
                edge.getID(),
            )
        )


# =====================================================
# DIJKSTRA
# =====================================================

def dijkstra(start, goal):

    priority_queue = [
        (0, start)
    ]

    distance = {
        start: 0
    }

    previous = {}

    while priority_queue:

        current_distance, current_node = (
            heapq.heappop(priority_queue)
        )

        if current_node == goal:
            break

        if current_distance > distance[current_node]:
            continue

        for (
            neighbor,
            weight,
            edge_id,
        ) in graph[current_node]:

            new_distance = (
                current_distance + weight
            )

            if (
                neighbor not in distance
                or new_distance < distance[neighbor]
            ):

                distance[neighbor] = new_distance

                previous[neighbor] = (
                    current_node,
                    edge_id,
                )

                heapq.heappush(
                    priority_queue,
                    (
                        new_distance,
                        neighbor,
                    ),
                )

    if goal not in previous:

        return []

    edges = []
    node = goal

    while node != start:

        previous_node, edge_id = (
            previous[node]
        )

        edges.append(edge_id)

        node = previous_node

    edges.reverse()

    return edges


# =====================================================
# BUILD BACKBONE
# =====================================================

backbone_edges = set()

pairs = [
    (0, 1),
    (0, 2),
    (1, 2),
]

print()

for start_index, goal_index in pairs:

    start = SURVEY_JUNCTIONS[start_index]
    goal = SURVEY_JUNCTIONS[goal_index]

    print(
        f"Computing path {start} -> {goal}"
    )

    path = dijkstra(
        start,
        goal,
    )

    print(
        f"  {len(path)} edges"
    )

    backbone_edges.update(path)


# =====================================================
# EXPORT EDGE LIST
# =====================================================

EDGE_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with open(
    EDGE_OUTPUT,
    "w",
) as f:

    for edge_id in sorted(backbone_edges):

        f.write(
            f"{edge_id}\n"
        )


# =====================================================
# VISUALIZATION
# =====================================================

plt.figure(
    figsize=(14, 14)
)

for edge in net.getEdges():

    if edge.getFunction() != "":
        continue

    shape = edge.getShape()

    if len(shape) < 2:
        continue

    xs = [
        point[0]
        for point in shape
    ]

    ys = [
        point[1]
        for point in shape
    ]

    if edge.getID() in backbone_edges:

        plt.plot(
            xs,
            ys,
            color="red",
            linewidth=3,
        )

    else:

        plt.plot(
            xs,
            ys,
            color="lightgray",
            linewidth=0.3,
        )


# =====================================================
# SURVEY JUNCTIONS
# =====================================================

for junction_id in SURVEY_JUNCTIONS:

    x, y = nodes[junction_id].getCoord()

    plt.scatter(
        x,
        y,
        s=120,
        color="blue",
        zorder=5,
    )


plt.axis("equal")

plt.title(
    "Dijkstra Backbone"
)

plt.tight_layout()


# =====================================================
# SAVE VISUALIZATION
# =====================================================

VISUALIZATION_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

plt.savefig(
    VISUALIZATION_OUTPUT,
    dpi=300,
    bbox_inches="tight",
)

plt.show()


# =====================================================
# SUMMARY
# =====================================================

print()
print(
    f"Backbone edges: {len(backbone_edges)}"
)

print(
    f"Edge list:      {EDGE_OUTPUT}"
)

print(
    f"Visualization:  {VISUALIZATION_OUTPUT}"
)