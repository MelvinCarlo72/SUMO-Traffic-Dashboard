import sys
from pathlib import Path

# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

import sumolib
import matplotlib.pyplot as plt


# =====================================================
# CONFIGURATION
# =====================================================

NET_FILE = (
    PROJECT_ROOT
    / "study_areas"
    / ".net.xml"
)

SPINE_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "backbone_edges.txt"
)

STUDY_AREA_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_area_edges.txt"
)

BOUNDARY_BUFFER_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "boundary_buffer_edges.txt"
)

VISUALIZATION_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "visualizations"
    / "network"
    / "study_network_expansion.png"
)

SHOW_FULL_NETWORK = True

SPINE_COLOR = "red"
STUDY_AREA_COLOR = "orange"
BUFFER_COLOR = "blue"


# =====================================================
# LOAD NETWORK
# =====================================================

print("Loading network...")

net = sumolib.net.readNet(
    str(NET_FILE)
)


# =====================================================
# LOAD EDGE FILE
# =====================================================

def load_edges(filename):

    with open(filename) as f:

        return {
            line.strip()
            for line in f
            if line.strip()
        }


spine_edges = load_edges(
    SPINE_FILE
)

study_area_edges = load_edges(
    STUDY_AREA_FILE
)

boundary_buffer_edges = load_edges(
    BOUNDARY_BUFFER_FILE
)


# =====================================================
# SEPARATE LAYERS
# =====================================================

study_area_only = (
    study_area_edges
    - spine_edges
)


# =====================================================
# DRAW FULL NETWORK
# =====================================================

if SHOW_FULL_NETWORK:

    for edge in net.getEdges():

        if edge.isSpecial():
            continue

        shape = edge.getShape()

        if len(shape) < 2:
            continue

        xs = [
            point[0]
            for point in shape
        ]

        ys = [
            point[1]
            for point in shape
        ]

        plt.plot(
            xs,
            ys,
            linewidth=0.4,
            alpha=0.2,
            color="gray",
        )


# =====================================================
# DRAW EDGE LAYER
# =====================================================

def draw_edges(
    edge_ids,
    color,
    linewidth,
    alpha,
    label,
):

    first = True

    for edge_id in edge_ids:

        try:
            edge = net.getEdge(edge_id)
        except Exception:
            continue

        shape = edge.getShape()

        if len(shape) < 2:
            continue

        xs = [
            point[0]
            for point in shape
        ]

        ys = [
            point[1]
            for point in shape
        ]

        plt.plot(
            xs,
            ys,
            color=color,
            linewidth=linewidth,
            alpha=alpha,
            label=label if first else None,
        )

        first = False


# =====================================================
# DRAW BOUNDARY BUFFER
# =====================================================

draw_edges(
    boundary_buffer_edges,
    color=BUFFER_COLOR,
    linewidth=2,
    alpha=0.7,
    label="Boundary Buffer",
)


# =====================================================
# DRAW STUDY AREA
# =====================================================

draw_edges(
    study_area_only,
    color=STUDY_AREA_COLOR,
    linewidth=2.5,
    alpha=0.8,
    label="Study Area",
)


# =====================================================
# DRAW SPINE
# =====================================================

draw_edges(
    spine_edges,
    color=SPINE_COLOR,
    linewidth=4,
    alpha=1.0,
    label="Backbone / Spine",
)


# =====================================================
# DISPLAY
# =====================================================

plt.axis("equal")

plt.title(
    "SUMO Study Network: Spine, Study Area, and Boundary Buffer"
)

plt.legend()

plt.tight_layout()


# =====================================================
# SAVE VISUALIZATION
# =====================================================

VISUALIZATION_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

plt.savefig(
    VISUALIZATION_OUTPUT,
    dpi=300,
    bbox_inches="tight",
)

plt.show()


# =====================================================
# SUMMARY
# =====================================================

print(
    f"""
Study Network Visualization
{'=' * 70}

Backbone edges:       {len(spine_edges)}
Study area edges:     {len(study_area_edges)}
Study area only:      {len(study_area_only)}
Buffer edges:         {len(boundary_buffer_edges)}

Visualization:
{VISUALIZATION_OUTPUT}
"""
)