import subprocess
import sys
from pathlib import Path


# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))


# =====================================================
# CONFIGURATION
# =====================================================

NETCONVERT = Path(
    r"C:\Program Files (x86)\Eclipse\Sumo\bin\netconvert.exe"
)

SOURCE_NETWORK = (
    PROJECT_ROOT
    / "study_areas"
    / ".net.xml"
)

EDGE_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "network"
    / "study_network_edges.txt"
)

OUTPUT_NETWORK = (
    PROJECT_ROOT
    / "study_areas"
    / "study_network.net.xml"
)


# =====================================================
# VALIDATE INPUTS
# =====================================================

if not NETCONVERT.exists():

    raise FileNotFoundError(
        f"netconvert not found:\n{NETCONVERT}"
    )


if not SOURCE_NETWORK.exists():

    raise FileNotFoundError(
        f"Source network not found:\n{SOURCE_NETWORK}"
    )


if not EDGE_FILE.exists():

    raise FileNotFoundError(
        f"Edge list not found:\n{EDGE_FILE}"
    )


# =====================================================
# BUILD NETWORK
# =====================================================

print("Building study network...")

OUTPUT_NETWORK.parent.mkdir(
    parents=True,
    exist_ok=True
)


command = [
    str(NETCONVERT),
    "-s",
    str(SOURCE_NETWORK),
    "--keep-edges.input-file",
    str(EDGE_FILE),
    "-o",
    str(OUTPUT_NETWORK),
]


result = subprocess.run(
    command,
    capture_output=True,
    text=True,
)


# =====================================================
# HANDLE RESULT
# =====================================================

if result.returncode != 0:

    print(result.stdout)
    print(result.stderr)

    raise RuntimeError(
        "netconvert failed."
    )


print()
print("=" * 70)
print("STUDY NETWORK BUILD COMPLETE")
print("=" * 70)
print()
print(f"Source network:  {SOURCE_NETWORK}")
print(f"Edge list:       {EDGE_FILE}")
print(f"Output network:  {OUTPUT_NETWORK}")
print()