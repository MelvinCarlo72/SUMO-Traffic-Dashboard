import csv
import sys
from pathlib import Path
from collections import defaultdict

# =====================================================
# PROJECT CONFIG
# =====================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))


# =====================================================
# CONFIGURATION
# =====================================================

VALIDATION_FILE = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "route_validation.csv"
)

DATA_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "data"
    / "weighted_routes.csv"
)

SUMMARY_OUTPUT = (
    PROJECT_ROOT
    / "outputs"
    / "summaries"
    / "route_weighting.txt"
)


ENTRY_WEIGHTS = {
    "HIGH": 1.00,
    "MODERATE": 0.75,
    "POTENTIAL_LOCAL": 0.40,
    "LOW": 0.15,
}

EXIT_WEIGHTS = {
    "HIGH": 1.00,
    "MODERATE": 0.75,
    "POTENTIAL_LOCAL": 0.40,
    "LOW": 0.15,
}


LOAD_CLASS_THRESHOLDS = {
    "PRIMARY": 0.75,
    "SECONDARY": 0.50,
    "LOCAL": 0.20,
}


LOAD_CLASS_PRIORITY = {
    "PRIMARY": 1,
    "SECONDARY": 2,
    "LOCAL": 3,
    "BACKGROUND": 4,
}


# =====================================================
# LOAD VALIDATED ROUTES
# =====================================================

print("Loading validated routes...")

routes = []

with open(
    VALIDATION_FILE,
    newline=""
) as f:

    reader = csv.DictReader(f)

    for row in reader:

        if row["valid_route"] == "YES":
            routes.append(row)


print(
    f"Validated routes: {len(routes)}"
)


# =====================================================
# CLASSIFY ROUTE
# =====================================================

def classify_route(weight):

    if weight >= LOAD_CLASS_THRESHOLDS["PRIMARY"]:
        return "PRIMARY"

    if weight >= LOAD_CLASS_THRESHOLDS["SECONDARY"]:
        return "SECONDARY"

    if weight >= LOAD_CLASS_THRESHOLDS["LOCAL"]:
        return "LOCAL"

    return "BACKGROUND"


# =====================================================
# BUILD WEIGHTED ROUTES
# =====================================================

weighted_routes = []

for route in routes:

    entry_relevance = route[
        "entry_relevance"
    ]

    exit_relevance = route[
        "exit_relevance"
    ]


    entry_weight = ENTRY_WEIGHTS.get(
        entry_relevance,
        0.0
    )

    exit_weight = EXIT_WEIGHTS.get(
        exit_relevance,
        0.0
    )


    od_weight = (
        entry_weight
        * exit_weight
    )


    load_class = classify_route(
        od_weight
    )


    weighted_routes.append({

        "entry_edge":
            route["entry_edge"],

        "exit_edge":
            route["exit_edge"],

        "entry_classification":
            route["entry_classification"],

        "exit_classification":
            route["exit_classification"],

        "entry_relevance":
            entry_relevance,

        "exit_relevance":
            exit_relevance,

        "entry_load_weight":
            round(
                entry_weight,
                4
            ),

        "exit_attraction_weight":
            round(
                exit_weight,
                4
            ),

        "od_weight":
            round(
                od_weight,
                4
            ),

        "load_class":
            load_class,

        "route_length":
            route["route_length"],

        "route_edges":
            route["route_edges"],
    })


# =====================================================
# SORT WEIGHTED ROUTES
# =====================================================

weighted_routes.sort(
    key=lambda row: (
        LOAD_CLASS_PRIORITY.get(
            row["load_class"],
            99
        ),
        -float(
            row["od_weight"]
        ),
    )
)


# =====================================================
# SUMMARY COUNTS
# =====================================================

class_counts = defaultdict(int)
entry_relevance_counts = defaultdict(int)
exit_relevance_counts = defaultdict(int)


for route in weighted_routes:

    class_counts[
        route["load_class"]
    ] += 1

    entry_relevance_counts[
        route["entry_relevance"]
    ] += 1

    exit_relevance_counts[
        route["exit_relevance"]
    ] += 1


# =====================================================
# WRITE CSV
# =====================================================

DATA_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True
)

fieldnames = [
    "entry_edge",
    "exit_edge",
    "entry_classification",
    "exit_classification",
    "entry_relevance",
    "exit_relevance",
    "entry_load_weight",
    "exit_attraction_weight",
    "od_weight",
    "load_class",
    "route_length",
    "route_edges",
]

with open(
    DATA_OUTPUT,
    "w",
    newline=""
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames
    )

    writer.writeheader()
    writer.writerows(weighted_routes)


# =====================================================
# BUILD SUMMARY TABLES
# =====================================================

route_distribution = "\n".join([
    f"{'PRIMARY':<35}{class_counts['PRIMARY']:>10}",
    f"{'SECONDARY':<35}{class_counts['SECONDARY']:>10}",
    f"{'LOCAL':<35}{class_counts['LOCAL']:>10}",
    f"{'BACKGROUND':<35}{class_counts['BACKGROUND']:>10}",
])


entry_weights_table = "\n".join(
    f"{relevance:<35}{weight:>10.2f}"
    for relevance, weight
    in ENTRY_WEIGHTS.items()
)


exit_weights_table = "\n".join(
    f"{relevance:<35}{weight:>10.2f}"
    for relevance, weight
    in EXIT_WEIGHTS.items()
)


entry_distribution = "\n".join(
    f"{relevance:<35}{entry_relevance_counts[relevance]:>10}"
    for relevance in ENTRY_WEIGHTS
)


exit_distribution = "\n".join(
    f"{relevance:<35}{exit_relevance_counts[relevance]:>10}"
    for relevance in EXIT_WEIGHTS
)


# =====================================================
# BUILD SUMMARY
# =====================================================

summary = f"""
SUMO ROUTE WEIGHTING
{'=' * 70}

OVERVIEW
{'-' * 70}
{'Validated routes':<35}{len(routes):>10}
{'Weighted routes':<35}{len(weighted_routes):>10}


ROUTE CLASSIFICATION
{'-' * 70}
{'CLASS':<35}{'ROUTES':>10}
{'-' * 70}
{route_distribution}


ENTRY LOAD WEIGHTS
{'-' * 70}
{'RELEVANCE':<35}{'WEIGHT':>10}
{'-' * 70}
{entry_weights_table}


EXIT ATTRACTION WEIGHTS
{'-' * 70}
{'RELEVANCE':<35}{'WEIGHT':>10}
{'-' * 70}
{exit_weights_table}


ENTRY RELEVANCE DISTRIBUTION
{'-' * 70}
{entry_distribution}


EXIT RELEVANCE DISTRIBUTION
{'-' * 70}
{exit_distribution}


NOTE
{'-' * 70}
Entry weights represent relative source importance.
Exit weights represent relative destination attractiveness.
OD weight combines both factors.
Weights are modeling assumptions and are not calibrated
traffic volumes.


OUTPUTS
{'-' * 70}
Weighted routes: {DATA_OUTPUT}
Summary:         {SUMMARY_OUTPUT}
"""


# =====================================================
# WRITE SUMMARY
# =====================================================

SUMMARY_OUTPUT.parent.mkdir(
    parents=True,
    exist_ok=True
)

with open(
    SUMMARY_OUTPUT,
    "w"
) as f:

    f.write(
        summary.strip()
    )


# =====================================================
# CONSOLE OUTPUT
# =====================================================

print()
print(summary)