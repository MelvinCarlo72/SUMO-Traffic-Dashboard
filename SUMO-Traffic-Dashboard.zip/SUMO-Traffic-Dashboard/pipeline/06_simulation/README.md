# SACOP + Del Rosario SUMO scenario

Place the verified San Fernando network, route/demand files, and traffic-light configuration here.
The web backend expects `scenario.sumocfg`.

Do not place // data in this directory.
