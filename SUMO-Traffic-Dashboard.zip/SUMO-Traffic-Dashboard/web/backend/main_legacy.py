from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import asyncio, random, time, math, os

ROOT = Path(__file__).resolve().parents[2]
app = FastAPI(title='SUMO Traffic Dashboard')
app.mount('/static', StaticFiles(directory=ROOT/'web/frontend/static'), name='static')

class Simulation:
    def __init__(self):
        self.running=False; self.t=0; self.mode='SAC'; self.scenario='Normal Traffic'
        self.metrics={}; self.last_action='HOLD'; self.confidence=0; self.reason='Waiting for simulation.'
        self.history=[]; self.clients=set(); self.reset()
    def reset(self):
        self.t=0; self.running=False
        self.metrics={'vehicles':142,'waiting':31.2,'queue':6.8,'throughput':0,'delay':14.4,'density':38.5,'speed':31.4,'reward':0.72}
        self.last_action='HOLD'; self.confidence=0; self.reason='Ready to run SAC controller.'
        self.history=[]
    def step(self):
        self.t += 1
        factor={'Normal Traffic':1.0,'Peak Hours':1.35,'Traffic Incident':1.75}.get(self.scenario,1.0)
        q=max(0.8, self.metrics['queue'] + random.uniform(-.55,.45) + (factor-1)*.12)
        wait=max(5, self.metrics['waiting'] + (q-7)*.45 + random.uniform(-1.2,1.0))
        if self.mode=='SAC':
            action=random.choice(['EXTEND GREEN','SHORTEN GREEN','HOLD']) if self.t%4==0 else self.last_action
            reward=max(.2,min(.98,1-(wait/110)-(q/55)+random.uniform(-.03,.03)))
            conf=min(99,max(76,88+random.uniform(-7,8)))
            reason='Higher queue detected on the dominant approach.' if action=='EXTEND GREEN' else 'Balanced queues; maintain current phase.'
        else:
            action='FIXED TIMING'; reward=max(.1, .72-(wait/180)); conf=100; reason='Fixed-time signal plan.'
        self.metrics.update({'vehicles':int(142*factor+random.randint(-8,8)),'waiting':round(wait,1),'queue':round(q,1),'throughput':int(self.t*4.2*factor),'delay':round(wait*.46,1),'density':round(min(98,38*factor+q*1.7),1),'speed':round(max(8,34-q*.65),1),'reward':round(reward,2)})
        self.last_action=action; self.confidence=round(conf); self.reason=reason
        self.history.append({'t':self.t,'waiting':self.metrics['waiting'],'queue':self.metrics['queue'],'reward':self.metrics['reward']})
        self.history=self.history[-60:]
    def state(self):
        return {'running':self.running,'time':self.t,'scenario':self.scenario,'mode':self.mode,'metrics':self.metrics,'controller':{'action':self.last_action,'confidence':self.confidence,'reason':self.reason},'intersections':[{'name':'SACOP','status':'OPTIMIZED','queue':round(self.metrics['queue']*.95,1),'wait':round(self.metrics['waiting']*1.08,1)},{'name':'Del Rosario','status':'OPTIMIZED','queue':round(self.metrics['queue']*1.12,1),'wait':round(self.metrics['waiting']*.94,1)}],'history':self.history}

sim=Simulation()

@app.get('/')
def index(): return FileResponse(ROOT/'web/frontend/index.html')
@app.get('/api/state')
def state(): return sim.state()
@app.post('/api/start')
def start(): sim.running=True; return sim.state()
@app.post('/api/stop')
def stop(): sim.running=False; return sim.state()
@app.post('/api/reset')
def reset(): sim.reset(); return sim.state()
@app.post('/api/step')
def step(): sim.step(); return sim.state()
@app.post('/api/settings')
async def settings(payload: dict):
    sim.mode=payload.get('mode',sim.mode); sim.scenario=payload.get('scenario',sim.scenario); return sim.state()

@app.websocket('/ws')
async def ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            if sim.running: sim.step()
            await websocket.send_json(sim.state())
            await asyncio.sleep(.7)
    except WebSocketDisconnect: pass
