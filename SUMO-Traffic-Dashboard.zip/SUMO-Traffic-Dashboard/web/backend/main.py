"""Compatibility entry point.

`python -m uvicorn web.backend.main:app` now serves the current dashboard
(webapp/), so there is only one UI. The original random-demo app is kept as
web/backend/main_legacy.py (its demo values are generated, not from SUMO or SAC).
"""
from webapp.backend.main import app  # noqa: F401
