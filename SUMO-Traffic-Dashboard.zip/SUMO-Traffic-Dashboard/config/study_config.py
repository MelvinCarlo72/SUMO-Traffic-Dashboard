SURVEY_JUNCTIONS = [
    "SACOP",   # Intersection 3
    "Del Rosario",   # Intersection 2
]