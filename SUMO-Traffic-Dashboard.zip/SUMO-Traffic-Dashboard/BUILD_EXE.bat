@echo off
REM Builds dist\SUMO-Traffic-Dashboard\SUMO-Traffic-Dashboard.exe (double-clickable, own window).
REM Run once on Windows with Python 3.10+. SUMO itself must still be installed on the PC.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate
python -m pip install -q -r webapp\requirements.txt -r desktop\requirements-desktop.txt pyinstaller
set EXTRA=
python -c "import stable_baselines3" 2>nul && set EXTRA=--hidden-import stable_baselines3
if "%EXTRA%"=="" echo NOTE: stable-baselines3 is not installed here, so the exe will use the fallback rule instead of your trained SAC model.
echo Building (this takes a few minutes)...
pyinstaller --noconfirm --clean --windowed --name SUMO-Traffic-Dashboard --icon desktop\app.ico ^
  --paths . --add-data "webapp\frontend;webapp\frontend" ^
  --collect-submodules uvicorn --collect-submodules websockets --collect-all webview ^
  --hidden-import webapp.backend.main --hidden-import webapp.backend.simulation %EXTRA% ^
  desktop\app.py
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
REM Files the app reads at runtime live NEXT TO the exe so they can be replaced without rebuilding.
xcopy /E /I /Y ml\models "dist\SUMO-Traffic-Dashboard\ml\models" >nul
xcopy /E /I /Y pipeline\06_simulation "dist\SUMO-Traffic-Dashboard\pipeline\06_simulation" >nul
xcopy /E /I /Y data "dist\SUMO-Traffic-Dashboard\data" >nul
echo.
echo Done: dist\SUMO-Traffic-Dashboard\SUMO-Traffic-Dashboard.exe
echo Copy the whole SUMO-Traffic-Dashboard folder to move the app to another PC.
pause
