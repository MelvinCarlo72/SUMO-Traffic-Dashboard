@echo off
REM Runs the dashboard as its own desktop app (no browser). Needs Python 3.10+.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate
python -m pip install -q -r webapp\requirements.txt -r desktop\requirements-desktop.txt
start "" ".venv\Scripts\pythonw.exe" desktop\app.py
