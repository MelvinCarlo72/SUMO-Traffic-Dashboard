# SACOP Makatao outer-lane candidate

Isolated candidate. Makatao approach edge `1085655715#0`, lane 0, is reserved for the right turn. Its lane-0 left-turn connection was removed; lanes 1 and 2 retain the left turn. The red-circled M02 outer-lane straight connection remains permissive and yields. Vehicle types use the earlier joined-candidate `tau=1.5` s, with no explicit `minGap` or `apparentDecel` override.

Checks passed: 56/56 fixed-time scenarios; 48/48 demand audits; eight observed-August environment windows with TraCI/libsumo parity; and eight-cycle seed-42 DQN and DDQN training/selection trials. Both algorithms completed eight cycles without a safety failure. DQN selected cycle 2, DDQN cycle 6. September was used during earlier calibration and is not an untouched final test.

The short trials establish that this candidate passed the specific safety gate that stopped the previous spacing-only candidates. They do not prove zero collisions across all seeds or a full 15-cycle run. The full run uses seeds 42, 43, 44 with a safety gate on every episode and excludes the locked-test stage.

Full DQN/DDQN training was launched in `full_training_01` on 2026-10-16. Its final status must be read from the per-seed summaries; launch alone does not constitute completion.
