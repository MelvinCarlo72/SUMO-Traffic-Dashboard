# SACOP one-minute manual count comparison — 16 October 2026

The user supplied independent counts of physical vehicles crossing the SACOP intersection in the three raw one-minute clips. The original manual totals are in `manual_counts_2026-10-16.csv`. This comparison assumes the supplied counts follow the clip intervals and crossing rule in the counting guide. It uses the existing production `movement_tracks.csv` outputs: rows with `status=MOVEMENT_CONFIRMED`, a movement ID, and `exit_time` in the same nominal minute `[start, end)`. No YOLO extraction was rerun.

| Clip | Manual total | YOLO confirmed exits | YOLO − manual | Excluded exit-track observations |
|---|---:|---:|---:|---:|
| A — Aug 6, 07:10–07:11 | 39 | 27 | −12 | 16 |
| B — Aug 22, 07:00–07:01 | 71 | 58 | −13 | 48 |
| C — Sep 19, 16:40–16:41 | 49 | 43 | −6 | 35 |
| **Total** | **159** | **128** | **−31** | **99** |

| Clip | M1 | M2 | M3 | M4 | M5 | M6 |
|---|---:|---:|---:|---:|---:|---:|
| A manual | 0 | 24 | 4 | 5 | 1 | 5 |
| A YOLO | 0 | 19 | 4 | 1 | 1 | 2 |
| B manual | 0 | 39 | 30 | 1 | 0 | 1 |
| B YOLO | 0 | 27 | 29 | 1 | 0 | 1 |
| C manual | 1 | 39 | 0 | 4 | 2 | 3 |
| C YOLO | 2 | 30 | 3 | 2 | 3 | 3 |

## Descriptive count metrics

These metrics treat the user's crossed-vehicle tallies as the reference and the three nominal one-minute windows as the units of comparison. They are **aggregate count metrics**, not vehicle detection precision or recall.

| Metric | Value | Meaning |
|---|---:|---|
| Pooled YOLO/manual count ratio | 128 / 159 = **80.5%** | Confirmed YOLO movement count relative to manual total |
| Pooled count bias | **−19.5%** | YOLO total was 31 lower than manual total |
| Mean absolute error per one-minute clip | **10.3 vehicles** | Mean of absolute clip-total differences 12, 13, and 6 |
| Root mean squared error per clip | **10.8 vehicles** | Larger clip errors receive more weight |
| Clip-total mean absolute percentage error | **20.4%** | Mean of 30.8%, 18.3%, and 12.2% |
| Movement-cell weighted absolute percentage error | **25.8%** | Sum of 18 absolute movement differences (41) divided by 159 manual vehicles |

Clip-total count agreement (YOLO/manual) was **69.2%** in A, **81.7%** in B, and **87.8%** in C. The movement-cell error is larger than the overall 19.5% net deficit because positive and negative movement errors cancel in the total.

| Movement | Manual, three clips | YOLO confirmed | YOLO/manual | Difference |
|---|---:|---:|---:|---:|
| M1 | 1 | 2 | 200.0% | +1 |
| M2 | 102 | 76 | 74.5% | −26 |
| M3 | 34 | 36 | 105.9% | +2 |
| M4 | 10 | 4 | 40.0% | −6 |
| M5 | 3 | 4 | 133.3% | +1 |
| M6 | 9 | 6 | 66.7% | −3 |

M2 supplies most of the net deficit. M1, M4, M5, and M6 have small denominators, so their percentages are unstable. A single global multiplier would not correct the uneven movement errors. Three one-minute clips cannot establish a reliable population-level error rate. Precision, recall, F1, mAP, and confirmed false-positive/false-negative counts require event-matched physical vehicle labels and detection/track evidence.

The dominant negative differences are M2 in all three clips (−5, −12, −9), plus M4/M6 in A (−4/−3). C also has positive differences in M1, M3, and M5. The `exit_crossings_review.csv` files show 16, 48, and 35 unique exit-track observations in these minutes whose movements were not confirmed. These are excluded from `movement_counts.csv` and the 128 YOLO confirmed exits. Most have no observed origin; several have a track-gap rejection. The review observations are track IDs, not deduplicated physical vehicles, and cannot simply be added to confirmed counts. An earlier check of `movement_tracks.csv` found only two September review rows with populated exit times; that file understates the review queue because many rejected tracks do not carry an `exit_time` in their final movement state.

The review-track breakdown is in `excluded_exit_tracks_summary.csv`: 94 have no observed origin and five have a track-gap or failed recovery reason across the three minutes. In the counting code, an exit hit before any entry sets `EXIT_BEFORE_ENTRY` and `REVIEW_REQUIRED`; the saved `track_journeys.csv` often labels that case `origin_not_observed`. These observations explain why confirmed counts can be lower than physical crossings, but do not identify which observations correspond to the user's manually counted vehicles.

The confirmed-exit totals were cross-checked against each production `movement_counts.csv` row for the same interval; they match exactly (27, 58, 43).

**Interpretation limit:** These are aggregate counts, not event-matched accuracy measurements. The manual rule used physical crossing of the central junction, whereas YOLO records an exit-zone event; a vehicle near a one-minute boundary can fall in different minutes. Shifting YOLO's 60-second query by ±10 seconds gives total ranges A 22–33, B 48–58, and C 43–51, showing C is particularly boundary-sensitive. A/B still sit below the manual total across those shifts. Individual miss, duplicate, wrong-movement, and class-error counts require the per-vehicle timestamps or direct video adjudication. The −31 aggregate difference must **not** be labeled 31 confirmed missed vehicles or used as recall.

Next review priority: M2 in B, M4/M6 in A, and the three C M3 assignments. The full per-movement machine-readable comparison is `manual_vs_yolo_comparison.csv`.

## Fit to this thesis

The thesis tests a YOLO-informed simulation and DRL framework where real count data were unavailable. These three short clips describe the quality of the pretrained-YOLO movement input; they are not a prerequisite for reporting the simulation experiment. The primary comparison remains internally controlled because the fixed-time and DRL agents are tested on the same generated demand. Synthetic demand variants probe how policies behave as that baseline changes. The study should state the observed aggregate count bias and avoid claiming exact physical traffic reconstruction or field deployment performance. A full 30-minute manual count and custom YOLO training are outside the stated scope.
