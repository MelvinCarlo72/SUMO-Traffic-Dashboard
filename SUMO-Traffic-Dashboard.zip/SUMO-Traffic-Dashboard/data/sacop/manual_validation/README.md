# SACOP three-clip manual count pilot

Count one physical vehicle once when it **leaves the intersection** during the one-minute clip. Count moving cars, vans, jeepneys, buses, trucks, motorcycles, and tricycles that travel through one of the six mapped origin-to-destination paths. Follow the vehicle through the central orange-marked junction and log it only when it reaches the road beyond the junction. Do not count traffic already traveling farther up the road beyond the junction, parked vehicles, pedestrians, or a vehicle merely waiting at the stop line. A vehicle already in the junction at the first frame counts if it exits during the minute; a vehicle still in the junction at the last frame does not. Mark uncertain or occluded paths as `uncertain` instead of guessing. Record an approximate exit time (mm:ss) in `count_events.csv` so each observation can later be matched to YOLO output. Count vehicles even if YOLO shows no box. Do not use the annotated `tracking_test.mp4` to make the manual count.

A tricycle counts as one vehicle, as does a motorcycle carrying multiple riders. Do not count parked vehicles or pedestrians. Replay uncertain moments at reduced speed and keep an `uncertain` tally if the origin or exit remains hidden.

| Clip ID | Raw video | Pipeline interval | Study role |
|---|---|---|---|
| A | `2026-08-06_0710_0711_raw.mp4` | Aug 6, 07:10:00–07:11:00 | training-period day |
| B | `2026-08-22_0700_0701_raw.mp4` | Aug 22, 07:00:00–07:01:00 | training-period day |
| C | `2026-09-19_1640_1641_raw.mp4` | Sep 19, 16:40:00–16:41:00 | locked-test day |

## Movement labels in the current project

| Label | From | Toward | Project turn |
|---|---|---|---|
| M1 | Del Rosario | Makatao | left |
| M2 | Del Rosario | San Agustin | straight |
| M3 | San Agustin | Del Rosario | straight |
| M4 | San Agustin | Makatao | right |
| M5 | Makatao | San Agustin | left |
| M6 | Makatao | Del Rosario | right |

If a visible path is not in these six, write `other` and describe it. The counts are an independent reference; leave the YOLO result files closed until the manual log is done.

`movement_areas_reference.png` shows the road names and entry/exit regions. Use it only to identify roads, not as a source of vehicle counts.

`count_events.csv` has one row per physical vehicle. Minimum useful fields: clip ID, exit time, movement, and uncertainty. Vehicle class is optional. Use `car`, `motorcycle`, `tricycle`, `van`, `bus`, `truck`, or `other` when clear. Leave the `notes` field for occlusion or difficult crossings.

If recording each vehicle is too slow, fill `tally_totals.csv` first. Movement totals let us compare demand, while the event log is needed to identify specific YOLO misses and duplicates.

Use elapsed time in the one-minute clip for `exit_time_mmss` (for example `00:23`), even if the camera's overlaid clock differs slightly from the pipeline timestamp. Each video was checked to contain 1,440 frames at 24 fps.
