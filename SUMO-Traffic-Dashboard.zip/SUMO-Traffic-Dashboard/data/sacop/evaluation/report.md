# SACOP j4 separated test evaluation

The eight September 16–20 demand windows were excluded from this training run and checkpoint selection. Earlier SACOP calibration inspected September data, so this is not a pristine prospective holdout.

| Controller | Seed | Selected cycle | Wait reduction vs fixed-time | Improved windows | Mean queue (model/fixed) | Arrived/scheduled | Collisions | Teleports |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| DQN | 42 | 2 | 39.85% | 7/8 | 2.52/3.29 | 14023/14023 | 0 | 0 |
| DDQN | 42 | 10 | 35.43% | 8/8 | 2.77/3.29 | 14023/14023 | 0 | 0 |
| DQN | 43 | 14 | 36.48% | 8/8 | 2.58/3.29 | 14023/14023 | 0 | 0 |
| DDQN | 43 | 8 | 38.00% | 8/8 | 2.83/3.29 | 14023/14023 | 0 | 0 |
| DQN | 44 | 8 | 25.22% | 8/8 | 2.94/3.29 | 14023/14023 | 0 | 0 |
| DDQN | 44 | 15 | 39.20% | 8/8 | 2.52/3.29 | 14023/14023 | 0 | 0 |

Source: `heldout_eval.json`; exact per-window values: `per_window.csv`. These are SUMO outcomes, not measured street performance. Signal timing remains provisional, and the network emits a missing-green-phase warning for one tls index.
