# SACOP Sunday afternoon diagnostic (exploratory)

The selected DQN seed-42 policy was traced on the September 20 afternoon window after the separated test comparison. This analysis did not change the checkpoint or the reported test result.

## Wait decomposition

| Measure | DQN seed 42 | Fixed-time | DQN minus fixed-time |
| --- | ---: | ---: | ---: |
| Stopped-vehicle seconds | 14,993 | 12,248 | +2,745 |
| Pending-insertion vehicle-seconds | 12,050 | 13,373 | -1,323 |
| **Total wait** | **27,043** | **25,621** | **+1,422** |

## Stopped delay by movement

| Movement | DQN | Fixed-time | Difference |
| --- | ---: | ---: | ---: |
| J02_M01: Del Rosario → Makatao | 523 | 358 | +165 |
| J02_M02: Del Rosario → San Agustin | 2,734 | 2,958 | -224 |
| J02_M03: San Agustin → Del Rosario | 9,763 | 8,009 | +1,754 |
| J02_M04: San Agustin → Makatao | 257 | 339 | -82 |
| J02_M05: Makatao → San Agustin | 748 | 299 | +449 |
| J02_M06: Makatao → Del Rosario | 968 | 285 | +683 |

## Signal trace

| Phase index | DQN seconds | Fixed-time seconds | Difference |
| --- | ---: | ---: | ---: |
| 0 | 1,880 | 1,890 | -10 |
| 1 | 890 | 950 | -60 |
| 2 | 830 | 760 | +70 |

The DQN policy made 64 phase-duration decisions versus 58 fixed-time phases. Its total phase-1 time was 60 seconds shorter and phase-2 time 70 seconds longer. Most extra stopped delay was on M03, M05, and M06. This correlation does not isolate a causal phase decision; departure timing, queues, and interactions also matter.

Stopped-vehicle seconds include vehicles halted anywhere in the simulated network, not solely at the junction stop line. Source traces are in this directory. The network still emits a missing-green-phase warning for one tls index. This is a post-test diagnosis, not an additional model-selection criterion.
