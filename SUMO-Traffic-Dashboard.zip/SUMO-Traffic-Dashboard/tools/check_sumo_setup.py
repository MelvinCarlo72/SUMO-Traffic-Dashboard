"""Validate the dashboard SUMO setup. Run: python tools/check_sumo_setup.py"""
import json
import os
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SIM_DIR = ROOT / "pipeline" / "06_simulation"
CFG = SIM_DIR / "scenario.sumocfg"


def main():
    ok = True

    def missing(message):
        nonlocal ok
        print(f"MISSING: {message}")
        ok = False

    binary = os.environ.get("SUMO_BINARY", "sumo")
    found = shutil.which(binary)
    if not found and os.environ.get("SUMO_HOME"):
        candidate = Path(os.environ["SUMO_HOME"]) / "bin" / ("sumo.exe" if os.name == "nt" else "sumo")
        if candidate.is_file():
            found = str(candidate)
    if found:
        print(f"OK: SUMO executable: {found}")
    else:
        missing("SUMO executable; install SUMO and add its bin folder to PATH or set SUMO_BINARY")

    if not CFG.is_file():
        missing(f"configuration file: {CFG}")
        return 1
    try:
        cfg = ET.parse(CFG).getroot()
    except (ET.ParseError, OSError) as exc:
        missing(f"valid scenario.sumocfg XML ({exc})")
        return 1
    inputs = cfg.find("input")
    if inputs is None:
        missing("<input> section in scenario.sumocfg")
        return 1
    network = None
    for tag in ("net-file", "route-files", "additional-files"):
        node = inputs.find(tag)
        if node is None or not node.get("value", "").strip():
            if tag != "additional-files":
                missing(f"{tag} value in scenario.sumocfg")
            continue
        paths = [(CFG.parent / part.strip()).resolve() for part in node.get("value").split(",") if part.strip()]
        absent = [str(path) for path in paths if not path.is_file()]
        if absent:
            missing(f"existing {tag} files: {', '.join(absent)}")
        else:
            print(f"OK: {tag}: {', '.join(map(str, paths))}")
            if tag == "net-file":
                network = paths[0]

    tls_file = SIM_DIR / "tls_ids.json"
    if not tls_file.is_file():
        missing(f"verified traffic-light IDs in {tls_file} (copy tls_ids.json.example and fill it in)")
    elif network:
        try:
            ids = json.loads(tls_file.read_text(encoding="utf-8"))
            tree = ET.parse(network)
            known = {item.get("id") for item in tree.iter("junction")
                     if item.get("type") in ("traffic_light", "traffic_light_right_on_red")}
            for role in ("sacop", "del_rosario"):
                value = ids.get(role)
                if not value or str(value).startswith("PUT_"):
                    missing(f"verified '{role}' traffic-light ID in {tls_file}")
                elif value not in known:
                    missing(f"'{role}' ID '{value}' is not a signalized junction in {network}")
                else:
                    print(f"OK: {role} traffic-light ID: {value}")
        except (OSError, ValueError, ET.ParseError) as exc:
            missing(f"readable TLS IDs and network ({exc})")
    else:
        print("NOTE: TLS IDs cannot be checked until a network file is available.")

    if ok:
        print("SUMO setup checks passed. This checks configuration readiness, not demand calibration.")
        return 0
    print("Setup is incomplete. No network or route scenario was generated.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
