"""List the traffic lights in a SUMO network so you can find SACOP and Del Rosario.

Usage:  python tools/list_traffic_lights.py path/to/network.net.xml

For every traffic-light junction it prints the ID (what you put in tls_ids.json),
its latitude/longitude with a map link, the compass side of each incoming road
(same rule the dashboard uses) and street names when the network has them.
Needs only Python - no SUMO install.
"""
import math
import re
import sys
import xml.etree.ElementTree as ET


def utm_to_latlon(e, n, zone):
    a, f, k0 = 6378137.0, 1 / 298.257223563, 0.9996
    e2 = f * (2 - f); ep2 = e2 / (1 - e2)
    x, m = e - 500000.0, n / k0
    mu = m / (a * (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256))
    e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
    p = (mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * math.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * math.sin(4 * mu)
         + (151 * e1 ** 3 / 96) * math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * math.sin(8 * mu))
    sp, cp, tp = math.sin(p), math.cos(p), math.tan(p)
    n1 = a / math.sqrt(1 - e2 * sp * sp); t1 = tp * tp; c1 = ep2 * cp * cp
    r1 = a * (1 - e2) / (1 - e2 * sp * sp) ** 1.5; d = x / (n1 * k0)
    lat = p - (n1 * tp / r1) * (d * d / 2 - (5 + 3 * t1 + 10 * c1 - 4 * c1 * c1 - 9 * ep2) * d ** 4 / 24
                                + (61 + 90 * t1 + 298 * c1 + 45 * t1 * t1 - 252 * ep2 - 3 * c1 * c1) * d ** 6 / 720)
    lon = math.radians((zone - 1) * 6 - 180 + 3) + (d - (1 + 2 * t1 + c1) * d ** 3 / 6
                                                   + (5 - 2 * c1 + 28 * t1 - 3 * c1 * c1 + 8 * ep2 + 24 * t1 * t1) * d ** 5 / 120) / cp
    return math.degrees(lat), math.degrees(lon)


def compass(shape):
    (x1, y1), (x2, y2) = shape[-2], shape[-1]
    dx, dy = x2 - x1, y2 - y1
    if abs(dx) >= abs(dy):
        return "W" if dx > 0 else "E"      # travelling east => arrives from the West
    return "S" if dy > 0 else "N"


def main(path):
    junctions, lane_shape, edge_name = {}, {}, {}
    offset, zone = (0.0, 0.0), None
    for _, el in ET.iterparse(path, events=("end",)):
        if el.tag == "location":
            ox, oy = (float(v) for v in el.get("netOffset", "0,0").split(","))
            offset = (ox, oy)
            m = re.search(r"\+zone=(\d+)", el.get("projParameter", ""))
            zone = int(m.group(1)) if m and "+proj=utm" in el.get("projParameter", "") else None
        elif el.tag == "edge":
            if el.get("name"):
                edge_name[el.get("id")] = el.get("name")
            for ln in el.findall("lane"):
                pts = [tuple(float(c) for c in p.split(",")) for p in ln.get("shape", "").split()]
                if len(pts) >= 2:
                    lane_shape[ln.get("id")] = pts
            el.clear()
        elif el.tag == "junction" and el.get("type") == "traffic_light":
            junctions[el.get("id")] = (float(el.get("x")), float(el.get("y")), el.get("incLanes", "").split())
    if not junctions:
        print("No traffic-light junctions found in this network.")
        return
    print(f"{len(junctions)} traffic light(s) in {path}\n")
    for tid, (x, y, inc) in junctions.items():
        print(f"TLS id: {tid}")
        if zone:
            lat, lon = utm_to_latlon(x - offset[0], y - offset[1], zone)
            print(f"  location : {lat:.5f}, {lon:.5f}   https://www.google.com/maps?q={lat:.5f},{lon:.5f}")
        sides = {}
        for lane in inc:
            if lane in lane_shape:
                sides.setdefault(compass(lane_shape[lane]), set()).add(lane.rsplit("_", 1)[0])
        print("  approaches:", ", ".join(f"{d}={'/'.join(sorted(sides[d]))}" for d in "NSEW" if d in sides) or "unknown")
        names = sorted({edge_name[e] for es in sides.values() for e in es if e in edge_name})
        print("  streets   :", ", ".join(names) if names else "(network has no street names)")
        print()


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
