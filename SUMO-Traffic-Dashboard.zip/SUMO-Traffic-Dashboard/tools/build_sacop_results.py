"""Build data/sacop/results.json (used by the dashboard's Results page) from the SACOP thesis files.

Usage:  python tools/build_sacop_results.py            (reads data/sacop, writes data/sacop/results.json)

Every number comes from the CSV/JSON files in data/sacop; nothing is estimated here.
Re-run after replacing those files (for example when the full DQN/DDQN training finishes).
"""
import csv
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "data" / "sacop"


def rows(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        x = float(v)
        return int(x) if x.is_integer() and "." not in str(v) else x
    except (TypeError, ValueError):
        return v


def pretty_window(w):
    """'2026-09-16_Wednesday_new_thesis morning_0700_0730' -> ('2026-09-16', 'Wednesday', 'morning', '07:00-07:30')"""
    w = w.replace("\\", " ").replace("/", " ")
    day, _, period = w.partition(" ")
    m = re.match(r"(\d{4}-\d{2}-\d{2})_([A-Za-z]+)", day)
    p = re.search(r"(morning|afternoon)_(\d{2})(\d{2})_(\d{2})(\d{2})", period)
    date, weekday = (m.group(1), m.group(2)) if m else (day, "")
    when = f"{p.group(2)}:{p.group(3)}-{p.group(4)}:{p.group(5)}" if p else period
    return date, weekday, (p.group(1) if p else ""), when


def main():
    out = {"site": "SACOP (J02)", "files": {}}
    # --- movements -------------------------------------------------------
    labels = {r["movement_id"]: r for r in rows(D / "yolo" / "movement_label_key.csv")}
    turns = {"M01": "left", "M02": "straight", "M03": "straight", "M04": "right", "M05": "left", "M06": "right"}
    readme = (D / "manual_validation" / "README.md").read_text(encoding="utf-8")
    for m in re.finditer(r"\|\s*M(\d)\s*\|[^|]+\|[^|]+\|\s*(left|right|straight)\s*\|", readme):
        turns[f"M0{m.group(1)}"] = m.group(2)
    out["movements"] = [{"id": mid, "label": mid.split("_")[1].replace("M0", "M"), "origin": r["origin"],
                         "destination": r["destination"], "turn": turns.get(mid.split("_")[1], "")}
                        for mid, r in sorted(labels.items())]
    # --- controller summary ---------------------------------------------
    out["summary"] = [{"controller": r["controller"], "seeds": num(r["seeds"]),
                       "total_wait_vehicle_seconds": num(r["mean_total_wait_vehicle_seconds"]),
                       "wait_reduction_vs_fixed_percent": num(r["wait_reduction_vs_fixed_percent"]),
                       "mean_queue_vehicles": num(r["mean_queue_vehicles"]), "arrived": num(r["arrived"]),
                       "scheduled": num(r["scheduled"]), "max_collisions": num(r["max_collisions"]),
                       "max_teleports": num(r["max_teleports"])} for r in rows(D / "evaluation" / "three_controller_summary.csv")]
    out["per_seed"] = [{"controller": r["controller"], "seed": num(r["seed"]), "selected_cycle": num(r["selected_cycle"]),
                        "wait_reduction_percent": num(r["wait_reduction_percent"]), "improved_windows": num(r["improved_windows"]),
                        "mean_queue": num(r["model_mean_approach_queue"]), "fixed_mean_queue": num(r["fixed_mean_approach_queue"]),
                        "arrived": num(r["arrived"]), "scheduled": num(r["scheduled"]), "collisions": num(r["collisions"]),
                        "teleports": num(r["teleports"])} for r in rows(D / "evaluation" / "seed_summary.csv")]
    pw = []
    for r in rows(D / "evaluation" / "three_controller_per_window.csv"):
        date, weekday, period, when = pretty_window(r["day_window"])
        pw.append({"date": date, "weekday": weekday, "period": period, "time": when, "scheduled": num(r["scheduled"]),
                   "fixed": {"wait": num(r["Fixed-time_wait_vehicle_seconds"]), "queue": num(r["Fixed-time_mean_queue"])},
                   "dqn": {"wait": num(r["DQN_wait_vehicle_seconds"]), "queue": num(r["DQN_mean_queue"])},
                   "ddqn": {"wait": num(r["DDQN_wait_vehicle_seconds"]), "queue": num(r["DDQN_mean_queue"])}})
    out["per_window"] = pw
    # --- observed demand (YOLO) -------------------------------------------
    tot = defaultdict(lambda: defaultdict(int)); ctrl = {}
    for r in rows(D / "yolo" / "movement_counts_all.csv"):
        if r["complete_interval"] != "True":
            continue
        tot[r["source_window"]][r["movement_id"].split("_")[1]] += int(r["count"])
        ctrl[r["movement_id"].split("_")[1]] = r["control_type"]
    demand = []
    for w, mv in sorted(tot.items()):
        date, weekday, period, when = pretty_window(w)
        demand.append({"date": date, "weekday": weekday, "period": period, "time": when,
                       "total": sum(mv.values()), "movements": {k: mv.get(k, 0) for k in ("M01", "M02", "M03", "M04", "M05", "M06")}})
    out["demand"] = {"windows": demand, "control_type": ctrl,
                     "note": "Vehicles with a confirmed movement exit in the YOLO tracking output (30-minute windows). YOLO under-counts: see validation."}
    # --- validation ---------------------------------------------------------
    out["validation"] = json.loads((D / "manual_validation" / "comparison_metrics.json").read_text(encoding="utf-8"))
    out["notes"] = [
        "Results are SUMO simulation outcomes on eight demand windows (16-20 Sep 2026), not measured street performance.",
        "September data was used during earlier calibration, so this is not a pristine prospective holdout.",
        "Signal timing is provisional, and the network emits a missing-green-phase warning for one traffic-light index.",
        "Fixed-time is one deterministic run; DQN and DDQN are averages over seeds 42, 43 and 44.",
        "The evaluated controllers are DQN and DDQN (PyTorch). These files contain no SAC results.",
    ]
    (D / "results.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print("wrote", D / "results.json", "-", len(demand), "demand windows,", len(pw), "test windows")


if __name__ == "__main__":
    sys.exit(main())
