"""SUMO Traffic Dashboard - standalone desktop app.

Starts the FastAPI backend on a free local port inside this process and shows the
dashboard in its own native window (pywebview). No browser, no address bar, nothing
to start separately. Closing the window stops the server and any SUMO/TraCI session.

Run from source:   python desktop/app.py
Build an .exe:     BUILD_EXE.bat
"""
import logging
import os
import socket
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

TITLE = "SUMO Traffic Dashboard"
FROZEN = getattr(sys, "frozen", False)
ROOT = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parents[1]
if not FROZEN:
    sys.path.insert(0, str(ROOT))
try:
    os.chdir(ROOT)
except OSError:
    pass

logging.basicConfig(filename=str(ROOT / "traffic_dashboard.log"), level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("desktop")


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_until_ready(url, timeout=25.0):
    """Poll the backend until it answers. Returns True when ready."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            with urllib.request.urlopen(url, timeout=1.5) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.25)
    return False


def start_server(port):
    import uvicorn
    from webapp.backend.main import app
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_config=None))
    thread = threading.Thread(target=server.run, daemon=True, name="uvicorn")
    thread.start()
    return server, thread


def stop_server(server, thread):
    try:
        from webapp.backend.main import sim
        sim.reset()  # closes TraCI / SUMO if a run is active
    except Exception:
        log.exception("sim reset failed")
    server.should_exit = True
    thread.join(5)


def show_error(message):
    log.error(message)
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, TITLE, 0x10)
            return
    except Exception:
        pass
    print(message, file=sys.stderr)


class Api:
    """Methods callable from the page as window.pywebview.api.*"""
    def __init__(self):
        self._window = None
        self._full = False

    def set_fullscreen(self, on):
        if self._window is not None and bool(on) != self._full:
            self._window.toggle_fullscreen()
            self._full = bool(on)


def main():
    port = int(os.getenv("TRAFFIC_PORT") or free_port())
    url = f"http://127.0.0.1:{port}/"
    log.info("starting backend on %s (frozen=%s, root=%s)", url, FROZEN, ROOT)
    try:
        server, thread = start_server(port)
    except Exception as exc:
        log.exception("backend failed to start")
        show_error(f"The dashboard backend could not start:\n{exc}\n\nSee traffic_dashboard.log")
        return 1
    if not wait_until_ready(url + "api/state"):
        show_error("The dashboard backend did not respond in time.\n\nSee traffic_dashboard.log")
        stop_server(server, thread)
        return 1
    try:
        import webview
    except ImportError:
        show_error("pywebview is not installed, so the app window is unavailable.\n"
                   "Run: pip install pywebview\nOpening your browser instead.")
        webbrowser.open(url)
        try:
            while thread.is_alive():
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        stop_server(server, thread)
        return 0
    api = Api()
    api._window = webview.create_window(TITLE, url, js_api=api, width=1440, height=900,
                                        min_size=(1100, 680), background_color="#0d0f12")
    try:
        webview.settings["ALLOW_DOWNLOADS"] = True  # CSV export
    except Exception:
        pass
    try:
        webview.start()
    finally:
        stop_server(server, thread)
    return 0


if __name__ == "__main__":
    sys.exit(main())
