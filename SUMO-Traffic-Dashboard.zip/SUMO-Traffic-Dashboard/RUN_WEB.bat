@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate
python -m pip install -r webapp\requirements.txt
echo.
echo Starting SAC Traffic Dashboard...
echo Open http://127.0.0.1:8000
python -m uvicorn webapp.backend.main:app --host 127.0.0.1 --port 8000
pause
